public class SAMLConfiguration {
    private final String idpSsoUrl;
    private final String spEntityId;
    private final String assertionConsumerServiceUrl;

    public SAMLConfiguration(String idpSsoUrl, String spEntityId, String assertionConsumerServiceUrl) {
        this.idpSsoUrl = idpSsoUrl;
        this.spEntityId = spEntityId;
        this.assertionConsumerServiceUrl = assertionConsumerServiceUrl;
    }

    public String getIdpSsoUrl() {
        return idpSsoUrl;
    }

    public String getSpEntityId() {
        return spEntityId;
    }

    public String getAssertionConsumerServiceUrl() {
        return assertionConsumerServiceUrl;
    }
}
