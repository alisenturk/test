import org.opensaml.core.xml.XMLObject;
import org.opensaml.core.xml.config.XMLObjectProviderRegistrySupport;
import org.opensaml.core.xml.io.MarshallerFactory;
import org.opensaml.core.xml.io.UnmarshallerFactory;
import org.opensaml.saml.common.SAMLObject;
import org.w3c.dom.Element;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.StringWriter;
import java.util.Base64;

public class SAMLUtil {

    public static <T extends SAMLObject> T buildSAMLObject(Class<T> clazz) {
        return (T) XMLObjectProviderRegistrySupport.getBuilderFactory().getBuilder(clazz).buildObject();
    }

    public static String marshallAndEncode(XMLObject object) throws Exception {
        Element element = marshall(object);
        return Base64.getEncoder().encodeToString(nodeToString(element).getBytes());
    }

    public static <T extends SAMLObject> T decodeAndUnmarshall(String encodedXML, Class<T> clazz) throws Exception {
        String decodedXML = new String(Base64.getDecoder().decode(encodedXML));
        return (T) unmarshall(decodedXML);
    }

    private static Element marshall(XMLObject object) throws Exception {
        MarshallerFactory marshallerFactory = XMLObjectProviderRegistrySupport.getMarshallerFactory();
        return marshallerFactory.getMarshaller(object).marshall(object);
    }

    private static XMLObject unmarshall(String xml) throws Exception {
        UnmarshallerFactory unmarshallerFactory = XMLObjectProviderRegistrySupport.getUnmarshallerFactory();
        return unmarshallerFactory.getUnmarshaller(parseXML(xml)).unmarshall(parseXML(xml));
    }

    private static Element parseXML(String xml) throws Exception {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        dbFactory.setNamespaceAware(true);
        return dbFactory.newDocumentBuilder().parse(new ByteArrayInputStream(xml.getBytes())).getDocumentElement();
    }

    private static String nodeToString(Element node) throws Exception {
        StringWriter sw = new StringWriter();
        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.transform(new DOMSource(node), new StreamResult(sw));
        return sw.toString();
    }
}
