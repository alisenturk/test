import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/acs")
public class AssertionConsumerServlet extends HttpServlet {

    private SAMLAuthenticator authenticator;

    @Override
    public void init() throws ServletException {
        // Initialize the SAMLAuthenticator here (same as in LoginServlet)
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String samlResponse = request.getParameter("SAMLResponse");
        try {
            SAMLResponse userInfo = authenticator.processResponse(samlResponse);
            // Create a session for the authenticated user
            request.getSession().setAttribute("authenticatedUser", userInfo);
            response.sendRedirect("/dashboard"); // Redirect to a protected resource
        } catch (Exception e) {
            throw new ServletException("Failed to process SAML response", e);
        }
    }
}
