package tr.com.halkbank.hbsso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HbssoApplication {

	public static void main(String[] args) {
		SpringApplication.run(HbssoApplication.class, args);
	}

}
