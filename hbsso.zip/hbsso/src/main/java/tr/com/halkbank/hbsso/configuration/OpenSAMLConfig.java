package tr.com.halkbank.hbsso.configuration;

import org.opensaml.core.config.InitializationService;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenSAMLConfig {
	
	static {
        try {
            InitializationService.initialize();
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize OpenSAML", e);
        }
    }

}
