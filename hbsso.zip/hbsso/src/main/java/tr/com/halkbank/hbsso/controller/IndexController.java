package tr.com.halkbank.hbsso.controller;

import java.io.IOException;

import org.opensaml.saml.saml2.core.AuthnRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServletResponse;
import tr.com.halkbank.hbsso.util.SAMLUtils;

@Controller
@RequestMapping("/")
public class IndexController {

	
	private final SAMLUtils samlUtils;

    public IndexController() {
        this.samlUtils = new SAMLUtils();
    }

    @GetMapping("/saml/login")
    public void samlLogin(HttpServletResponse response) throws IOException {
        String issuerId = "your-entity-id"; // Replace with your entity ID
        String destination = "https://adfs.gen.halkbank.local/adfs/ls/"; // ADFS endpoint

        AuthnRequest authnRequest = samlUtils.createSAMLRequest(issuerId, destination);

        String samlRequest = samlUtils.encodeSAMLRequest(authnRequest);

        redirectToADFS(response, samlRequest);
    }

    private void redirectToADFS(HttpServletResponse response, String samlRequest) throws IOException {
        String redirectUrl = "https://adfs.gen.halkbank.local/adfs/ls/";
        response.sendRedirect(redirectUrl + "?SAMLRequest=" + samlRequest);
    }
}
