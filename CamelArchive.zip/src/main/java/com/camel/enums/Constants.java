package com.camel.enums;

/**
 *
 * @author asenturk
 */
public enum Constants {
    InquirySearchResult("InquirySearchResult","Inquiry arama sonuçları"),
    InquiryOtherSearchResult("InquiryOtherSearchResult","Inquiry arama sonuçları"),
    InquiryProjectSearchResult("InquiryProjectSearchResult","Inquiry Project arama sonuçları"),
    PROJECT_FILE_FOLDER("/opt/camel/","Proje dosyalarının yüklendiği dizin"),
    PROJECT_STAGE("prod","Proje ortamını ifade eder");
    
    Constants(String val){
        this.value = val;        
    }
    Constants(String val,String description){
        this.value = val;
        this.description = description;
    }
    
    private String  value;
    private String  description;

    public String getValue() {
        return value;
    }

   
    public String getDescription() {
        return description;
    }

    
    
    
}
