/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.enums;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asenturk
 */
public enum CustomsType {
    EXPORT("EXPORT","Export","PROJECT,AIR"),
    IMPORT("IMPORT","Import","PROJECT,AIR"),
    INLAND("INLAND","Inland","PROJECT"),
    ROUNDTRIP("ROUNDTRIP","Roundtrip","PROJECT"),
    CROSS("CROSS","Cross Trade","PROJECT,AIR,OCEAN"),
    TRANSIT("TRANSIT","Transit","PROJECT,AIR,OCEAN"),
    EXTRA_SERVICE("EXTRASERVICE","Other Service","ALL");
    
    private String  key;
    private String  value;
    private String  type;
    
    CustomsType(String key,String value,String type) {
        this.key = key;
        this.value = value;
        this.type = type;
    }

    public String getKey() {
        return key;
    }

    
    public String getValue() {
        return value;
    }

    public String getType() {
        return type;
    }

    public static List<CustomsType> getProjectCustomsTypes(){
        return getCustomsTypes("PROJECT");
    }
    
    public static List<CustomsType> getOceanCustomsTypes(){
        return getCustomsTypes("OCEAN");
    }
    
    
    public static List<CustomsType> getAirCustomsTypes(){
        return getCustomsTypes("AIR");
    }
    
    public static List<CustomsType> getCustomsTypes(String strType){
        List<CustomsType> list = new ArrayList<>();
        for(CustomsType it:CustomsType.values()){
            if(!it.getType().contains(strType) && !it.getType().equals("ALL"))continue;
            
            list.add(it);
        }
        return list;
    }
    
}
