/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.enums;

/**
 *
 * @author asenturk
 */
public enum UserType {
    
    ADMIN("ADMIN","Yönetici"),
    MEMBER("MEMBER","Üye");
    
    private UserType(String key,String val){
        this.key    = key;
        this.value  = val;
    }
    
    private String key;
    private String value;

    public String getKey() {
        return key;
    }


    public String getValue() {
        return value;
    }

    
    
}
