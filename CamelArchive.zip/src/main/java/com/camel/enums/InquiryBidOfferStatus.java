package com.camel.enums;

/**
 *
 * @author alisenturk
 */
public enum InquiryBidOfferStatus {
    
    NEW("NEW","New Record"),
    ACCEPTED("ACCEPTED","Accepted"),
    REJECT("REJECT","Reject");

    InquiryBidOfferStatus(String value, String label) {
        this.value = value;
        this.label = label;
    }
    
    private String  value;
    private String  label;

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }
    
    
    
}
