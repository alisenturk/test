package com.camel.enums;

public enum InquiryWorkScope {

    DOOR_TO_DOOR("D2D","Door To Door"),
    DOOR_TO_PORT("D2P","Door To Port"),
    PORT_TO_PORT("P2P","Port To Port"),
    PORT_TO_DOOR("P2D","Port To Door"),
    OTHER("OTHER","Other Service");

    private String  key;
    private String  value;

    InquiryWorkScope(String key,String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }


    public String getValue() {
        return value;
    }


}
