/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.enums;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asenturk
 */
public enum InquiryType {
    FIRM("FIRM","Firm","PROJECT"),
    INDICATION("INDICATION","Indication","PROJECT"),
    AIR("AIR","Air","OTHER"),
    OCEAN("OCEAN","Ocean","OTHER");
    
    private String  key;
    private String  value;
    private String  type;
    
    InquiryType(String key, String value,String type) {
        this.key = key;
        this.value = value;
        this.type = type;
    }

    public String getKey() {
        return key;
    }


    public String getValue() {
        return value;
    }

    public String getType() {
        return type;
    }

    
    public static List<InquiryType> getProjectInquiryTypes(){
        
        return getInquiryTypes("PROJECT");
    }
    
    
    public static List<InquiryType> getOtherInquiryTypes(){
        return getInquiryTypes("OTHER");
    }
    
    public static List<InquiryType> getInquiryTypes(String strType){
        List<InquiryType> list = new ArrayList<>();
        for(InquiryType it:InquiryType.values()){
            if(!it.getType().equals(strType) && !it.getType().equals("ALL"))continue;
            
            list.add(it);
        }
        return list;
    }
    
}
