package com.camel.enums;

/**
 *
 * @author asenturk
 */
public enum VisitType {
    PHONECALL("PHONECALL","Phone Call"),
    VISIT("VISIT","Visit");
    
    private String  value;
    private String  label;
    
    VisitType(String value,String label){
        this.value = value;
        this.label = label;
    }

    public String getValue() {
        return value;
    }


    public String getLabel() {
        return label;
    }

    
    
}
