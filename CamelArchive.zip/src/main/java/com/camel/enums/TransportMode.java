/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.enums;

/**
 *
 * @author asenturk
 */
public enum TransportMode {
    AIR("AIR","Air"),
    BREAKBULK("BREAKBULK","Break Bulk"),
    CONTAINER("CONTAINER","Container"),
    EXTRASERVICES("EXTRASERVICES","Extra Services"),
    MULTIMODAL("MULTIMODAL","Multi Modal"),
    LAND("LAND","Land"),
    OCEAN("OCEAN","Ocean"),
    RORO("RORO","Ro/Ro");
    
    
    private String  key;
    private String  value;
    TransportMode(String key,String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }


    public String getValue() {
        return value;
    }

    
}
