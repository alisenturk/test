/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.enums;

/**
 *
 * @author asenturk
 */
public enum InquiryStatus {
    ACCEPTED("ACCEPTED","Offer Accepted"),
    DECLINED("DECLINED","Offer Declined"),
    INPROGRESS("INPROGRESS","In Progress"),
    WAITINGFEEDBACK("WAITINGFEEDBACK","Waiting For Feedback"),
    SHIPMENTCOMPLETED("SHIPMENTCOMPLETED","Shipment Completed"),
    NOFEEDBACKRECEIVED("NOFEEDBACKRECEIVED","No Feedback Received"),
    OTHER_OPTION_ACCEPTED("OTHERACCEPTED","Other Option Accepted"),
    INDICATIVEOFFERGIVEN("INDICATIVEOFFERGIVEN","Indicative Offer Given"),
    CANCELLED("CANCELLED","Cancelled");
    
    private String  key;
    private String  value;
    InquiryStatus(String key,String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }


    public String getValue() {
        return value;
    }


    
}
