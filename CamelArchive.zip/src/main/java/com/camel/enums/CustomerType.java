package com.camel.enums;

/**
 *
 * @author asenturk
 */
public enum CustomerType {
    AGENT("AGENT","ISS Network"),
    CUSTOMER("CUSTOMER","Customer"),
    //FORWARDER("FORWARDER","Forwarder"),
    OTHER("OTHER","Other Network");
    
    private String  key;
    private String  value;
    CustomerType(String key,String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

  
    public String getValue() {
        return value;
    }

    
}
