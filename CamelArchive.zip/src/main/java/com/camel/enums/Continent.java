package com.camel.enums;

/**
 *
 * @author asenturk
 */
public enum Continent {

    EAST_MEDITERRANEAN("EAST_MEDITERRANEAN","East Mediterranean"),
    EASTERN_AFRICA("EASTERN_AFRICA","Eastern Africa"),
    EASTERN_ASIA("EASTERN_ASIA","Eastern Asia"),
    EASTERN_EUROPE("EASTERN_EUROPE","Eastern Europe"),
    MIDDLE_AFRICA("MIDDLE_AFRICA","Middle Africa"),
    MIDDLE_EAST("MIDDLE_EAST","Middle East"),
    NORTHERN_AFRICA("NORTHERN_AFRICA","Northern Africa"),
    NORTHERN_AMERICA("NORTHERN_AMERICA","Northern America"),
    NORTHERN_EUROPE("NORTHERN_EUROPE","Northern Europe"),
    OCEANIA("OCEANIA","Oceania"),
    SOUTH_AMERICA("SOUTH_AMERICA","South America"),
    SOUTH_EASTERN_ASIA("SOUTH_EASTERN_ASIA","South Eastern Asia"),
    SOUTHERN_AFRICA("SOUTHERN_AFRICA","Southern Africa"),
    SOUTHERN_ASIA("SOUTHERN_ASIA","Southern Asia"),
    SOUTHERN_EUROPE("SOUTHERN_EUROPE","Southern Europe"),
    WESTERN_AFRICA("WESTERN_AFRICA","Western Africa"),
    WESTERN_ASIA("WESTERN_ASIA","Western Asia"),
    WESTERN_EUROPE("WESTERN_EUROPE","Western Europe");

    Continent(String key,String value){
        this.key    = key;
        this.value  = value;
    }
    
    private String key;
    private String value;

    public String getKey() {
        return key;
    }


    public String getValue() {
        return value;
    }

    public static Continent getContinentFromValue(String strContinent){
        for(Continent continent:values()){
            if(continent.key.equalsIgnoreCase(strContinent) || continent.value.equalsIgnoreCase(strContinent) || continent.name().equalsIgnoreCase(strContinent)){
               return continent;
            }
        }

        return null;
    }
    
}
