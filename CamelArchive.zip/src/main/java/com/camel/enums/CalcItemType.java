/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.enums;

/**
 *
 * @author asenturk
 */
public enum CalcItemType {
    GENERAL("GENERAL","General"),
    ORGIN("ORGIN","Orgin"),
    DESTINATION("DESTINATION","Destination");
    private String  key;
    private String  value;
    
    private CalcItemType(String key,String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }


    public String getValue() {
        return value;
    }

    
}
