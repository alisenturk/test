package com.camel.action.project;

import com.camel.action.base.CrudService;
import com.camel.entity.base.Merchant;
import com.camel.entity.project.Project;
import com.camel.enums.Constants;
import com.camel.util.Helper;
import com.camel.util.JSFHelper;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named(value = "projectSearch")
@ViewScoped
public class ProjectSearchAction implements Serializable {
    @Inject
    CrudService crud;

    @Inject
    JSFHelper jsfHelper;

    @Inject
    private EntityManager em;

    private String  projectName;
    private List<Project> inquiryProjects = new ArrayList<>();
    private Merchant merchant = Helper.getCurrentUserMerchant();

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public List<Project> getInquiryProjects() {
        if(inquiryProjects.isEmpty() && jsfHelper.getSessionValue(Constants.InquiryProjectSearchResult.getValue())!=null){
            inquiryProjects = (List)jsfHelper.getSessionValue(Constants.InquiryProjectSearchResult.getValue());
        }
        return inquiryProjects;
    }

    public void setInquiryProjects(List<Project> inquiryProjects) {
        this.inquiryProjects = inquiryProjects;
    }

    public void searchProject(){
        try{

            jsfHelper.removeSessionValue(Constants.InquiryProjectSearchResult.getValue());
            ProjectQuery query = new ProjectQuery();
            query.setQueryName("InqProjectSearchListQuery");
            query.setProjectName(projectName);

            query.setMerchant(merchant);
            inquiryProjects.clear();
            inquiryProjects.addAll(crud.getList(query.getProjectQuery(),query.getParams()));
            if(inquiryProjects.size()>0){
                jsfHelper.setSessionValue(Constants.InquiryProjectSearchResult.getValue(),inquiryProjects);
            }

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
