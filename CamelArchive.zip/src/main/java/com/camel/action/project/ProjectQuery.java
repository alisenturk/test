/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.project;

import com.camel.entity.base.Department;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.MerchantBranch;
import com.camel.entity.base.User;
import com.camel.enums.UserType;

import java.util.HashMap;

/**
 *
 * @author asenturk
 */
public class ProjectQuery {
    private String          projectName;
    private Long            projectId;

    private Boolean   onlyBranchInquiries = true;

    private Merchant        merchant;
    private MerchantBranch  branch;
    private Department      department;
    private User            currentUser;
    private String          queryName;

    private HashMap<String,Object> params = new HashMap<String,Object>();

    public String getProjectQuery(){
        StringBuffer sql = new StringBuffer();
        try{
            boolean where = false;
            sql.append("SELECT d FROM Project d ");
            if(projectId!=null && projectId.longValue()>0){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.id=:projectId ");
            }
            if(merchant!=null && merchant.getId()!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.merchant.id=:mrchntid ");
            }
            if(projectName!=null && projectName.length()>3){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.projectName LIKE :prjctname ");
            }

            /** Sadece aynı branch'teki kişiler  bir birlerinin kayıtları görebilir
             *  Admin tipindeki kullanıcılar tüm kayıtları görebilir.
             **/
            if(branch!=null && currentUser!=null && !currentUser.getUserType().equals(UserType.ADMIN) && onlyBranchInquiries!=null && onlyBranchInquiries.booleanValue()){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.branch.id=:branchId ");
            }
            
            if(where){
                sql.append(" AND ");
            }else{
                sql.append(" WHERE ");
                where = true;
            }
            sql.append(" d.status = 'ACTIVE' ");
            
        }catch(Exception e){
            e.printStackTrace();
        }    
        
        return sql.toString();          
        
    }

    public HashMap<String, Object> getParams() {
        params = new HashMap<String,Object>();
        if(merchant!=null && merchant.getId()!=null){
            params.put("mrchntid",merchant.getId());
        }
        if(projectName!=null && projectName.length()>3){
            params.put("prjctname","%" + projectName+"%");
        }

        if(branch!=null && currentUser!=null && !currentUser.getUserType().equals(UserType.ADMIN) && onlyBranchInquiries!=null && onlyBranchInquiries){
            params.put("branchId",branch.getId());
        }
        if(department!=null){
            params.put("departmentid",department.getId());
        }



        return params;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public void setParams(HashMap<String, Object> params) {
        this.params = params;
    }

    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }


    public Boolean getOnlyBranchInquiries() {
        return onlyBranchInquiries;
    }

    public void setOnlyBranchInquiries(Boolean onlyBranchInquiries) {
        this.onlyBranchInquiries = onlyBranchInquiries;
    }

    public MerchantBranch getBranch() {
        return branch;
    }

    public void setBranch(MerchantBranch branch) {
        this.branch = branch;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }




    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }


    public String getQueryName() {
        return queryName;
    }

    public void setQueryName(String queryName) {
        this.queryName = queryName;
    }
}
