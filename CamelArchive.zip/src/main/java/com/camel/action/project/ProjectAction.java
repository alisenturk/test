package com.camel.action.project;

import com.camel.action.base.BaseAction;
import com.camel.action.base.Enums;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.User;
import com.camel.entity.inquiry.Inquiry;
import com.camel.entity.location.Country;
import com.camel.entity.project.Project;
import com.camel.entity.project.ProjectFile;
import com.camel.entity.project.ProjectFileType;
import com.camel.enums.Constants;
import com.camel.enums.Status;
import com.camel.servlet.FileDownload;
import com.camel.util.Helper;
import com.google.gson.Gson;
import org.apache.commons.io.FilenameUtils;
import org.omnifaces.cdi.Param;
import org.omnifaces.cdi.param.ParamValue;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

@Named(value = "projectBean")
@ViewScoped
public class ProjectAction  extends BaseAction<Project> {

    @Inject
    Enums enums;

    @Inject
    @Param(required = false)
    private ParamValue<String> processParam ;


    private List<User>      projectOwners   = new ArrayList<>();
    private List<Country>   countries       = new ArrayList<>();
    private boolean         updatable       = true;
    private Merchant        merchant        = Helper.getCurrentUserMerchant();
    private List<ProjectFile>       projectFiles    = new ArrayList<>();
    private String          previewFilePath="";
    private ProjectFile     currentProjectFile;

    private List<Inquiry>   projectInquiries = new ArrayList<>();

    @PostConstruct
    private void postLoad(){

        if(getInstance()!=null && getInstance().getId()!=null && getInstance().getId()>0){
            /*if(!checkUserAccessRight()){
                accessDeniedRedirect();
            } **/
            updatable = checkUserAccessRight();
            loadProjectInquiries();
        }

    }

    private boolean checkUserAccessRight(){
        if(Helper.getCurrentUserIsAdmin() || Helper.getCurrentUserIsMemberAdmin()){
            return true;
        }
        if(getInstance()!=null && getInstance().isManaged() && getInstance().getProjectOwner().getId().intValue()==Helper.getCurrentUserFromSession().getId().intValue()){
            return  true;
        }
        return false;
    }
    private void accessDeniedRedirect(){
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();

        HttpServletResponse response        = (HttpServletResponse) externalContext.getResponse();
        HttpServletRequest request         = (HttpServletRequest) externalContext.getRequest();

        try {
            response.sendRedirect(request.getContextPath() + "/access-denied.xhtml");
        } catch (IOException ex) {
            Logger.getLogger(ProjectAction.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void save(){
        try{

            if(getInstance().getMerchant()==null){
                getInstance().setMerchant(merchant);
            }
            if(getInstance().getBranch()==null){
                getInstance().setBranch(Helper.getCurrentUserMerchantBranch());
            }
            if(getInstance().getDepartment()==null){
                getInstance().setDepartment(Helper.getCurrentUserDepartment());
            }

            if(getInstance().getProjectOwner()==null){
                getInstance().setProjectOwner(Helper.getCurrentUserFromSession());
            }
            if(getInstance().isManaged()){ /** UPDATE **/

                getCrud().updateObject(getInstance());

                Helper.addMessage(Helper.getMessage("Global.Record.Updated"));
            }else{ /** INSERT **/

                getCrud().createObject(getInstance());
                Helper.addMessage(Helper.getMessage("Global.Record.Added"));
            }

            super.setList(new ArrayList<>());
        }catch(Exception e){
            Helper.addMessage("HATA..:" + e.getMessage());
        }
    }

    public List<User> getProjectOwners() {
        if(projectOwners.isEmpty()){
            projectOwners.add(Helper.getCurrentUserFromSession());
            if(getInstance().getProjectOwner()!=null && !getInstance().getProjectOwner().getId().equals(Helper.getCurrentUserFromSession().getId())){
                projectOwners.add(getInstance().getProjectOwner());
            }
        }
        return projectOwners;
    }

    public void setProjectOwners(List<User> projectOwners) {
        this.projectOwners = projectOwners;
    }

    public List<Country> getCountries() {
        if(countries.isEmpty()){
            countries.addAll(getCrud().getNamedList("Country.findAll"));
        }
        return countries;
    }

    public void setCountries(List<Country> countries) {
        this.countries = countries;
    }

    public boolean isUpdatable() {
        return updatable;
    }

    public void setUpdatable(boolean updatable) {
        this.updatable = updatable;
    }


    public List<ProjectFile> getProjectFiles() {
        if(projectFiles.isEmpty() && getInstance().isManaged()){
            HashMap<String,Object> inqParam = new HashMap<String,Object>();
            inqParam.put("prjctid",getInstance().getId());
            projectFiles.addAll(getCrud().getNamedList("ProjectFile.findAll", inqParam));
        }
        return projectFiles;
    }

    public void setProjectFiles(List<ProjectFile> projectFiles) {
        this.projectFiles = projectFiles;
    }

    public void handleFileUpload(FileUploadEvent event) {
        try{
            String fileName = event.getFile().getFileName().toLowerCase(Locale.ENGLISH);
            UploadedFile source = event.getFile();

            String folderPath = Constants.PROJECT_FILE_FOLDER.getValue() + "/project/"+Helper.getCurrentUserMerchant().getId()+"/"+getInstance().getId();
            if(Constants.PROJECT_STAGE.getValue().equals("dev")){
                folderPath = "/Users/alisenturk/Temp/opt/camel" + "/inquiry/"+Helper.getCurrentUserMerchant().getId()+"/"+getInstance().getId();
            }
            File folder = new File(folderPath);
            if(!folder.exists()){
                folder.mkdirs();
            }
            String filePath = folderPath +"/"+fileName;
            byte[] bytes=null;
            if (null!=source) {
                bytes = source.getContents();


                File newFile = new File(filePath);
                BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(newFile));
                stream.write(bytes);
                stream.close();

                ProjectFile inqFile = new ProjectFile();
                inqFile.setProjectFileType(ProjectFileType.OTHER);
                inqFile.setProject(getInstance());
                inqFile.setFileName(fileName);
                inqFile.setFilePath(filePath);
                inqFile.setFileType(FilenameUtils.getExtension(filePath).toUpperCase());
                inqFile.setFileMimeType(source.getContentType());
                inqFile.setStatus(Status.ACTIVE);
                getCrud().createObject(inqFile);

                projectFiles.clear();
            }

        }catch(Exception e){
            e.printStackTrace();
        }
        FacesMessage message = new FacesMessage("Succesful", event.getFile().getFileName() + " is uploaded.");
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void loadSelectedProjectFile(ProjectFile ifile){
        currentProjectFile = ifile;
        try{
            FileDownload file = new FileDownload();
            file.setFileName(currentProjectFile.getFileName());
            file.setFilePath(currentProjectFile.getFilePath());
            file.setContentType(currentProjectFile.getFileMimeType());

            Gson gson = new Gson();
            String fileData = gson.toJson(file);
            fileData = Helper.getEncryptData(fileData,Helper.SECRET_KEY);
            previewFilePath = "/FileDownloader?fileData="+fileData;

        }catch(Exception e){

        }
    }

    public void deleteProjectFile(ProjectFile file) {
        file.setStatus(Status.DELETED);
        getCrud().deleteObject(file);
        Helper.addMessage(Helper.getMessage("Global.Record.Deleted"));
        projectFiles.clear();
    }
    public String getPreviewFilePath() {
        return previewFilePath;
    }

    public void setPreviewFilePath(String previewFilePath) {
        this.previewFilePath = previewFilePath;
    }

    public ProjectFile getCurrentProjectFile() {
        return currentProjectFile;
    }

    public void setCurrentProjectFile(ProjectFile currentProjectFile) {
        this.currentProjectFile = currentProjectFile;
    }


    public void loadProjectInquiries(){

        projectInquiries.clear();
        if(getInstance()!=null && getInstance().isManaged()) {
            HashMap<String, Object> inqParam = new HashMap<String, Object>();
            inqParam.put("mrchntid",merchant.getId());
            inqParam.put("projectid", getInstance().getId());
            projectInquiries.addAll(getCrud().getNamedList("Inquiry.findProjectInquiries",inqParam));
        }
    }

    public List<Inquiry> getProjectInquiries() {
        return projectInquiries;
    }

    public void setProjectInquiries(List<Inquiry> projectInquiries) {
        this.projectInquiries = projectInquiries;
    }
}
