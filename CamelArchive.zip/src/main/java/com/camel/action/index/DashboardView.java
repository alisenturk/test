package com.camel.action.index;

import com.camel.action.base.CrudService;
import com.camel.action.events.ScheduleEventQuery;
import com.camel.action.inquiry.InquiryQuery;
import com.camel.entity.base.User;
import com.camel.entity.events.ScheduleEvent;
import com.camel.entity.inquiry.Inquiry;
import com.camel.enums.EventType;
import com.camel.enums.MemberType;
import com.camel.enums.Status;
import com.camel.util.Helper;
import com.camel.util.JSFHelper;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
/**
 *
 * @author asenturk
 */
@Named
@ViewScoped
public class DashboardView implements Serializable {
     
    @Inject
    CrudService crud;
    
    @Inject
    JSFHelper jsfHelper;
    
    private List<Dashboard>     list        = new ArrayList<Dashboard>();


    private Dashboard currentUserLoading        = null;
    private Dashboard currentUserOfferDeadline  = null;
    private Dashboard currentUserToAct          = null;
    private Dashboard departmentLoading         = null;
    private Dashboard departmentOfferDeadline   = null;
    
    private List<Inquiry> inquires = new ArrayList<>();
    private String      inquiresTableHeader = "Inquiries List";
    
    @PostConstruct
    public void init() {
        Date today = new Date();
        User user = jsfHelper.getCurrentUserFromSession();

        if(user!=null && crud!=null){
            try{
                HashMap<String,Object> userParam = new HashMap<String, Object>();

                userParam.put("responsibleId",user.getId());
                userParam.put("mrchntid",Helper.getCurrentUserMerchant().getId());
                
                boolean isInquiryStatusNull=true,isInquiryTypesNull=true;

                currentUserOfferDeadline = new Dashboard();
                currentUserOfferDeadline.setTitle(jsfHelper.getMessage("Dashboard.ToQuote"));
                currentUserOfferDeadline.setImagePath("images/dashboard/sales.svg");

                currentUserOfferDeadline.setInquiresAsOwner(new ArrayList<Inquiry>());
                currentUserOfferDeadline.getInquiresAsOwner().addAll(crud.getList(InquiryQuery
                                                                         .getResponsibleInquiriesFromOfferDeadline(isInquiryStatusNull,isInquiryTypesNull,MemberType.OWNER),userParam));
                

                currentUserOfferDeadline.setInquiresAsPricing(new ArrayList<Inquiry>());
                currentUserOfferDeadline.getInquiresAsPricing().addAll(crud.getList(InquiryQuery
                                                                           .getResponsibleInquiriesFromOfferDeadline(isInquiryStatusNull,isInquiryTypesNull,MemberType.PRICING),userParam));
                

                currentUserOfferDeadline.setInquiresAsInfo(new ArrayList<Inquiry>());
                currentUserOfferDeadline.getInquiresAsInfo().addAll(crud.getList(InquiryQuery
                                                                        .getResponsibleInquiriesFromOfferDeadline(isInquiryStatusNull,isInquiryTypesNull,MemberType.INFO),userParam));
                
                list.add(currentUserOfferDeadline);

                userParam.put("today",today);
                currentUserLoading = new Dashboard();
                currentUserLoading.setTitle(jsfHelper.getMessage("Dashboard.ToTrack"));
                currentUserLoading.setImagePath("images/dashboard/views.svg");
                currentUserLoading.setInquiresAsOwner(new ArrayList<Inquiry>());
                currentUserLoading.getInquiresAsOwner().addAll(crud.getList(InquiryQuery
                                                                   .getResponsibleInquiriesFromLoadingDate(isInquiryStatusNull,isInquiryTypesNull,MemberType.OWNER),userParam));
                
                currentUserLoading.setInquiresAsPricing(new ArrayList<Inquiry>());
                currentUserLoading.getInquiresAsPricing().addAll(crud.getList(InquiryQuery
                                                                     .getResponsibleInquiriesFromLoadingDate(isInquiryStatusNull,isInquiryTypesNull,MemberType.PRICING),userParam));
                
                currentUserLoading.setInquiresAsInfo(new ArrayList<Inquiry>());
                currentUserLoading.getInquiresAsInfo().addAll(crud.getList(InquiryQuery
                                                                  .getResponsibleInquiriesFromLoadingDate(isInquiryStatusNull,isInquiryTypesNull,MemberType.INFO),userParam));
                
                list.add(currentUserLoading);
                
                currentUserToAct = new Dashboard();
                currentUserToAct.setTitle(jsfHelper.getMessage("Dashboard.ToAct"));
                currentUserToAct.setImagePath("images/dashboard/progress.svg");
                currentUserToAct.setInquiresAsOwner(new ArrayList<Inquiry>());
                currentUserToAct.getInquiresAsOwner().addAll(crud.getList(InquiryQuery
                                                                 .getResponsibleInquiriesFromToAct(isInquiryStatusNull,isInquiryTypesNull,MemberType.OWNER),userParam));
                
                currentUserToAct.setInquiresAsPricing(new ArrayList<Inquiry>());
                currentUserToAct.getInquiresAsPricing().addAll(crud.getList(InquiryQuery
                                                                   .getResponsibleInquiriesFromToAct(isInquiryStatusNull,isInquiryTypesNull,MemberType.PRICING),userParam));
                
                currentUserToAct.setInquiresAsInfo(new ArrayList<Inquiry>());
                currentUserToAct.getInquiresAsInfo().addAll(crud.getList(InquiryQuery
                                                                .getResponsibleInquiriesFromToAct(isInquiryStatusNull,isInquiryTypesNull,MemberType.INFO),userParam));
                
                list.add(currentUserToAct);
    

            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    public List<Dashboard> getList() {
        return list;
    }

    public void setList(List<Dashboard> list) {
        this.list = list;
    }

    public Dashboard getCurrentUserLoading() {
        return currentUserLoading;
    }

    public void setCurrentUserLoading(Dashboard currentUserLoading) {
        this.currentUserLoading = currentUserLoading;
    }

    public Dashboard getCurrentUserOfferDeadline() {
        return currentUserOfferDeadline;
    }

    public void setCurrentUserOfferDeadline(Dashboard currentUserOfferDeadline) {
        this.currentUserOfferDeadline = currentUserOfferDeadline;
    }

    public Dashboard getDepartmentLoading() {
        return departmentLoading;
    }

    public void setDepartmentLoading(Dashboard departmentLoading) {
        this.departmentLoading = departmentLoading;
    }

    public Dashboard getDepartmentOfferDeadline() {
        return departmentOfferDeadline;
    }

    public void setDepartmentOfferDeadline(Dashboard departmentOfferDeadline) {
        this.departmentOfferDeadline = departmentOfferDeadline;
    }

    public Dashboard getCurrentUserToAct() {
        return currentUserToAct;
    }

    public void setCurrentUserToAct(Dashboard currentUserToAct) {
        this.currentUserToAct = currentUserToAct;
    }


    public List<Inquiry> getInquires() {
        return inquires;
    }

    public void setInquires(List<Inquiry> inquires) {
        this.inquires = inquires;
    }

    public void selectDashboard(Dashboard dash,String memberType){
        this.inquires = Collections.emptyList();
        this.inquiresTableHeader = dash.getTitle() + " - ";
        if(memberType.equals(MemberType.INFO.getKey())){
            this.inquires = dash.getInquiresAsInfo();
            this.inquiresTableHeader += "Info";
        }else if(memberType.equals(MemberType.OWNER.getKey())){
            this.inquires = dash.getInquiresAsOwner();
            this.inquiresTableHeader += "Owner";
        }else if(memberType.equals(MemberType.PRICING.getKey())){
            this.inquires = dash.getInquiresAsPricing();
            this.inquiresTableHeader += "Pricing";
        }
        this.inquiresTableHeader += " Inquiries";
    }

    public String getInquiresTableHeader() {
        return inquiresTableHeader;
    }

    public void setInquiresTableHeader(String inquiresTableHeader) {
        this.inquiresTableHeader = inquiresTableHeader;
    }
    
    
}
