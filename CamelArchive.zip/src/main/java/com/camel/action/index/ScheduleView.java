package com.camel.action.index;

import com.camel.action.base.CrudService;
import com.camel.action.events.ScheduleEventQuery;
import com.camel.action.inquiry.InquiryQuery;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.User;
import com.camel.entity.inquiry.Inquiry;
import com.camel.enums.EventType;
import com.camel.enums.InquiryStatus;
import com.camel.enums.InquiryType;
import com.camel.enums.Status;
import com.camel.util.Helper;
import com.camel.util.JSFHelper;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.event.ScheduleEntryMoveEvent;
import org.primefaces.event.ScheduleEntryResizeEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.DefaultScheduleEvent;
import org.primefaces.model.LazyScheduleModel;
import org.primefaces.model.ScheduleEvent;
import org.primefaces.model.ScheduleModel;
/**
 *
 * @author asenturk
 */
@Named
@ViewScoped
public class ScheduleView implements Serializable {

    @Inject
    CrudService crud;

    @Inject
    JSFHelper jsfHelper;

    private User            user        = null;
    private ScheduleModel   eventModel;
    private Merchant        merchant    = Helper.getCurrentUserMerchant();
    private ScheduleEvent event = new DefaultScheduleEvent();

    private List<Inquiry> listLoading = new ArrayList<>();
    private List<Inquiry> listOfferDeadline = new ArrayList<>();
    private List<Inquiry> listUnloading = new ArrayList<>();
    
    private List<com.camel.entity.events.ScheduleEvent> listEvents = new ArrayList<com.camel.entity.events.ScheduleEvent>();

    private List<String> inquiryStatuses = new ArrayList<String>();
    private List<String> inquiryTypes    = new ArrayList<String>();
    private List<String> selectedTracking= new ArrayList<String>();
    
    private com.camel.entity.events.ScheduleEvent scheduleEvent;
    
    private Date startDate = new Date();
    
    public ScheduleModel getEventModel() {
        return eventModel;
    }

    public void setEventModel(ScheduleModel eventModel) {
        this.eventModel = eventModel;
    }

    public List<Inquiry> getListLoading() {
        return listLoading;
    }

    public void setListLoading(List<Inquiry> listLoading) {
        this.listLoading = listLoading;
    }

    public List<Inquiry> getListOfferDeadline() {
        return listOfferDeadline;
    }

    public void setListOfferDeadline(List<Inquiry> listOfferDeadline) {
        this.listOfferDeadline = listOfferDeadline;
    }

    public List<String> getInquiryStatuses() {
        return inquiryStatuses;
    }

    public void setInquiryStatuses(List<String> inquiryStatuses) {
        this.inquiryStatuses = inquiryStatuses;
    }

    public List<String> getInquiryTypes() {
        return inquiryTypes;
    }

    public void setInquiryTypes(List<String> inquiryTypes) {
        this.inquiryTypes = inquiryTypes;
    }

    
    public void loadData() {
        //Date today = new Date();

        if(user==null){
            user = jsfHelper.getCurrentUserFromSession();
        }
        boolean isInquiryStatusNull=true,isInquiryTypesNull=true;
        HashMap<String, Object> deptParam = new HashMap<String, Object>();
        deptParam.put("today", startDate);
        deptParam.put("currentUserId", Long.valueOf("0"));
        deptParam.put("departmentId", user.getDepartment().getId());
        deptParam.put("mrchntid",Helper.getCurrentUserMerchant().getId());
        
        List<InquiryType> selectedTypes = new ArrayList<InquiryType>();
        if(inquiryTypes!=null && !inquiryTypes.isEmpty() && inquiryTypes.size()>0){
            for(String it:inquiryTypes){
                selectedTypes.add(InquiryType.valueOf(it));
            }
        }
        
        List<InquiryStatus> selectedStatus = new ArrayList<InquiryStatus>();
        if(inquiryStatuses!=null && !inquiryStatuses.isEmpty()){
            for(String is:inquiryStatuses){
                selectedStatus.add(InquiryStatus.valueOf(is));
            }
        }
        
        if(selectedStatus.size()>0){
            deptParam.put("inquiryStatuses", selectedStatus);
            isInquiryStatusNull = false;
        }
        if(selectedTypes.size()>0){
            deptParam.put("inquiryTypes", selectedTypes);
            isInquiryTypesNull = false;
        }
        
        listLoading.clear();
        listOfferDeadline.clear();
        listUnloading.clear();
        listEvents = new ArrayList<>();
        
        if(selectedTracking.contains("loading"))
            listLoading         = crud.getList(InquiryQuery.getDepartmentInquiriesFromLoadingDate(isInquiryStatusNull,isInquiryTypesNull), deptParam);
        
        if(selectedTracking.contains("offerdeadline"))
            listOfferDeadline   = crud.getList(InquiryQuery.getDepartmentInquiriesFromOfferDeadline(isInquiryStatusNull,isInquiryTypesNull,null), deptParam);
        
        if(selectedTracking.contains("unloading"))
            listUnloading       = crud.getList(InquiryQuery.getDepartmentInquiriesFromUnloadingDate(isInquiryStatusNull,isInquiryTypesNull), deptParam);


        List<EventType> strEventTypes = new ArrayList<>();
        boolean eventTypesEmpty = true;
        if(selectedTracking.contains(EventType.HOLIDAY.getKey().toLowerCase())){    
            strEventTypes.add(EventType.HOLIDAY);
        }            
        if(selectedTracking.contains(EventType.MEETING.getKey().toLowerCase())){
            strEventTypes.add(EventType.MEETING);
        }
        if(selectedTracking.contains(EventType.VISIT.getKey().toLowerCase()) ){
            strEventTypes.add(EventType.VISIT);
        }
        if(selectedTracking.contains(EventType.REMINDER.getKey().toLowerCase()) ){
            strEventTypes.add(EventType.REMINDER);
        }
        
        if(!strEventTypes.isEmpty()){
           eventTypesEmpty = false;
        }   
        HashMap<String, Object> eventParam = new HashMap<String, Object>();
        eventParam.put("today", startDate);
        eventParam.put("currentUserId", user.getId());
        eventParam.put("departmentId", user.getDepartment().getId());
        eventParam.put("evntStatus",Status.ACTIVE);
        eventParam.put("eventTypes",strEventTypes);
        eventParam.put("mrchntid",Helper.getCurrentUserMerchant().getId());
        if(!eventTypesEmpty)
            listEvents = crud.getList(ScheduleEventQuery.getScheduleEventQuery(eventTypesEmpty), eventParam);
        
    }
    
    public void refreshSchedule(){
        loadData();
        renderSchedule();
    }
    private String getEventInquiryDescription(Inquiry inq,int evetType){
        StringBuffer desc = new StringBuffer();
        desc.append("<table>");
        
        desc.append("    <tr>");
        desc.append("        <th style=\"font-weight:bold;text-align:left;\">Inquiry Code</th>");
        desc.append("        <td>"+inq.getInquiryCode()+"</td>");
        desc.append("    </tr>");
        
        desc.append("    <tr>");
        desc.append("        <th style=\"font-weight:bold;text-align:left;\">Inquiry Description</th>");
        desc.append("        <td>"+inq.getInquiryDescription()+"</td>");
        desc.append("    </tr>");
        if(evetType==1 || evetType==3){
            desc.append("    <tr>");
            desc.append("        <th style=\"font-weight:bold;text-align:left;\">Loading Date</th>");
            desc.append("        <td>"+Helper.date2String(inq.getLoadingDate())+"</td>");
            desc.append("    </tr>");
        }else if(evetType==2){
            desc.append("    <tr>");
            desc.append("        <th style=\"font-weight:bold;text-align:left;\">Offer Deadline Date</th>");
            desc.append("        <td>"+Helper.date2String(inq.getOfferDeadline())+"</td>");
            desc.append("    </tr>");
        }else if(evetType==3){
            desc.append("    <tr>");
            desc.append("        <th style=\"font-weight:bold;text-align:left;\">Unloading Date</th>");
            desc.append("        <td>"+Helper.date2String(inq.getUnloadingDate())+"</td>");
            desc.append("    </tr>");
        }
        desc.append("    <tr>");
        desc.append("        <th style=\"font-weight:bold;text-align:left;\">Customer</th>");
        desc.append("        <td>"+inq.getCustomer().getCustomerName()+"</td>");
        desc.append("    </tr>");
        
        desc.append("    <tr>");
        desc.append("        <th style=\"font-weight:bold;text-align:left;\">Responsible</th>");
        desc.append("        <td>"+inq.getResponsible().getNameSurname()+"</td>");
        desc.append("    </tr>");
        desc.append("</table>");
        
        
        return desc.toString();
    }
    public void renderSchedule() {
        try {
            //eventModel = new DefaultScheduleModel();
            
            DefaultScheduleEvent event = null;
            int count = 0;
         
            for (Inquiry inq : listLoading) {
                count++;
                event = new DefaultScheduleEvent(inq.getInquiryCode() +"-" + inq.getResponsible().getNameSurname() +"-" + inq.getInquiryDescription(), getEventStartDate(inq.getLoadingDate()), getEventEndDate(inq.getLoadingDate()), true);
                event.setId(String.valueOf(inq.getId()));
                event.setData(inq.getId());
                event.setEditable(false);
                event.setStyleClass("inquiry1");
                event.setDescription(getEventInquiryDescription(inq,1));
                
                eventModel.addEvent(event);
            }
             for (Inquiry inq : listUnloading) {
                count++;
                event = new DefaultScheduleEvent(inq.getInquiryCode() +"-" + inq.getResponsible().getNameSurname() +"-" + inq.getInquiryDescription(), getEventStartDate(inq.getLoadingDate()), getEventEndDate(inq.getLoadingDate()), true);
                event.setId(String.valueOf(inq.getId()));
                event.setData(inq.getId());
                event.setEditable(false);
                event.setStyleClass("inquiry3");
                event.setDescription(getEventInquiryDescription(inq,3));
                
                eventModel.addEvent(event);
            }
            for (Inquiry inq : listOfferDeadline) {
                count++;

                event = new DefaultScheduleEvent(inq.getInquiryCode() +"-" + inq.getResponsible().getNameSurname() +"-" + inq.getInquiryDescription(), getEventStartDate(inq.getOfferDeadline()), getEventEndDate(inq.getOfferDeadline()), true);
                event.setId(String.valueOf(inq.getId()));
                event.setData(inq.getId());
                event.setEditable(false);
                event.setStyleClass("inquiry2");
                event.setDescription(getEventInquiryDescription(inq,2));
                eventModel.addEvent(event);
            }
            
            for(com.camel.entity.events.ScheduleEvent evnt : listEvents) {
                count++;                
                event = new DefaultScheduleEvent(evnt.getDescription(),getEventDate(evnt.getEventStartdate()),getEventDate(evnt.getEventEnddate()),evnt.getEnableAllDay());
                event.setId(String.valueOf(evnt.getId()));
                event.setData(evnt);
                event.setEditable(true);                
                if(evnt.getEventType().equals(EventType.HOLIDAY)){
                    event.setStyleClass("eventType1");
                }else if(evnt.getEventType().equals(EventType.VISIT)){
                    event.setStyleClass("eventType2");
                }else if(evnt.getEventType().equals(EventType.MEETING)){
                    event.setStyleClass("eventType3");
                }
                event.setDescription(evnt.getDescription());
                eventModel.addEvent(event);
            }
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @PostConstruct
    public void init() {
        
        user = jsfHelper.getCurrentUserFromSession();
        if (user != null && crud != null) {

            selectedTracking.add("loading");
            selectedTracking.add("unloading");
            selectedTracking.add("offerdeadline");
            selectedTracking.add("holiday");
            selectedTracking.add("visit");
            selectedTracking.add("meeting");
            selectedTracking.add("reminder");
            
            eventModel = new LazyScheduleModel(){
                @Override
                public void loadEvents(Date start, Date end) {
                    startDate = start;
                    loadData();
                    renderSchedule();
                }   
            };
        }
    }

    public ScheduleEvent getEvent() {
        return event;
    }

    public void setEvent(ScheduleEvent event) {
        this.event = event;
    }

    public void addEvent(ActionEvent actionEvent) {
        if(event.getId() == null) {        
            scheduleEvent.setMerchant(merchant);
           crud.createObject(scheduleEvent);
        }else if(event.getId()!=null && event.isEditable()){            
            crud.updateObject(scheduleEvent);
        }
        loadData();
        renderSchedule();
    }

    private Date getEventStartDate(Date date) {
        Calendar t = Calendar.getInstance();
        t.setTime(date);
        t.set(Calendar.AM_PM, Calendar.AM);
        t.set(Calendar.DATE, t.get(Calendar.DATE));
        t.set(Calendar.HOUR, 9);

        return t.getTime();
    }

    private Date getEventEndDate(Date date) {
        Calendar t = Calendar.getInstance();
        t.setTime(date);
        t.set(Calendar.AM_PM, Calendar.PM);
        t.set(Calendar.DATE, t.get(Calendar.DATE));
        t.set(Calendar.HOUR, 5);

        return t.getTime();
    }
    
    private Date getEventDate(Date date) {
        Calendar t = Calendar.getInstance();
        t.setTimeInMillis(date.getTime());
        if(date.getHours()>=12){
            t.set(Calendar.AM_PM, Calendar.PM);
        }else{
               t.set(Calendar.AM_PM, Calendar.AM);
        }
        t.setTimeZone(TimeZone.getTimeZone("GMT+2"));
        return t.getTime();
    }

    public void onEventSelect(SelectEvent selectEvent) {
        event = (ScheduleEvent) selectEvent.getObject();
        scheduleEvent = new com.camel.entity.events.ScheduleEvent();
        if(event.getId()!=null && event.isEditable() && event.getData()!=null){
            scheduleEvent = (com.camel.entity.events.ScheduleEvent)event.getData();
        }
    }

    public void onDateSelect(SelectEvent selectEvent) {
        DefaultScheduleEvent dse = new DefaultScheduleEvent("", (Date) selectEvent.getObject(), (Date) selectEvent.getObject());
        scheduleEvent = new com.camel.entity.events.ScheduleEvent();
        scheduleEvent.setEventStartdate((Date) selectEvent.getObject());
        scheduleEvent.setEventEnddate((Date) selectEvent.getObject());
        scheduleEvent.setResponsible(user);
        scheduleEvent.setEventType(EventType.MEETING);
        dse.setData(scheduleEvent);
        event = dse;
    }

    public void onEventMove(ScheduleEntryMoveEvent event) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Event moved", "Day delta:" + event.getDayDelta() + ", Minute delta:" + event.getMinuteDelta());

        addMessage(message);
    }

    public void onEventResize(ScheduleEntryResizeEvent event) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Event resized", "Day delta:" + event.getDayDelta() + ", Minute delta:" + event.getMinuteDelta());

        addMessage(message);
    }

    private void addMessage(FacesMessage message) {
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public com.camel.entity.events.ScheduleEvent getScheduleEvent() {
        if(scheduleEvent == null){
            scheduleEvent = new com.camel.entity.events.ScheduleEvent();
            scheduleEvent.setEventType(EventType.MEETING);
            scheduleEvent.setResponsible(user);
        }
        return scheduleEvent;
    }

    public void setScheduleEvent(com.camel.entity.events.ScheduleEvent scheduleEvent) {
        this.scheduleEvent = scheduleEvent;
    }

    public List<String> getSelectedTracking() {
        return selectedTracking;
    }

    public void setSelectedTracking(List<String> selectedTracking) {
        this.selectedTracking = selectedTracking;
    }
    
    
    
}
