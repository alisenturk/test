/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.index;

import com.camel.entity.inquiry.Inquiry;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asenturk
 */
public class Dashboard implements Serializable{
    private String title;
    private List<Inquiry>   inquiresAsOwner     = new ArrayList<Inquiry>();
    private List<Inquiry>   inquiresAsPricing   = new ArrayList<Inquiry>();
    private List<Inquiry>   inquiresAsInfo      = new ArrayList<Inquiry>(); 
    private int inquiresAsOwnerCount    = -1;
    private int inquiresAsInfoCount     = -1;
    private int inquiresAsPricingCount  = -1;
    private String  imagePath="images/dashboard/sales.svg";
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<Inquiry> getInquiresAsOwner() {
        return inquiresAsOwner;
    }

    public void setInquiresAsOwner(List<Inquiry> inquiresAsOwner) {
        this.inquiresAsOwner = inquiresAsOwner;
    }

    public List<Inquiry> getInquiresAsPricing() {
        return inquiresAsPricing;
    }

    public void setInquiresAsPricing(List<Inquiry> inquiresAsPricing) {
        this.inquiresAsPricing = inquiresAsPricing;
    }

    public List<Inquiry> getInquiresAsInfo() {
        return inquiresAsInfo;
    }

    public void setInquiresAsInfo(List<Inquiry> inquiresAsInfo) {
        this.inquiresAsInfo = inquiresAsInfo;
    }

    public int getInquiresAsOwnerCount() {
        if(inquiresAsOwnerCount<0 ){
            inquiresAsOwnerCount = inquiresAsOwner.size();
        }
        return inquiresAsOwnerCount;
    }

    public void setInquiresAsOwnerCount(int inquiresAsOwnerCount) {
        this.inquiresAsOwnerCount = inquiresAsOwnerCount;
    }

    public int getInquiresAsInfoCount() {
        if(inquiresAsInfoCount<0 ){
            inquiresAsInfoCount = inquiresAsInfo.size();
        }
        return inquiresAsInfoCount;
    }

    public void setInquiresAsInfoCount(int inquiresAsInfoCount) {
        this.inquiresAsInfoCount = inquiresAsInfoCount;
    }

    public int getInquiresAsPricingCount() {
        if(inquiresAsPricingCount<0 ){
            inquiresAsPricingCount = inquiresAsPricing.size();
        }
        return inquiresAsPricingCount;
    }

    public void setInquiresAsPricingCount(int inquiresAsPricingCount) {
        this.inquiresAsPricingCount = inquiresAsPricingCount;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    
    
    
}
