/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.reports;

import com.camel.entity.base.MerchantBranch;
import com.camel.entity.base.User;
import com.camel.entity.customer.Customer;
import com.camel.enums.InquiryStatus;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author asenturk
 */
public class ReportQueries implements Serializable{

    private Long    merchantId;
    private Date    requestDateBegin;
    private Date    requestDateEnd;
    private User    responsibleUser;
    private InquiryStatus   inquiryStatus;
    private String  customerIds;
    private Map<String,Object>  params      = new HashMap<String, Object>();
    private Long    branchId;
    
    public void clearData(){
        merchantId          = 0L;
        branchId            = 0L;
        requestDateBegin    = null;
        requestDateEnd      = null;
        params.clear();
    }
    public String getResponsibleAvgOfferDays(){
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ");
        sql.append("    iq.responsible_id, ");
        sql.append("    u.firstname, ");
        sql.append("    u.lastname, ");
        sql.append(" avg(DATEDIFF(iq.offerDate , iq.requestDate)) avgOfferDays, ");
        sql.append("    count(1) inquiryCount, ");
        sql.append("    avg(iq.importance) avgImportance ");
        sql.append("FROM ");
        sql.append("    inquiry iq ");
        sql.append("    JOIN user u on u.id = iq.responsible_id ");
        sql.append("WHERE ");
        sql.append("    iq.merchant_id =:mrchntid  ");
        if(branchId!=null && branchId.intValue()>0){
            sql.append(" and ");
            sql.append(" iq.branch_id = " + branchId);
        }
        if(responsibleUser!=null && responsibleUser.getId()>0){
            sql.append(" and ");
            sql.append(" iq.responsible_id=:responsibleId ");
        }
        sql.append("    and (iq.requestDate between :requestBeginDate and :requestEndDate )  ");
        sql.append("    and iq.offerDate is not null ");
        sql.append("    and iq.requestDate is not null   ");
        sql.append("    and iq.status = 'ACTIVE' ");
        sql.append("GROUP BY iq.responsible_id ");
        sql.append("ORDER BY avgOfferDays,inquiryCount desc ");
        
        params.clear();
        
        return sql.toString();
    }

    public String getResponsibleModeBased(){
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ");
        sql.append("    iq.transportMode, ");
        sql.append("    UPPER(iq.customsType), ");
        sql.append("    count(1) cnt   ");
        sql.append("FROM ");
        sql.append("    inquiry iq ");
        sql.append("WHERE "); 
        sql.append("    iq.merchant_id =:mrchntid  ");
        if(branchId!=null && branchId.intValue()>0){
            sql.append(" and ");
            sql.append(" iq.branch_id = " + branchId);
        }
        if(responsibleUser!=null && responsibleUser.getId()>0){
            sql.append(" and ");
            sql.append(" iq.responsible_id=:responsibleId ");
        }
        sql.append("    and (iq.requestDate between :requestBeginDate and :requestEndDate )  ");
        sql.append("    and iq.offerDate is not null ");
        sql.append("    and iq.requestDate is not null   ");
        sql.append("    and iq.status = 'ACTIVE' ");
        sql.append("GROUP BY iq.transportMode,iq.customsType ");
        sql.append("ORDER BY iq.transportMode,iq.customsType ");
        
        
        
        return sql.toString();
    }
    
    public String getResponsibleSourceTypeBased(){
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ");
        sql.append("    iq.inquirySource, ");
        sql.append("    UPPER(iq.customsType), ");
        sql.append("    count(1) cnt   ");
        sql.append("FROM ");
        sql.append("    inquiry iq ");
        sql.append("WHERE "); 
        sql.append("    iq.merchant_id =:mrchntid  ");
        if(branchId!=null && branchId.intValue()>0){
            sql.append(" and ");
            sql.append(" iq.branch_id = " + branchId);
        }
        if(responsibleUser!=null && responsibleUser.getId()>0){
            sql.append(" and ");
            sql.append(" iq.responsible_id=:responsibleId ");
        }
        sql.append("    and (iq.requestDate between :requestBeginDate and :requestEndDate )  ");
        sql.append("    and iq.offerDate is not null ");
        sql.append("    and iq.requestDate is not null   ");
        sql.append("    and iq.status = 'ACTIVE' ");
        sql.append("GROUP BY iq.inquirySource,iq.customsType ");
        sql.append("ORDER BY iq.inquirySource,iq.customsType ");
        
        
        
        return sql.toString();
    }
    
    public String getResponsibleResultBased(){
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ");
        sql.append("    iq.inquiryStatus, ");
        sql.append("    UPPER(iq.inquirySource), ");
        sql.append("    count(1) cnt   ");
        sql.append("FROM ");
        sql.append("    inquiry iq ");
        sql.append("WHERE "); 
        sql.append("    iq.merchant_id =:mrchntid  ");
        if(branchId!=null && branchId.intValue()>0){
            sql.append(" and ");
            sql.append(" iq.branch_id = " + branchId);
        }
        if(responsibleUser!=null && responsibleUser.getId()>0){
            sql.append(" and ");
            sql.append(" iq.responsible_id=:responsibleId ");
        }
        sql.append("    and (iq.requestDate between :requestBeginDate and :requestEndDate )  ");
        sql.append("    and iq.offerDate is not null ");
        sql.append("    and iq.requestDate is not null   ");
        sql.append("    and iq.status = 'ACTIVE' ");
        sql.append("GROUP BY iq.inquiryStatus,iq.inquirySource ");
        sql.append("ORDER BY iq.inquiryStatus,iq.inquirySource ");
        
        
        return sql.toString();
    }
    
    public String getResponsibleCustomerBased(){
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ");
        sql.append("    c.customerName, ");
        sql.append("    iq.inquiryStatus, ");
        sql.append("    count(1) cnt   ");
        sql.append("FROM ");
        sql.append("    inquiry iq ");
        sql.append("    JOIN customer c ON c.id = iq.customer_id ");
        sql.append("WHERE "); 
        sql.append("    iq.merchant_id =:mrchntid  ");
        if(branchId!=null && branchId.intValue()>0){
            sql.append(" and ");
            sql.append(" iq.branch_id = " + branchId);
        }
        if(responsibleUser!=null && responsibleUser.getId()>0){
            sql.append(" and ");
            sql.append(" iq.responsible_id=:responsibleId ");
        }
        if(customerIds!=null && customerIds.length()>0){
            sql.append(" and iq.customer_id IN (:custList) ");
        }
        sql.append("    and (iq.requestDate between :requestBeginDate and :requestEndDate )  ");
        sql.append("    and iq.offerDate is not null ");
        sql.append("    and iq.requestDate is not null   ");
        sql.append("    and iq.status = 'ACTIVE' ");
        sql.append("GROUP BY c.customerName,iq.inquiryStatus ");
        sql.append("ORDER BY c.customerName,iq.inquiryStatus ");
        
        
        return sql.toString();
    }
    
    public Long getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }

    public Date getRequestDateBegin() {
        return requestDateBegin;
    }

    public void setRequestDateBegin(Date requestDateBegin) {
        this.requestDateBegin = requestDateBegin;
    }

    public Date getRequestDateEnd() {
        return requestDateEnd;
    }

    public void setRequestDateEnd(Date requestDateEnd) {
        this.requestDateEnd = requestDateEnd;
    }

    public Map<String, Object> getParams() {
        if(params==null)params = new HashMap<>();
        
        if(params.isEmpty()){
            params.put("mrchntid",merchantId);
            if(responsibleUser!=null && responsibleUser.getId()>0){
                params.put("responsibleId",responsibleUser.getId());
            }
            if(customerIds!=null && customerIds.length()>0){
                params.put("custList",customerIds);
            }
            if(inquiryStatus!=null){
                params.put("inqryStatus",inquiryStatus.getKey());
            }
            params.put("requestBeginDate",requestDateBegin);
            params.put("requestEndDate", requestDateEnd);
        }
        return params;
    }

    public void setParams(Map<String, Object> params) {
        this.params = params;
    }

    public User getResponsibleUser() {
        return responsibleUser;
    }

    public void setResponsibleUser(User responsibleUser) {
        this.responsibleUser = responsibleUser;
    }

    public String getCustomerIds() {
        return customerIds;
    }

    public void setCustomerIds(String customerIds) {
        this.customerIds = customerIds;
    }


    public InquiryStatus getInquiryStatus() {
        return inquiryStatus;
    }

    public void setInquiryStatus(InquiryStatus inquiryStatus) {
        this.inquiryStatus = inquiryStatus;
    }

    public Long getBranchId() {
        return branchId;
    }

    public void setBranchId(Long branchId) {
        this.branchId = branchId;
    }

    public String getBranchPerformanceQuery() {
        StringBuilder sql = new StringBuilder();
        sql.append("select ");
        sql.append("    mb.id, ");
        sql.append("   mb.branchName, ");
        sql.append("   sum(iq.offerCost) cost, ");
        sql.append("   sum(iq.offerValue) revenue, ");
        sql.append("   sum(iq.offerValue - iq.offerCost) profit ");
        sql.append("from ");
        sql.append("    inquiry iq ");
        sql.append("   join merchantbranch mb on iq.branch_id = mb.id ");
        sql.append("where ");
        sql.append("    iq.merchant_id =:mrchntid ");
        sql.append("    and (iq.requestDate between :requestBeginDate and :requestEndDate ) ");
        sql.append("    and iq.status = 'ACTIVE' ");
        if(inquiryStatus!=null){
            sql.append(" and iq.inquiryStatus =:inqryStatus ");
        }
        sql.append("group by mb.id,mb.branchName ");
        sql.append("order by mb.id,mb.branchName ");


        return sql.toString();
    }
}
