package com.camel.action.reports;

import com.camel.action.base.CrudService;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.User;
import com.camel.entity.reports.ReportData;
import com.camel.enums.InquiryStatus;
import com.camel.util.Helper;
import org.primefaces.model.chart.*;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

/**
 *
 * @author asenturk
 */
@ViewScoped
@Named(value = "reportBranchAction")
public class ReportBranchPerformanceAction implements Serializable {

    @Inject
    CrudService crud;

    private Merchant        merchant            = Helper.getCurrentUserMerchant();
    private Date            requestDateEnd      = new Date();
    private Date            requestDateBegin    = Helper.dateAdd(requestDateEnd, -300);
    private User            responsible;    
    private ReportQueries   queries             = new ReportQueries();
    private InquiryStatus   inquiryStatus       = null;

    private BarChartModel       branchPerformanceBarModel= new BarChartModel();
    private List<Object[]>     branchPerformanceData = new ArrayList<>();


    @PostConstruct
    public void init() {
        loadReportDatas();
    }

    public void loadReportDatas(){
        try {
            queries.clearData();

            branchPerformanceData.clear();

            queries.setMerchantId(merchant.getId());
            queries.setRequestDateBegin(requestDateBegin);
            queries.setRequestDateEnd(requestDateEnd);
            queries.setInquiryStatus(inquiryStatus);

            branchPerformanceData.clear();
            branchPerformanceData.addAll(crud.getNativeList(queries.getBranchPerformanceQuery(), (HashMap<String, Object>) queries.getParams()));


            loadBranchPerformanceBarChart();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
      private void loadBranchPerformanceBarChart(){
        branchPerformanceBarModel = new BarChartModel();
        branchPerformanceBarModel.setTitle("Branch Performance Chart");
        if(inquiryStatus!=null){
            branchPerformanceBarModel.setTitle(branchPerformanceBarModel.getTitle() + " ( " + inquiryStatus.getValue() +" ) ");

        }
        branchPerformanceBarModel.setAnimate(true);
        branchPerformanceBarModel.setLegendPosition("ne");

        branchPerformanceBarModel.setShowDatatip(true);
        branchPerformanceBarModel.setMouseoverHighlight(true);


        Axis xAxis = branchPerformanceBarModel.getAxis(AxisType.X);
        xAxis.setLabel("");
        xAxis.setTickAngle(-30);

        Axis yAxis = branchPerformanceBarModel.getAxis(AxisType.Y);
        yAxis.setLabel("Value ($)");
        yAxis.setMin(0);
        yAxis.setMax(0);


        String label = "";
        double cost = 0d, revenue=0d,profit=0d;
        ChartSeries branchSerie = null;

        branchSerie = new BarChartSeries();
        branchSerie.setLabel("Offer Cost");
        int yMax = 0;
        for(Object[] item:branchPerformanceData) {
          label = String.valueOf(item[1]);
          cost = ((Double)item[2]).doubleValue();
          revenue = ((Double)item[3]).doubleValue();
          yMax = (int)(cost+revenue);
          if(((Integer)yAxis.getMax()).doubleValue() < yMax){
                yAxis.setMax(yMax);
          }
          /*
          if(((Integer)yAxis.getMax()).doubleValue() < (revenue > cost?revenue:cost)){
              yAxis.setMax((revenue > cost?revenue:cost));
          } */
          branchSerie.set(label,cost);
        }
        branchPerformanceBarModel.addSeries(branchSerie);

        branchSerie = new BarChartSeries();
        branchSerie.setLabel("Offer Revenue");
        for(Object[] item:branchPerformanceData) {
          label = String.valueOf(item[1]);
          revenue = ((Double)item[3]).doubleValue();
          profit = ((Double)item[4]).doubleValue();

          branchSerie.set(label,revenue);
        }
        branchPerformanceBarModel.addSeries(branchSerie);

        branchSerie = new BarChartSeries();
        branchSerie.setLabel("Offer Profit");
        for(Object[] item:branchPerformanceData) {
          label = String.valueOf(item[1]);
          profit = ((Double)item[4]).doubleValue();

          branchSerie.set(label,profit);
        }
        branchPerformanceBarModel.addSeries(branchSerie);

      }



    public Date getRequestDateEnd() {
        return requestDateEnd;
    }

    public void setRequestDateEnd(Date requestDateEnd) {
        this.requestDateEnd = requestDateEnd;
    }

    public Date getRequestDateBegin() {
        return requestDateBegin;
    }

    public void setRequestDateBegin(Date requestDateBegin) {
        this.requestDateBegin = requestDateBegin;
    }

    public InquiryStatus getInquiryStatus() {
        return inquiryStatus;
    }

    public void setInquiryStatus(InquiryStatus inquiryStatus) {
        this.inquiryStatus = inquiryStatus;
    }

    public BarChartModel getBranchPerformanceBarModel() {
        return branchPerformanceBarModel;
    }

    public void setBranchPerformanceBarModel(BarChartModel branchPerformanceBarModel) {
        this.branchPerformanceBarModel = branchPerformanceBarModel;
    }

    public List<Object[]> getBranchPerformanceData() {
        return branchPerformanceData;
    }

    public void setBranchPerformanceData(List<Object[]> branchPerformanceData) {
        this.branchPerformanceData = branchPerformanceData;
    }
}
