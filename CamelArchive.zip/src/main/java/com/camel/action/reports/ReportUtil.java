package com.camel.action.reports;

import com.camel.entity.reports.ReportData;

import java.math.BigInteger;
import java.util.List;

public class ReportUtil {

    private ReportUtil(){}

    public static int findMaxData(List<ReportData> datas){
        int max = 0;
        int val = 0;
        for(ReportData data:datas){
            for(Object obj:data.getValues()){
                val = ((BigInteger)obj).intValue();
                if((max>0 && max<val) || max==0)
                    max = val;

            }
        }
        return max;
    }

    public static int getReportDataAsIntger(List dataList,int indx){
        if(dataList!=null && dataList.size()>0 && dataList.size()>indx){
            if(dataList.get(indx) instanceof Integer){
                return ((Integer)dataList.get(indx)).intValue();
            }else if(dataList.get(indx) instanceof BigInteger){
                return ((BigInteger)dataList.get(indx)).intValue();
            }
            return 0;
        }
        return 0;
    }
}
