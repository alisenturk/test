package com.camel.action.reports;

import com.camel.action.base.CrudService;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.User;
import com.camel.entity.customer.Customer;
import com.camel.entity.reports.ColumnValue;
import com.camel.entity.reports.ReportData;
import com.camel.enums.CustomsType;
import com.camel.enums.InquirySource;
import com.camel.enums.InquiryStatus;
import com.camel.enums.TransportMode;
import com.camel.util.Helper;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.model.DualListModel;
import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.BarChartModel;
import org.primefaces.model.chart.ChartSeries;

/**
 *
 * @author asenturk
 */
@ViewScoped
@Named(value = "reportAction")
public class ReportAction implements Serializable {

    @Inject
    CrudService crud;

    private Merchant        merchant            = Helper.getCurrentUserMerchant();
    private Date            requestDateEnd      = new Date();
    private Date            requestDateBegin    = Helper.string2Date("01/01/"+(requestDateEnd.getYear()+1900),"dd/MM/yyyy");
    private User            responsible;    
    private ReportQueries   queries             = new ReportQueries();
    
    private List<User>      responsibles        = new ArrayList<User>();
    private List<Customer>  sourceCustomers     = new ArrayList<Customer>();
    private List<Customer>  targetCustomers     = new ArrayList<Customer>(); 
    
    private DualListModel<Customer>   customers = null;
    
    private List<Object[]>      responsibleBasedList            = new ArrayList<>();    
    private BarChartModel       responsibleBasedBarModel        = new BarChartModel();
    
    private BarChartModel       responsibleModeTypeBasedBarModel= new BarChartModel();
    private List<String>        responsibleModeTypeBasedColumns = new LinkedList<String>();
    private List<ReportData>    responsibleModeTypeBasedDatas   = new LinkedList<ReportData>();
    
    private BarChartModel       responsibleSourceBasedBarModel= new BarChartModel();
    private List<String>        responsibleSourceBasedColumns = new LinkedList<String>();
    private List<ReportData>    responsibleSourceBasedDatas   = new LinkedList<ReportData>();
    
    private BarChartModel       responsibleResultBasedBarModel= new BarChartModel();
    private List<String>        responsibleResultBasedColumns = new LinkedList<String>();
    private List<ReportData>    responsibleResultBasedDatas   = new LinkedList<ReportData>();
    
    private BarChartModel       responsibleCustomerBasedBarModel= new BarChartModel();
    private List<String>        responsibleCustomerBasedColumns = new LinkedList<String>();
    private List<ReportData>    responsibleCustomerBasedDatas   = new LinkedList<ReportData>();
    
    
    @PostConstruct
    public void init() {
        loadReportDatas();
        if(sourceCustomers==null || sourceCustomers.isEmpty()){
            HashMap<String,Object> params = Helper.getParamsHashByMerchant();
            sourceCustomers = new ArrayList<Customer>();
            sourceCustomers.addAll(crud.getNamedList("Customer.findAll",params));
        }
    }
    private void loadReportDataValues(List<Object[]> list,List<String> targetColumns,List<ReportData> targetReports){
        ReportData data = null;
            String columnName = "";
            for(Object[] obj:list){
                columnName = String.valueOf(obj[1]);
                if(!targetColumns.contains(columnName)){
                    targetColumns.add(columnName);
                }
                
                data = new ReportData();
                data.setFieldName((String)obj[0]);
                if(!targetReports.contains(data)){                    
                    data.getValues().add(obj[2]);
                    targetReports.add(data);
                }else{
                    int indx = targetReports.indexOf(data);
                    data = targetReports.get(indx);
                    data.getValues().add(obj[2]);
                }
                
            }
    }
    private void loadReportDataValues2(List<Object[]> list,List<String> targetColumns,List<ReportData> targetReports){
        ReportData data = null;
            String columnName = "";
            
            int columnIndx , rowIndx = -1;
            for(Object[] obj:list){
                columnName = String.valueOf(obj[1]);
                columnIndx = targetColumns.indexOf(columnName);

                data = new ReportData();
                data.setFieldName((String)obj[0]);
                if(!targetReports.contains(data)){          
                    for(String inqs : targetColumns){
                        data.getValues().add(new BigInteger("0"));
                    }
                    data.getValues().add(columnIndx,obj[2]);
                    targetReports.add(data);
                }else{
                    rowIndx = targetReports.indexOf(data);
                    data = targetReports.get(rowIndx);
                    data.getValues().add(columnIndx,obj[2]);
                }
                
            }
    }
    public void loadCustomerDatas(){
        responsibleCustomerBasedColumns.clear();
        responsibleCustomerBasedDatas.clear();
        StringBuilder sb = new StringBuilder();
        int countCustomer = 0;

        queries.clearData();
        queries.setMerchantId(merchant.getId());
        queries.setRequestDateBegin(requestDateBegin);
        queries.setRequestDateEnd(requestDateEnd);
        queries.setResponsibleUser(responsible);
        if(countCustomer>0){
            sb.append(0);
            queries.setCustomerIds(sb.toString());
        }
        List list = new ArrayList<>();
        list.addAll(crud.getNativeList(queries.getResponsibleCustomerBased(), (HashMap<String, Object>) queries.getParams()));
        for(InquiryStatus is : InquiryStatus.values()){
            responsibleCustomerBasedColumns.add(is.getKey());
        }
        loadReportDataValues2(list, responsibleCustomerBasedColumns, responsibleCustomerBasedDatas);
            
        loadResponsibleCustomerBarChart();
            
    }
    public void loadReportDatas() {
        try {
            queries.clearData();
            responsibleBasedList.clear();

            responsibleModeTypeBasedColumns.clear();
            responsibleModeTypeBasedDatas.clear();
            responsibleSourceBasedColumns.clear();
            responsibleSourceBasedDatas.clear();
            responsibleResultBasedColumns.clear();
            responsibleResultBasedDatas.clear();
            responsibleCustomerBasedColumns.clear();
            responsibleCustomerBasedDatas.clear();
            
            
            queries.setMerchantId(merchant.getId());
            queries.setRequestDateBegin(requestDateBegin);
            queries.setRequestDateEnd(requestDateEnd);
            queries.setResponsibleUser(responsible);
            queries.setBranchId(Helper.getCurrentUserMerchantBranch().getId());
            if(Helper.getCurrentUserIsAdmin() || Helper.getCurrentUserIsMemberAdmin()) {
               queries.setBranchId(0L);
            }
             
            responsibleBasedList.addAll(crud.getNativeList(queries.getResponsibleAvgOfferDays(), (HashMap<String, Object>) queries.getParams()));
            
            List<Object[]>  list = new ArrayList<>();
            list.addAll(crud.getNativeList(queries.getResponsibleModeBased(), (HashMap<String, Object>) queries.getParams()));
            for(CustomsType ct:CustomsType.getProjectCustomsTypes()){
                responsibleModeTypeBasedColumns.add(ct.getKey());
            }
            loadReportDataValues2(list, responsibleModeTypeBasedColumns, responsibleModeTypeBasedDatas);
            
            
            list = new ArrayList<>();            
            list.addAll(crud.getNativeList(queries.getResponsibleSourceTypeBased(), (HashMap<String, Object>) queries.getParams()));
            for(CustomsType ct:CustomsType.getProjectCustomsTypes()){
                responsibleSourceBasedColumns.add(ct.getKey());
            }
            loadReportDataValues2(list, responsibleSourceBasedColumns, responsibleSourceBasedDatas);
            
            
            list = new ArrayList<>();
            list.addAll(crud.getNativeList(queries.getResponsibleResultBased(), (HashMap<String, Object>) queries.getParams()));
            for(InquirySource source:InquirySource.values()){
                responsibleResultBasedColumns.add(source.getKey());
            }
            loadReportDataValues2(list, responsibleResultBasedColumns, responsibleResultBasedDatas);
            
            list = new ArrayList<>();
            list.addAll(crud.getNativeList(queries.getResponsibleCustomerBased(), (HashMap<String, Object>) queries.getParams()));
            for(InquiryStatus is : InquiryStatus.values()){
                responsibleCustomerBasedColumns.add(is.getKey());
            }
            loadReportDataValues2(list, responsibleCustomerBasedColumns, responsibleCustomerBasedDatas);
            
            
            loadResponsibleBarChart();
            loadResponsibleModeTypeBarChart();
            loadResponsibleCustomerBarChart();
            loadResponsibleResultBarChart();
            loadResponsibleSourceBarChart();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public int getReportDataAsIntger(List dataList,int indx){
        if(dataList!=null && dataList.size()>0 && dataList.size()>indx){
            if(dataList.get(indx) instanceof Integer){
                return ((Integer)dataList.get(indx)).intValue();
            }else if(dataList.get(indx) instanceof BigInteger){
                return ((BigInteger)dataList.get(indx)).intValue();
            }
            return 0;
        }
        return 0;
    }
    
    public int getReportDataAsIntger(ReportData data,List dataList,int indx){
        if(dataList!=null && dataList.size()>0 && dataList.size()>indx){
            return ((BigInteger)dataList.get(indx)).intValue();
        }
        return 0;
    }
    
    private void loadResponsibleBarChart(){
        responsibleBasedBarModel = new BarChartModel();
        responsibleBasedBarModel.setTitle("Responsible Chart");
        responsibleBasedBarModel.setAnimate(true);
        responsibleBasedBarModel.setLegendPosition("ne");

        Axis xAxis = responsibleBasedBarModel.getAxis(AxisType.X);
        xAxis.setLabel("");
        xAxis.setTickAngle(-30);

        Axis yAxis = responsibleBasedBarModel.getAxis(AxisType.Y);
        yAxis.setLabel("Avg. Offer");
        yAxis.setMin(0);
        yAxis.setMax(5);

        String label = "";
        double val = 0d;

        ChartSeries respSerie = new ChartSeries();
        respSerie.setLabel("Avg. Offer Days");
        if(responsibleBasedList!=null && responsibleBasedList.size()>0){
            for(Object[] item:responsibleBasedList){
                label = item[1] + " " + item[2];                    
                if(item[3] instanceof BigDecimal ){
                    val = ((BigDecimal)item[3]).doubleValue();
                }if(item[3] instanceof Double ){
                    val = ((Double)item[3]).doubleValue();
                }
                
                respSerie.getData().put(label, val);
            }
            responsibleBasedBarModel.addSeries(respSerie);
            
            respSerie = new ChartSeries();
            respSerie.setLabel("Avg. Importance");
            for(Object[] item:responsibleBasedList){
                label = item[1] + " " + item[2];                    
                if(item[5] instanceof BigDecimal ){
                    val = ((BigDecimal)item[5]).doubleValue();
                }if(item[5] instanceof Double ){
                    val = ((Double)item[5]).doubleValue();
                }
                
                respSerie.getData().put(label, val);
            }
            
            responsibleBasedBarModel.addSeries(respSerie);
        }
    }

    private void loadResponsibleModeTypeBarChart(){
        responsibleModeTypeBasedBarModel = new BarChartModel();
        responsibleModeTypeBasedBarModel.setTitle("Responsible Mode Type Chart");
        responsibleModeTypeBasedBarModel.setAnimate(true);
        responsibleModeTypeBasedBarModel.setLegendPosition("ne");

        Axis xAxis = responsibleModeTypeBasedBarModel.getAxis(AxisType.X);
        xAxis.setLabel("");
        xAxis.setTickAngle(-30);

        Axis yAxis = responsibleModeTypeBasedBarModel.getAxis(AxisType.Y);
        yAxis.setLabel("Count");
        yAxis.setMin(0);
        yAxis.setMax(5);

        String label = "";
        double val = 0d;


        ChartSeries respSerie = null;
        int indx = -1;
        if(responsibleModeTypeBasedDatas!=null && responsibleModeTypeBasedDatas.size()>0){
            yAxis.setMax(ReportUtil.findMaxData(responsibleModeTypeBasedDatas));
            for(String columns:responsibleModeTypeBasedColumns){
                indx++;
                respSerie = new ChartSeries();
                respSerie.setLabel(columns);
                for(ReportData data:responsibleModeTypeBasedDatas){
                    label = data.getFieldName();
                    val = getReportDataAsIntger(data.getValues(), indx); 
                    //respSerie.getData().put(label, val);
                    respSerie.set(label, val);
                }
                
                responsibleModeTypeBasedBarModel.addSeries(respSerie);
            }
        }
    }
    
    private void loadResponsibleSourceBarChart(){
        responsibleSourceBasedBarModel = new BarChartModel();
        responsibleSourceBasedBarModel.setTitle("Sources Chart");
        responsibleSourceBasedBarModel.setAnimate(true);
        responsibleSourceBasedBarModel.setLegendPosition("ne");

        Axis xAxis = responsibleSourceBasedBarModel.getAxis(AxisType.X);
        xAxis.setLabel("");
        xAxis.setTickAngle(-30);

        Axis yAxis = responsibleSourceBasedBarModel.getAxis(AxisType.Y);
        yAxis.setLabel("Count");
        yAxis.setMin(0);
        yAxis.setMax(5);

        String label = "";
        double val = 0d;


        ChartSeries respSerie = null;
        int indx = -1;
        if(responsibleSourceBasedDatas!=null && responsibleSourceBasedDatas.size()>0){
            yAxis.setMax(ReportUtil.findMaxData(responsibleSourceBasedDatas));
            for(String columns:responsibleSourceBasedColumns){
                indx++;
                respSerie = new ChartSeries();
                respSerie.setLabel(columns);
                for(ReportData data:responsibleSourceBasedDatas){
                    label = data.getFieldName();
                    val = getReportDataAsIntger(data.getValues(), indx); 
                    respSerie.set(label, val);
                }
                
                responsibleSourceBasedBarModel.addSeries(respSerie);
            }
        }
    }
    private void loadResponsibleResultBarChart(){
        responsibleResultBasedBarModel = new BarChartModel();
        responsibleResultBasedBarModel.setTitle("Result Based Chart");
        responsibleResultBasedBarModel.setAnimate(true);
        responsibleResultBasedBarModel.setLegendPosition("ne");

        Axis xAxis = responsibleResultBasedBarModel.getAxis(AxisType.X);
        xAxis.setLabel("");
        xAxis.setTickAngle(-30);

        Axis yAxis = responsibleResultBasedBarModel.getAxis(AxisType.Y);
        yAxis.setLabel("Count");
        yAxis.setMin(0);
        yAxis.setMax(5);

        String label = "";
        double val = 0d;


        ChartSeries respSerie = null;
        int indx = -1;
        if(responsibleResultBasedDatas!=null && responsibleResultBasedDatas.size()>0){
            yAxis.setMax(ReportUtil.findMaxData(responsibleResultBasedDatas));
            for(String columns:responsibleResultBasedColumns){
                indx++;
                respSerie = new ChartSeries();
                respSerie.setLabel(columns);
                for(ReportData data:responsibleResultBasedDatas){
                    label = data.getFieldName();
                    val = getReportDataAsIntger(data.getValues(), indx); 
                    respSerie.set(label, val);
                }
                
                responsibleResultBasedBarModel.addSeries(respSerie);
            }
        }
    }
    private void loadResponsibleCustomerBarChart(){
        responsibleCustomerBasedBarModel = new BarChartModel();
        responsibleCustomerBasedBarModel.setTitle("Customer Based Chart");
        responsibleCustomerBasedBarModel.setAnimate(true);
        responsibleCustomerBasedBarModel.setLegendPosition("ne");

        Axis xAxis = responsibleCustomerBasedBarModel.getAxis(AxisType.X);
        xAxis.setLabel("");
        xAxis.setTickAngle(-30);

        Axis yAxis = responsibleCustomerBasedBarModel.getAxis(AxisType.Y);
        yAxis.setLabel("Count");
        yAxis.setMin(0);
        yAxis.setMax(5);

        String label = "";
        double val = 0d;


        ChartSeries respSerie = null;
        int indx = -1;
        if(responsibleCustomerBasedDatas!=null && responsibleCustomerBasedDatas.size()>0){
            yAxis.setMax(ReportUtil.findMaxData(responsibleCustomerBasedDatas));
            for(ReportData data:responsibleCustomerBasedDatas){
                indx = -1;
                respSerie = new ChartSeries();
                respSerie.setLabel(data.getFieldName());
                for(String columns:responsibleCustomerBasedColumns){
                    indx++;
                    label = columns ;
                    val = getReportDataAsIntger(data.getValues(), indx); 
                    respSerie.set(label, val);
                }
                
                responsibleCustomerBasedBarModel.addSeries(respSerie);
            }
        }
    }
    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    public Date getRequestDateEnd() {
        return requestDateEnd;
    }

    public void setRequestDateEnd(Date requestDateEnd) {
        this.requestDateEnd = requestDateEnd;
    }

    public Date getRequestDateBegin() {
        return requestDateBegin;
    }

    public void setRequestDateBegin(Date requestDateBegin) {
        this.requestDateBegin = requestDateBegin;
    }

    public User getResponsible() {
        return responsible;
    }

    public void setResponsible(User responsible) {
        this.responsible = responsible;
    }

    public ReportQueries getQueries() {
        return queries;
    }

    public void setQueries(ReportQueries queries) {
        this.queries = queries;
    }

    public List<User> getResponsibles() {
        if(responsibles.isEmpty()){
            if(Helper.getCurrentUserIsAdmin() || Helper.getCurrentUserIsMemberAdmin()) {
                responsibles.addAll(crud.getNamedList("User.findMerchantAllUsers", Helper.getParamsHashByMerchant()));
            }else{
                responsibles.add(Helper.getCurrentUserFromSession());
            }
        }
        return responsibles;
    }

    public void setResponsibles(List<User> responsibles) {
        this.responsibles = responsibles;
    }

    public List<Object[]> getResponsibleBasedList() {
        return responsibleBasedList;
    }

    public void setResponsibleBasedList(List<Object[]> responsibleBasedList) {
        this.responsibleBasedList = responsibleBasedList;
    }

    public BarChartModel getResponsibleBasedBarModel() {
        return responsibleBasedBarModel;
    }

    public void setResponsibleBasedBarModel(BarChartModel responsibleBasedBarModel) {
        this.responsibleBasedBarModel = responsibleBasedBarModel;
    }

    public List<String> getResponsibleModeTypeBasedColumns() {
        return responsibleModeTypeBasedColumns;
    }

    public void setResponsibleModeTypeBasedColumns(List<String> responsibleModeTypeBasedColumns) {
        this.responsibleModeTypeBasedColumns = responsibleModeTypeBasedColumns;
    }

    public List<ReportData> getResponsibleModeTypeBasedDatas() {
        return responsibleModeTypeBasedDatas;
    }

    public void setResponsibleModeTypeBasedDatas(List<ReportData> responsibleModeTypeBasedDatas) {
        this.responsibleModeTypeBasedDatas = responsibleModeTypeBasedDatas;
    }

    public List<String> getResponsibleSourceBasedColumns() {
        return responsibleSourceBasedColumns;
    }

    public void setResponsibleSourceBasedColumns(List<String> responsibleSourceBasedColumns) {
        this.responsibleSourceBasedColumns = responsibleSourceBasedColumns;
    }

    public List<ReportData> getResponsibleSourceBasedDatas() {
        return responsibleSourceBasedDatas;
    }

    public void setResponsibleSourceBasedDatas(List<ReportData> responsibleSourceBasedDatas) {
        this.responsibleSourceBasedDatas = responsibleSourceBasedDatas;
    }

    public List<String> getResponsibleResultBasedColumns() {
        return responsibleResultBasedColumns;
    }

    public void setResponsibleResultBasedColumns(List<String> responsibleResultBasedColumns) {
        this.responsibleResultBasedColumns = responsibleResultBasedColumns;
    }

    public List<ReportData> getResponsibleResultBasedDatas() {
        return responsibleResultBasedDatas;
    }

    public void setResponsibleResultBasedDatas(List<ReportData> responsibleResultBasedDatas) {
        this.responsibleResultBasedDatas = responsibleResultBasedDatas;
    }

    public List<String> getResponsibleCustomerBasedColumns() {
        return responsibleCustomerBasedColumns;
    }

    public void setResponsibleCustomerBasedColumns(List<String> responsibleCustomerBasedColumns) {
        this.responsibleCustomerBasedColumns = responsibleCustomerBasedColumns;
    }

    public List<ReportData> getResponsibleCustomerBasedDatas() {
        return responsibleCustomerBasedDatas;
    }

    public void setResponsibleCustomerBasedDatas(List<ReportData> responsibleCustomerBasedDatas) {
        this.responsibleCustomerBasedDatas = responsibleCustomerBasedDatas;
    }

    public BarChartModel getResponsibleModeTypeBasedBarModel() {
        return responsibleModeTypeBasedBarModel;
    }

    public void setResponsibleModeTypeBasedBarModel(BarChartModel responsibleModeTypeBasedBarModel) {
        this.responsibleModeTypeBasedBarModel = responsibleModeTypeBasedBarModel;
    }

    public BarChartModel getResponsibleSourceBasedBarModel() {
        return responsibleSourceBasedBarModel;
    }

    public void setResponsibleSourceBasedBarModel(BarChartModel responsibleSourceBasedBarModel) {
        this.responsibleSourceBasedBarModel = responsibleSourceBasedBarModel;
    }

    public BarChartModel getResponsibleResultBasedBarModel() {
        return responsibleResultBasedBarModel;
    }

    public void setResponsibleResultBasedBarModel(BarChartModel responsibleResultBasedBarModel) {
        this.responsibleResultBasedBarModel = responsibleResultBasedBarModel;
    }

    public BarChartModel getResponsibleCustomerBasedBarModel() {
        return responsibleCustomerBasedBarModel;
    }

    public void setResponsibleCustomerBasedBarModel(BarChartModel responsibleCustomerBasedBarModel) {
        this.responsibleCustomerBasedBarModel = responsibleCustomerBasedBarModel;
    }

    public List<Customer> getSourceCustomers() {
        return sourceCustomers;
    }

    public void setSourceCustomers(List<Customer> sourceCustomers) {
        this.sourceCustomers = sourceCustomers;
    }

    public List<Customer> getTargetCustomers() {
        return targetCustomers;
    }

    public void setTargetCustomers(List<Customer> targetCustomers) {
        this.targetCustomers = targetCustomers;
    }

    public DualListModel<Customer> getCustomers() {
        if(customers==null){
            customers = new DualListModel<Customer>(sourceCustomers, targetCustomers);
        }
        return customers;
    }

    public void setCustomers(DualListModel<Customer> customers) {
        this.customers = customers;
    }

    
    
    
    
   
    
    
}
