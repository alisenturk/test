/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.schedule;

import com.camel.entity.base.DailyExchange;
import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author asenturk
 */
public class TestMain {
    public static EntityManager getEntityManager(){
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CamelPU");
        return entityManagerFactory.createEntityManager();
    }
    public static EntityManager getEntityManager2(){
        EntityManager em = null;
        try{
            Context ic = (Context) new InitialContext();
           // em = (EntityManager)(new InitialContext()).lookup("java:comp/ejb/EntityManager");
             em = (EntityManager) ic.lookup("java:comp/env/persistence/name");
        } catch (Exception e){
            e.printStackTrace();
        };
        return em;
    }
    public static void main(String[] args){
        EntityManager em = getEntityManager2();
        //EntityTransaction et = em.getTransaction();
        //et.begin();
        String sql = "SELECT d FROM Dailyexchange d ";
        Query query = em.createQuery(sql);
        List<DailyExchange> listDaily = query.getResultList();
        for(DailyExchange de:listDaily){
            System.out.println("de.currency..:" + de.getCurrency() + " = " + de.getBuyingPrice());
        }
        //et.commit();
        //et = null;
        em.close();
        em = null;
    }
}
