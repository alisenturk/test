/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.customer;

import com.camel.action.base.BaseAction;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.MerchantBranch;
import com.camel.entity.customer.Contact;
import com.camel.util.Helper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named(value = "salesTeam")
@ViewScoped
public class SalesTeamAction extends BaseAction<Contact>{
    private HashMap<String, Object> params = new HashMap<String,Object>();
    private Merchant    merchant = Helper.getCurrentUserMerchant();
    private List<MerchantBranch> branches = new ArrayList<>();
    @Override
    public List<Contact> getList() {
        if(super.getList()==null || super.getList().isEmpty()){
           super.setList(new ArrayList<Contact>());
           super.getList().addAll(getCrud().getNamedList("Contact.findMerchantSalesTeam",Helper.getParamsHashByMerchant()));
        }
        return super.getList(); 
    }

    @Override
    public void save() {
        if(getInstance().getMerchant()==null){
            getInstance().setMerchant(merchant);
        }
        super.save(); 
    }

    public List<MerchantBranch> getBranches() {
        if(branches.isEmpty()){
            loadBranches();
        }
        return branches;
    }

    private void loadBranches() {
        params.clear();
        params.put("mrchntid",merchant.getId());
        branches.addAll(getCrud().getNamedList("MerchantBranch.findAllMerchantBranchs",params));

    }

    public void setBranches(List<MerchantBranch> branches) {
        this.branches = branches;
    }
}
