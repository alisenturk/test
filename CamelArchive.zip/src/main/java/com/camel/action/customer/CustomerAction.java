/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.customer;

import com.camel.action.base.BaseAction;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.Sector;
import com.camel.entity.customer.Customer;
import com.camel.entity.customer.Contact;
import com.camel.entity.inquiry.Inquiry;
import com.camel.entity.location.Country;
import com.camel.entity.visit.CustomerVisit;
import com.camel.enums.ContactType;
import com.camel.enums.CustomerType;
import com.camel.util.Helper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named
@ViewScoped
public class CustomerAction extends BaseAction<Customer>{

    private List<Sector>    sectors     = new ArrayList<Sector>();
    private List<Contact>   contacts    = new ArrayList<Contact>();
    private List<Country>   countries   = new ArrayList<Country>();
    private List<Inquiry>   customerInquiries = new ArrayList<>();

    private List<CustomerVisit> customerVisits = new ArrayList<>();

    private Merchant    merchant = Helper.getCurrentUserMerchant();
    private Contact     contact;

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }
    
    public List<Sector> getSectors() {
        if(sectors==null || sectors.isEmpty()){
           sectors.addAll(getCrud().getNamedList("Sector.findAll"));
        }
        return sectors;
    }

    public void setSectors(List<Sector> sectors) {
        this.sectors = sectors;
    }

    public List<Contact> getContacts() {
        if(getInstance()!=null && getInstance().isManaged() && (contacts==null || contacts.isEmpty())){
            HashMap<String,Object> params = new HashMap<String,Object>();
            params.put("custid",getInstance().getId());
            params.put("mrchntid",Helper.getCurrentUserMerchant().getId());
            contacts.addAll(getCrud().getNamedList("Contact.findCustomerContacts",params));
        }else if(getInstance()!=null && !getInstance().isManaged()){
            contacts = new ArrayList<Contact>();
        }
        return contacts;
    }

    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
    }
    
    public void loadCustomer(){
        contacts = new ArrayList<Contact>();
    }
    @Override
    public void newRecord() throws InstantiationException, IllegalAccessException {
        
        super.newRecord();
        getInstance().setCustomerType(CustomerType.CUSTOMER);
        getInstance().setMerchant(merchant);
    }

    
    public void addContact(){
        if(getInstance().isManaged()){
            contacts.add(0,new Contact(getInstance(),ContactType.CUSTOMER));
        }
    }  
    
    public void saveContact(Contact cntct){
        if(cntct.isManaged()){
            cntct.setContactType(ContactType.CUSTOMER);
            cntct.setMerchant(merchant);
            getCrud().updateObject(cntct);
            Helper.addMessage("Kayıt güncellendi!");
            contacts = new ArrayList<Contact>();
        }else{            
            cntct.setCustomer(getInstance());
            cntct.setContactType(ContactType.CUSTOMER);
            cntct.setMerchant(merchant);
            getCrud().createObject(cntct);
            Helper.addMessage("Kayıt eklendi!");
            contacts = new ArrayList<Contact>();
        }
    }
   
    
    @Override
    public List<Customer> getList() {
        if(super.getList()==null || super.getList().isEmpty()){
            HashMap<String,Object> params = Helper.getParamsHashByMerchant();
            super.setList(new ArrayList<Customer>());
            super.getList().addAll(getCrud().getNamedList("Customer.findAll",params));
        }
        return super.getList(); 
    }

    
    public List<Country> getCountries() {
        if(countries.isEmpty()){
            countries.addAll(getCrud().getNamedList("Country.findAll"));
        }
        return countries;
    }

    public void setCountries(List<Country> countries) {
        this.countries = countries;
    }

    public Merchant getMerchant() {
        if(merchant==null){
            merchant = Helper.getCurrentUserMerchant();
        }
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    public List<Customer> completeCustomer(String query) {
        List<Customer> filteredCustomers = new ArrayList<>();

        HashMap<String,Object> params = Helper.getParamsHashByMerchant();
        params.put("pcustomerName", query);
        if(getInstance().isManaged()){
            params.put("custid",getInstance().getId());
        }else{
            params.put("custid",0L);
        }
        filteredCustomers.addAll(getCrud().getNamedList("Customer.findCustomerByName",params));

        return filteredCustomers;
    }

    @Override
    public void save() {

        if(getInstance().getMerchant()==null){
            getInstance().setMerchant(getMerchant());
        }
        super.save();
        if(getInstance().isManaged() && getInstance().getId()>0) {
            setInstance(getCrud().find(Customer.class, getInstance().getId()));
        }
    }
    private void loadCustomerInquiries(){
        HashMap<String,Object> params = Helper.getParamsHashByMerchant();

        if(getInstance().isManaged()){
            params.put("custid",getInstance().getId());
        }else{
            params.put("custid",0);
        }
        customerInquiries.addAll(getCrud().getNamedList("Inquiry.findCustomerTop10Inquiry",params,10));
    }
    public List<Inquiry> getCustomerInquiries() {
        if(customerInquiries.isEmpty()){
            loadCustomerInquiries();
        }
        return customerInquiries;
    }

    public void setCustomerInquiries(List<Inquiry> customerInquiries) {
        this.customerInquiries = customerInquiries;
    }

    public List<CustomerVisit> getCustomerVisits() {
        if(customerVisits.isEmpty()){
            loadCustomerVisits();
        }
        return customerVisits;
    }

    private void loadCustomerVisits() {

        HashMap<String,Object> params = Helper.getParamsHashByMerchant();

        if(getInstance().isManaged()){
            params.put("custid",getInstance().getId());
        }else{
            params.put("custid",0);
        }
        customerVisits.addAll(getCrud().getNamedList("CustomerVisit.findCustomerAllVisit",params,10));
    }

    public void setCustomerVisits(List<CustomerVisit> customerVisits) {
        this.customerVisits = customerVisits;
    }
}
