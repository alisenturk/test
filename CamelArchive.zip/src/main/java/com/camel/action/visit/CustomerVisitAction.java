/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.visit;

import com.camel.action.base.BaseAction;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.User;
import com.camel.entity.base.UserAuth;
import com.camel.entity.customer.Contact;
import com.camel.entity.customer.Customer;
import com.camel.entity.visit.CustomerVisit;
import com.camel.entity.visit.VisitSubject;
import com.camel.util.Helper;
import org.primefaces.model.DualListModel;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.event.ValueChangeEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named
@ViewScoped
public class CustomerVisitAction extends BaseAction<CustomerVisit>{
    
    Merchant merchant = Helper.getCurrentUserMerchant();
    
    private List<User>      visitors    = new ArrayList<User>();
    private List<Customer>  customers   = new ArrayList<Customer>();
    private List<VisitSubject> subjects = new ArrayList<>();
    
    private CustomerVisitQuery visitQuery = new CustomerVisitQuery(merchant);
    private DualListModel<Contact>     contacts;

    private List<Contact>              sourceContacts = new ArrayList<>();
    private List<Contact>              targetContacts = new ArrayList<>();

    public List<Customer> getCustomers() {
        if(customers.isEmpty()){
            customers.addAll(getCrud().getNamedList("Customer.findAll",Helper.getParamsHashByMerchant()));
        }
        return customers;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }


    public List<User> getVisitors() {
        if(visitors.isEmpty()){
            visitors.addAll(getCrud().getNamedList("User.findMerchantAllUsers",Helper.getParamsHashByMerchant()));
        }
        return visitors;
    }

    public void setVisitors(List<User> visitors) {
        this.visitors = visitors;
    }
    
    
    
    @Override
    public List<CustomerVisit> getList() {
        
        return super.getList(); 
    }

    @Override
    public void save() {
        
        if(merchant!=null && merchant.getId()!=null && merchant.getId()>0){
            if(getInstance()!=null && getInstance().getMerchant()==null){
                getInstance().setMerchant(merchant);
            }            
        }
        getInstance().getContacts().clear();
        getInstance().getContacts().addAll(contacts.getTarget());
        super.save(); 
    }
    
    public void customerValueChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=getInstance().getCustomer()){
            sourceContacts.clear();
            HashMap<String, Object> params = new HashMap<String,Object>();
            params.put("custid", ((Customer)event.getNewValue()).getId());
            params.put("mrchntid",merchant.getId());
            sourceContacts.addAll(getCrud().getNamedList("Contact.findCustomerContacts", params));
        }
    }

    public void loadCustomerVisits(){
        try{
            if(getMerchant()==null){
                merchant = Helper.getCurrentUserMerchant();
            }
            visitQuery.setMerchant(getMerchant());
            super.getList().clear();
            String sql = visitQuery.getCustomerVisitQuery();
            super.getList().addAll(getCrud().getList(sql,visitQuery.getParams()));
        }catch(Exception e){
            System.out.println("e..:" + e.getMessage());
        }
        
    }
    
    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    
    public CustomerVisitQuery getVisitQuery() {
        return visitQuery;
    }

    public void setVisitQuery(CustomerVisitQuery visitQuery) {
        this.visitQuery = visitQuery;
    }


    public List<VisitSubject> getSubjects() {
        if(subjects.isEmpty()){
            subjects.addAll(getCrud().getNamedList("VisitSubject.findAll",Helper.getParamsHashByMerchant()));
        }
        return subjects;
    }

    public void setSubjects(List<VisitSubject> subjects) {
        this.subjects = subjects;
    }


    public DualListModel<Contact> getContacts() {
        return contacts;
    }

    public void setContacts(DualListModel<Contact> contacts) {
        this.contacts = contacts;
    }

    @PostConstruct
    private void init(){
        HashMap<String,Object>      params      = new HashMap<String,Object>();
        merchant    = Helper.getCurrentUserMerchant();
        params.put("mrchntid",merchant.getId());
        getInstance().setMerchant(merchant);

        if(getInstance()!=null && getInstance().isManaged()){
            targetContacts.addAll(getInstance().getContacts());

        }

        contacts = new DualListModel<>(sourceContacts,targetContacts);
    }
}
