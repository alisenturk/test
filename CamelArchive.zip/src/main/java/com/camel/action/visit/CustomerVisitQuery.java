/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.visit;

import com.camel.entity.base.Merchant;
import com.camel.entity.base.User;
import com.camel.entity.customer.Customer;
import com.camel.enums.Status;
import com.camel.enums.VisitType;
import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named(value = "customerVisitQuery")
@Stateless
public class CustomerVisitQuery implements Serializable{
    
    private Merchant        merchant;
    private VisitType       visitType;
    private Customer        customer;
    private User            visitor;
    private Date            visitDateBegin;
    private Date            visitDateEnd; 

    public CustomerVisitQuery() {
    }
    public CustomerVisitQuery(Merchant merchant) {
        this.merchant = merchant;
    }
    
    
    private HashMap<String, Object> params = new HashMap<String,Object>();

    public String getCustomerVisitQuery(){
        StringBuffer sql=new StringBuffer();
        sql.append("SELECT cv FROM CustomerVisit cv ");
        sql.append("WHERE ");
        sql.append(" cv.merchant.id=:mrchntid ");
        sql.append(" AND cv.status <> 'DELETED' ");
        if(visitType!=null){
            sql.append(" AND ");
            sql.append(" cv.visitType =:visittype");
        }
        if(customer!=null){
            sql.append(" AND ");
            sql.append(" cv.customer.id=:customerid");
        }
        if(visitor!=null){
            sql.append(" AND ");
            sql.append(" cv.visitor.id=:visitorid");
        }
        if(visitDateBegin!=null && visitDateEnd!=null){
            sql.append(" AND ");
            sql.append(" (cv.visitDate BETWEEN :beginDate AND :endDate) ");
        }
        
        return sql.toString();
    }
    
    public HashMap<String, Object> getParams() {
        params = new HashMap<String,Object>();
        params.put("mrchntid",merchant.getId());
        
        if(visitType!=null){
            params.put("visittype",visitType);
        }
        if(customer!=null){
            params.put("customerid",customer.getId());
        }
        if(visitor!=null){
          params.put("visitorid",visitor.getId());
        }
        if(visitDateBegin!=null && visitDateEnd!=null){
            params.put("beginDate", visitDateBegin);
            params.put("endDate", visitDateEnd);
        }
        return params;
    }

    public void setParams(HashMap<String, Object> params) {
        this.params = params;
    }
    
    
    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    public VisitType getVisitType() {
        return visitType;
    }

    public void setVisitType(VisitType visitType) {
        this.visitType = visitType;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public User getVisitor() {
        return visitor;
    }

    public void setVisitor(User visitor) {
        this.visitor = visitor;
    }

    public Date getVisitDateBegin() {
        return visitDateBegin;
    }

    public void setVisitDateBegin(Date visitDateBegin) {
        this.visitDateBegin = visitDateBegin;
    }

    public Date getVisitDateEnd() {
        return visitDateEnd;
    }

    public void setVisitDateEnd(Date visitDateEnd) {
        this.visitDateEnd = visitDateEnd;
    }
    
    
    
    
}
