package com.camel.action.inquiry;

import com.camel.action.base.BaseAction;
import com.camel.entity.customer.Customer;
import com.camel.entity.inquiry.CalcItem;
import com.camel.entity.inquiry.Inquiry;
import com.camel.entity.inquiry.InquiryCalc;
import com.camel.enums.CalcItemType;
import com.camel.enums.CalculationType;
import com.camel.enums.Currency;
import com.camel.enums.Status;
import com.camel.util.Helper;
import com.camel.util.JSFHelper;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import javax.faces.event.ValueChangeEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.component.api.UIData;
import org.primefaces.event.RowEditEvent;

/**
 *
 * @author asenturk
 */
@Named(value = "inquiryCalc")
@ViewScoped
public class InquiryCalcAction extends BaseAction<InquiryCalc>{
        
    @Inject
    JSFHelper helper;
        
    private Inquiry     inquery;
   
    private List<Customer>      suppliers           = new ArrayList<Customer>();
    private List<InquiryCalc>   costInquiryCalcs    = new ArrayList<InquiryCalc>();
    private List<InquiryCalc>   sellingInquiryCalcs = new ArrayList<InquiryCalc>();
    private List<CalcItem>      calcItems           = new ArrayList<CalcItem>();
    private HashMap<String,Object> inqParams = new HashMap<String,Object>();
    
    private Date    exchangeDate    = null;
    
    private Double  profitRate      = 10D;
    private Double  totalCostAsTRY  = 0d;
    private Double  totalSaleAsTRY  = 0d;
    private Double  totalBenefit    = 0d;
    private Double  benefitRate     = 0d;
    
    public Inquiry getInquery() {
        return inquery;
    }

    public void setInquery(Inquiry inquery) {
        this.inquery = inquery;
    }

    public List<Customer> getSuppliers() {
        if(suppliers.isEmpty()){
            suppliers = new ArrayList<Customer>();
            suppliers.addAll(getCrud().getNamedList("Customer.findAllSuppliers",Helper.getParamsHashByMerchant()));
        }
        return suppliers;
    }

    public void setSuppliers(List<Customer> suppliers) {
        this.suppliers = suppliers;
    }

    public List<InquiryCalc> getCostInquiryCalcs() {
        
        if(costInquiryCalcs.isEmpty()){
            costInquiryCalcs = new ArrayList<InquiryCalc>();
            try{
                costInquiryCalcs.addAll(getCrud().getNamedList("InquiryCalc.findCostAll",loadInquiryParam()));
            }catch(Exception e){
                System.out.println("aaa...:" + e.getMessage());
            }
        }
        
        return costInquiryCalcs;
    }

    public void setCostInquiryCalcs(List<InquiryCalc> costInquiryCalcs) {
        this.costInquiryCalcs = costInquiryCalcs;
    }

    public List<InquiryCalc> getSellingInquiryCalcs() {
        if(sellingInquiryCalcs.isEmpty()){
            sellingInquiryCalcs = new ArrayList<InquiryCalc>();
            sellingInquiryCalcs.addAll(getCrud().getNamedList("InquiryCalc.findSellingAll",loadInquiryParam()));
        }
        return sellingInquiryCalcs;
    }

    public void setSellingInquiryCalcs(List<InquiryCalc> sellingInquiryCalcs) {
        this.sellingInquiryCalcs = sellingInquiryCalcs;
    }
    
    
    private HashMap loadInquiryParam(){
        if(!inqParams.containsKey("inqryid") && getInquery()!=null){
            inqParams.put("inqryid", getInquery().getId());
        }
        return inqParams;
    }

    public void newCostRecord(){
        try{            
            setInstance(new InquiryCalc(getInquery(),CalculationType.COST,CalcItemType.ORGIN,Currency.TRY,getExchangeDate()));
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void removeCostRecord(InquiryCalc calc){
        try{    
            costInquiryCalcs.remove(calc);
            if(calc.isManaged()){
                calc.setStatus(Status.DELETED);
                getCrud().deleteObject(calc);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void newSaleRecord(){
        try{            
            setInstance(new InquiryCalc(getInquery(),CalculationType.SELLING,CalcItemType.ORGIN));
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void removeSaleRecord(InquiryCalc calc){
        try{    
            sellingInquiryCalcs.remove(calc);
            if(calc.isManaged()){
                calc.setStatus(Status.DELETED);
                getCrud().deleteObject(calc);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public List<CalcItem> getCalcItems() {
        if(calcItems.isEmpty()){
            calcItems.addAll(getCrud().getNamedList("CalcItem.findAll",Helper.getParamsHashByMerchant()));
        }        
        return calcItems;
    }

    public void setCalcItems(List<CalcItem> calcItems) {
        this.calcItems = calcItems;
    }
    
    
    public void saveInquiryCalc(){
         try{
            reCalcTotal(getInstance());
            if(getInstance().isManaged()){
                getCrud().updateObject(getInstance());
            }else{                
                getCrud().createObject(getInstance());
                cloneCost2Sale(getInstance());
            }
            costInquiryCalcs.clear();
            sellingInquiryCalcs.clear();
            
            if(getInstance().getCalcType().equals(CalculationType.COST)){
                newCostRecord();
            }else{
                newSaleRecord();
            }
         }catch(Exception e){
             e.printStackTrace();
         }
    }
    
    public void currencyValueChange(ValueChangeEvent e){
        Currency myNewValue = (Currency)e.getNewValue();
        Currency myOldValue = (Currency)e.getOldValue();
        
        if(myNewValue!=null && myOldValue!=null && !myNewValue.getValue().equals(myOldValue.getValue())){
            double exchage = helper.getDailyExchangeValue(myNewValue,getExchangeDate());
            
            getInstance().setDailyExchangeTRYRate(exchage);
            getInstance().setDailyExchangeDate(getExchangeDate());
            reCalcTotal(getInstance());
        }
    }
    
    public void saleCurrencyValueChange(ValueChangeEvent e){
        Currency myNewValue = (Currency)e.getNewValue();
        Currency myOldValue = (Currency)e.getOldValue();
        
        if(myNewValue!=null && myOldValue!=null && !myNewValue.getValue().equals(myOldValue.getValue())){
            double exchage = helper.getDailyExchangeValue(myNewValue,getExchangeDate());
            getInstance().setDailyExchangeTRYRate(exchage);
            getInstance().setDailyExchangeDate(getExchangeDate());
            reCalcTotal(getInstance());
        }
    }
    
    public void numberValueChange(ValueChangeEvent e){
        
        
        Double myNewValue = (Double)e.getNewValue();
        Double myOldValue = (Double)e.getOldValue();
        
        if(myNewValue!=null && myOldValue!=null && !myNewValue.equals(myOldValue)){
            
            String componentID = e.getComponent().getId();
            if(componentID.equals("calcRateEdit")){
                getInstance().setRate(myNewValue);
            }else if(componentID.equals("calcVatEdit")){
                getInstance().setVat(myNewValue);
            }else if(componentID.equals("calcParam1Edit")){
                getInstance().setParam1(myNewValue);
            }else if(componentID.equals("calcParam2Edit")){
                getInstance().setParam2(myNewValue);
            }else if(componentID.equals("calcDailyExchangeEdit")){
                getInstance().setDailyExchangeTRYRate(myNewValue);
            }
            reCalcTotal(getInstance());
        }
    }
    
    private void reCalcTotal(InquiryCalc calc){
        if(calc!=null){
            double total = Helper.roundDecimal(calc.getRate() * calc.getVat() * calc.getParam1() * calc.getParam2());
            calc.setTotal(total);
            
        }
    }
    public Double getProfitRate() {
        return profitRate;
    }

    public void setProfitRate(Double profitRate) {
        this.profitRate = profitRate;
    }

    public void calculationSellingByCost(){
        
        try{
            if(!costInquiryCalcs.isEmpty() && sellingInquiryCalcs.isEmpty()){
                for(InquiryCalc cost:costInquiryCalcs){
                     cloneCost2Sale(cost);
                }                
            }
            sellingInquiryCalcs.clear();
        }catch(Exception e){
            
        }
    }
    
    private void cloneCost2Sale(InquiryCalc cost){
        InquiryCalc sale = null;
        try{
            sale = cost.clone();
            sale.setId(null);
            sale.setCalcType(CalculationType.SELLING);
            sale.setRate(Helper.roundDecimal((cost.getRate() * (1+getProfitRate()/100))));
            reCalcTotal(sale);
            getCrud().createObject(sale);                 
        }catch(Exception e){
            
        }finally{
            sale = null;
        }
    }

    public void calcSummary(){
        try{
            if(!getCostInquiryCalcs().isEmpty() && !getSellingInquiryCalcs().isEmpty()){
                totalBenefit    = 0d;
                totalCostAsTRY  = 0d;
                totalSaleAsTRY  = 0d;
                benefitRate     = 0d;
                for(InquiryCalc calc:getCostInquiryCalcs()){
                    totalCostAsTRY +=calc.getTotalAsTRY();
                }
                for(InquiryCalc calc:getSellingInquiryCalcs()){
                    totalSaleAsTRY += calc.getTotalAsTRY();
                }
                totalBenefit = Helper.roundDecimal(totalSaleAsTRY - totalCostAsTRY);
                if(totalBenefit>0 && totalCostAsTRY>0){
                    benefitRate  = Helper.roundDecimal(totalBenefit/totalCostAsTRY*100d);
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public Double getTotalCostAsTRY() {
        if(totalCostAsTRY==0){
            calcSummary();
        }
        return totalCostAsTRY;
    }

    public void setTotalCostAsTRY(Double totalCostAsTRY) {
        this.totalCostAsTRY = totalCostAsTRY;
    }

    public Double getTotalSaleAsTRY() {
        return totalSaleAsTRY;
    }

    public void setTotalSaleAsTRY(Double totalSaleAsTRY) {
        this.totalSaleAsTRY = totalSaleAsTRY;
    }

    public Double getTotalBenefit() {
        return totalBenefit;
    }

    public void setTotalBenefit(Double totalBenefit) {
        this.totalBenefit = totalBenefit;
    }

    public Double getBenefitRate() {
        return benefitRate;
    }

    public void setBenefitRate(Double benefitRate) {
        this.benefitRate = benefitRate;
    }

    public Date getExchangeDate() {
        if(exchangeDate==null && inquery!=null && inquery.getOfferDate()!=null){
            exchangeDate = inquery.getOfferDate();
        }else if(exchangeDate==null && inquery!=null && inquery.getOfferDate()==null && inquery.getRequestDate()!=null){
            exchangeDate = inquery.getRequestDate();
        }
        return exchangeDate;
    }

    public void setExchangeDate(Date exchangeDate) {
        this.exchangeDate = exchangeDate;
    }
    
    public void updateExchangeDate(){
        for(InquiryCalc calc:costInquiryCalcs){
            if(!calc.isManaged())continue;
            calc.setDailyExchangeTRYRate(helper.getDailyExchangeValue(calc.getCurrency(),getExchangeDate()));
            calc.setDailyExchangeDate(getExchangeDate());
            reCalcTotal(calc);
            getCrud().updateObject(calc);
        }
        for(InquiryCalc calc:sellingInquiryCalcs){
            if(!calc.isManaged())continue;
            calc.setDailyExchangeTRYRate(helper.getDailyExchangeValue(calc.getCurrency(),getExchangeDate()));
            calc.setDailyExchangeDate(getExchangeDate());
            reCalcTotal(calc);
            getCrud().updateObject(calc);            
        }
        getCostInquiryCalcs().clear();
        getSellingInquiryCalcs().clear();
    }

    @Override
    public InquiryCalc getInstance() {
        if(super.getInstance()==null)newCostRecord();
        return super.getInstance(); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
