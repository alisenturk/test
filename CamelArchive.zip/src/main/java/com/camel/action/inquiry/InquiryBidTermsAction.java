/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.inquiry;

import com.camel.action.base.BaseAction;
import com.camel.entity.base.Department;
import com.camel.entity.base.Merchant;
import com.camel.entity.inquiry.InquiryBidTerms;
import com.camel.util.Helper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author alisenturk
 */
@Named
@ViewScoped
public class InquiryBidTermsAction extends BaseAction<InquiryBidTerms>{
    Merchant        merchant = Helper.getCurrentUserMerchant();

    @Override
    public List<InquiryBidTerms> getList() {
        super.getList().clear();
        super.getList().addAll(getCrud().getNamedList("InquiryBidTerms.findAllTerms",Helper.getParamsHashByMerchant()));
        return super.getList(); 
    }
    
    

    @Override
    public void newRecord() throws InstantiationException, IllegalAccessException {
        super.newRecord();
        getInstance().setMerchant(merchant);
    }

    @Override
    public void save() {
        
        if(merchant!=null && merchant.getId()!=null && merchant.getId()>0){
            if(getInstance()!=null && getInstance().getMerchant()==null){
                getInstance().setMerchant(merchant);
            }            
        }    
        super.save(); 
    }
}
