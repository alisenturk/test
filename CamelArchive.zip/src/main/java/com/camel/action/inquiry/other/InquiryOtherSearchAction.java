package com.camel.action.inquiry.other;

import com.camel.action.base.CrudService;
import com.camel.entity.base.Department;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.User;
import com.camel.entity.customer.Customer;
import com.camel.entity.inquiry.other.InquiryOther;
import com.camel.entity.location.City;
import com.camel.entity.location.Country;
import com.camel.entity.location.Port;
import com.camel.enums.Constants;
import com.camel.enums.Continent;
import com.camel.enums.CustomerType;
import com.camel.enums.InquiryStatus;
import com.camel.util.Helper;
import com.camel.util.JSFHelper;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.event.ValueChangeEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named(value = "inquiryOtherSearch")
@ViewScoped
public class InquiryOtherSearchAction implements Serializable{
    
    @Inject
    CrudService crud;
        
    @Inject
    JSFHelper   jsfHelper;
    
    private List<User>          responsibles    = new ArrayList<User>();
    private List<Customer>      customers       = new ArrayList<Customer>();
    private List<InquiryOther>  inquiries       = new ArrayList<InquiryOther>();
    
    private List<Country>   loadingCountries    = new ArrayList<Country>();
    private List<City>      loadingCities       = new ArrayList<City>();
    private List<Port>      loadingPorts        = new ArrayList<Port>();
    
    private List<Country>   unloadingCountries  = new ArrayList<Country>();
    private List<City>      unloadingCities     = new ArrayList<City>();
    private List<Port>      unloadingPorts      = new ArrayList<Port>();
    
    
    
    private InquiryOther    inquiry = new InquiryOther();
    private String          inquiryCode;
    private User            responsible;    
    private CustomerType    customerType;
    private Customer        customer;
    private Date            requestBeginDate;
    private Date            requestEndDate;
    private Date            loadingBeginDate;
    private Date            loadingEndDate;
    private InquiryStatus   inquiryStatus;
    private Merchant        merchant = Helper.getCurrentUserMerchant();
    private boolean         pendingBid = false;
    private boolean         onlyBidOffer = false;
    private Department      currentUserDepartment;

    private Continent   loadingContinent;
    private Country     loadingCountry;
    private City        loadingCity;
    private Port        loadingPort;
    
    private Continent   unloadingContinent;
    private Country     unloadingCountry;
    private City        unloadingCity;
    private Port        unloadingPort;    
    
    
    
    @PostConstruct
    public void init(){
        if(loadingContinent!=null){
            loadCountries("edtContinent",loadingContinent);
        }
        if(unloadingContinent!=null){
            loadCountries("edtUnLoadContinent",unloadingContinent);
        }
    }
    
    public String getInquiryCode() {
        return inquiryCode;
    }

    public void setInquiryCode(String inquiryCode) {
        this.inquiryCode = inquiryCode;
    }

    public User getResponsible() {
        return responsible;
    }

    public void setResponsible(User responsible) {
        this.responsible = responsible;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public InquiryStatus getInquiryStatus() {
        return inquiryStatus;
    }

    public void setInquiryStatus(InquiryStatus inquiryStatus) {
        this.inquiryStatus = inquiryStatus;
    }
        
    public InquiryOther getInquiry() {
        return inquiry;
    }

    public void setInquiry(InquiryOther inquiry) {
        this.inquiry = inquiry;
    }
        
    public List<InquiryOther> getInquiries() {
        if(inquiries.isEmpty() && jsfHelper.getSessionValue(Constants.InquiryOtherSearchResult.getValue())!=null){
            inquiries = (List)jsfHelper.getSessionValue(Constants.InquiryOtherSearchResult.getValue());
        }
        return inquiries;
    }

    public void setInquiries(List<InquiryOther> inquiries) {
        this.inquiries = inquiries;
    }

    
    public CustomerType getCustomerType() {
        return customerType;
    }

    public void setCustomerType(CustomerType customerType) {
        this.customerType = customerType;
    }

    
    public Date getRequestBeginDate() {
        return requestBeginDate;
    }

    public void setRequestBeginDate(Date requestBeginDate) {
        this.requestBeginDate = requestBeginDate;
    }

    public Date getRequestEndDate() {
        return requestEndDate;
    }

    public void setRequestEndDate(Date requestEndDate) {
        this.requestEndDate = requestEndDate;
    }

    public Date getLoadingBeginDate() {
        return loadingBeginDate;
    }

    public void setLoadingBeginDate(Date loadingBeginDate) {
        this.loadingBeginDate = loadingBeginDate;
    }

    public Date getLoadingEndDate() {
        return loadingEndDate;
    }

    public void setLoadingEndDate(Date loadingEndDate) {
        this.loadingEndDate = loadingEndDate;
    }
           
    public List<User> getResponsibles() {
        if(responsibles.isEmpty()){
            responsibles.addAll(crud.getNamedList("User.findMerchantAllUsers",Helper.getParamsHashByMerchant()));
        }
        return responsibles;
    }

    public void setResponsibles(List<User> responsibles) {
        this.responsibles = responsibles;
    }

    public List<Customer> getCustomers() {
        if(customers.isEmpty()){
            customers.addAll(crud.getNamedList("Customer.findAll",Helper.getParamsHashByMerchant()));
        }
        return customers;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }

    public void loadCustomers(ValueChangeEvent event){
        customers = new ArrayList<Customer>();
        if(event!=null &&  event.getNewValue()!=null && ((customerType!=null && event.getNewValue()!=customerType) || customerType==null)){            
            
            customerType = (CustomerType)event.getNewValue();
            HashMap<String, Object> params = new HashMap<String,Object>();
            params.put("custType", customerType);            
            params.put("mrchntid",merchant.getId());
            customers.addAll(crud.getNamedList("Customer.findCustomersByType",params));
        }
    }
    public void searchInquiry(){
        inquiries = new ArrayList<InquiryOther>();
        
        try{   
            if(getCurrentUserDepartment().getCharter()){
                pendingBid = true;
            }
            jsfHelper.removeSessionValue(Constants.InquiryOtherSearchResult.getValue());
            InquiryOtherQuery query = new InquiryOtherQuery();            
            query.setInquiryCode(inquiryCode);
            query.setResponsible(responsible);
            query.setCustomerType(customerType);
            query.setCustomer(customer);
            query.setLoadingBeginDate(loadingBeginDate);
            query.setLoadingEndDate(loadingEndDate);
            query.setRequestBeginDate(requestBeginDate);
            query.setRequestEndDate(requestEndDate);
            query.setInquiryStatus(inquiryStatus);
            query.setMerchant(merchant);
            
            query.setLoadingCountry(loadingCountry);
            query.setLoadingCity(loadingCity);
            query.setLoadingPort(loadingPort);
            
            query.setUnloadingCountry(unloadingCountry);
            query.setUnloadingCity(unloadingCity);
            query.setUnloadingPort(unloadingPort);
            
            
            if(isPendingBid()){
                query.setPendingBid(pendingBid);
            }else{
                query.setPendingBid(null);
            }
            inquiries.addAll(crud.getList(query.getInqueryQuery(),query.getParams()));
            if(inquiries.size()>0){
                jsfHelper.setSessionValue(Constants.InquiryOtherSearchResult.getValue(),inquiries);
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    private void loadCountries(String componentId,Continent continent){
        Map<String,Object> params = new HashMap<>();
        params.put("cntnt", continent);

        if(componentId.equals("edtUnLoadContinent")){
            unloadingCountries.clear();
            unloadingCities.clear();
            unloadingCountries.addAll(getCrud().getNamedList("Country.findCountryByContinent", params));
        }else{
            loadingCountries.clear();
            loadingCities.clear();
            loadingCountries.addAll(getCrud().getNamedList("Country.findCountryByContinent", params));
        }
    }
    public void continentValueChange(ValueChangeEvent event){
        
        if(event.getNewValue()!=null){
            Continent continent = (Continent)event.getNewValue();
            loadCountries(event.getComponent().getId(),continent);            
        }       
    }
    private void loadCities(String componentId,Country country){
        Map<String,Object> params = new HashMap<>();
        params.put("country", country.getId());

        if(componentId.equals("unloadingCountrySelect")){
            unloadingCities.clear();
            unloadingCities.addAll(getCrud().getNamedList("City.findCountryCities", params));
            
            unloadingPorts.clear();
            unloadingPorts.addAll(getCrud().getNamedList("Port.findCountryPorts", params));
        }else{
            loadingCities.clear();
            loadingCities.addAll(getCrud().getNamedList("City.findCountryCities", params));
            
            loadingPorts.clear();
            loadingPorts.addAll(getCrud().getNamedList("Port.findCountryPorts", params));
        }
    }
    public void countryValueChange(ValueChangeEvent event){
        if(event.getNewValue()!=null){
            Country country = (Country)event.getNewValue();
            loadCities(event.getComponent().getId(), country);
        }
    }
    
    public boolean isPendingBid() {
        return pendingBid;
    }

    public void setPendingBid(boolean pendingBid) {
        this.pendingBid = pendingBid;
    }

    public Department getCurrentUserDepartment() {
        if(null==currentUserDepartment){
            currentUserDepartment = Helper.getCurrentUserDepartment();
        }
        return currentUserDepartment;
    }

    public void setCurrentUserDepartment(Department currentUserDepartment) {
        this.currentUserDepartment = currentUserDepartment;
    }

    public List<Country> getLoadingCountries() {
        return loadingCountries;
    }

    public void setLoadingCountries(List<Country> loadingCountries) {
        this.loadingCountries = loadingCountries;
    }

    public List<City> getLoadingCities() {
        return loadingCities;
    }

    public void setLoadingCities(List<City> loadingCities) {
        this.loadingCities = loadingCities;
    }

    public List<Port> getLoadingPorts() {
        return loadingPorts;
    }

    public void setLoadingPorts(List<Port> loadingPorts) {
        this.loadingPorts = loadingPorts;
    }

    public List<Country> getUnloadingCountries() {
        return unloadingCountries;
    }

    public void setUnloadingCountries(List<Country> unloadingCountries) {
        this.unloadingCountries = unloadingCountries;
    }

    public List<City> getUnloadingCities() {
        return unloadingCities;
    }

    public void setUnloadingCities(List<City> unloadingCities) {
        this.unloadingCities = unloadingCities;
    }

    public List<Port> getUnloadingPorts() {
        return unloadingPorts;
    }

    public void setUnloadingPorts(List<Port> unloadingPorts) {
        this.unloadingPorts = unloadingPorts;
    }

    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    public boolean isOnlyBidOffer() {
        return onlyBidOffer;
    }

    public void setOnlyBidOffer(boolean onlyBidOffer) {
        this.onlyBidOffer = onlyBidOffer;
    }

    public CrudService getCrud() {
        return crud;
    }

    public void setCrud(CrudService crud) {
        this.crud = crud;
    }

    public JSFHelper getJsfHelper() {
        return jsfHelper;
    }

    public void setJsfHelper(JSFHelper jsfHelper) {
        this.jsfHelper = jsfHelper;
    }

    public Continent getLoadingContinent() {
        return loadingContinent;
    }

    public void setLoadingContinent(Continent loadingContinent) {
        this.loadingContinent = loadingContinent;
    }

    public Country getLoadingCountry() {
        return loadingCountry;
    }

    public void setLoadingCountry(Country loadingCountry) {
        this.loadingCountry = loadingCountry;
    }

    public City getLoadingCity() {
        return loadingCity;
    }

    public void setLoadingCity(City loadingCity) {
        this.loadingCity = loadingCity;
    }

    public Port getLoadingPort() {
        return loadingPort;
    }

    public void setLoadingPort(Port loadingPort) {
        this.loadingPort = loadingPort;
    }

    public Continent getUnloadingContinent() {
        return unloadingContinent;
    }

    public void setUnloadingContinent(Continent unloadingContinent) {
        this.unloadingContinent = unloadingContinent;
    }

    public Country getUnloadingCountry() {
        return unloadingCountry;
    }

    public void setUnloadingCountry(Country unloadingCountry) {
        this.unloadingCountry = unloadingCountry;
    }

    public City getUnloadingCity() {
        return unloadingCity;
    }

    public void setUnloadingCity(City unloadingCity) {
        this.unloadingCity = unloadingCity;
    }

    public Port getUnloadingPort() {
        return unloadingPort;
    }

    public void setUnloadingPort(Port unloadingPort) {
        this.unloadingPort = unloadingPort;
    }

    
    
    
}
