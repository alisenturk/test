/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.inquiry;

import com.camel.action.base.BaseAction;
import com.camel.entity.inquiry.InquiryOffer;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named(value = "offerView")
@ViewScoped
public class OfferView extends BaseAction<InquiryOffer>{
    
}
