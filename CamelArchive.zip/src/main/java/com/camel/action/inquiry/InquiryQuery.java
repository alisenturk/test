/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.inquiry;

import com.camel.entity.base.Department;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.MerchantBranch;
import com.camel.entity.base.User;
import com.camel.entity.customer.Customer;
import com.camel.entity.location.City;
import com.camel.entity.location.Country;
import com.camel.entity.location.Port;
import com.camel.enums.Continent;
import com.camel.enums.CustomerType;
import com.camel.enums.InquiryStatus;
import com.camel.enums.MemberType;
import com.camel.enums.UserType;
import java.util.Date;
import java.util.HashMap;

/**
 *
 * @author asenturk
 */
public class InquiryQuery {
    private String          inquiryCode;
    private User            responsible;    
    private CustomerType    customerType;
    private Customer        customer;
    private Date            requestBeginDate;
    private Date            requestEndDate;
    private Date            loadingBeginDate;
    private Date            loadingEndDate;
    private Merchant        merchant;
    private InquiryStatus   inquiryStatus;
    private Boolean         pendingBid;
    private String          cargoTrackingNo;    

    private Continent loadContinent;  
    private Country   loadingCountry    ;
    private City      loadingCity      ;
    private Port      loadingPort        ;
    
    private Continent unloadContinent;
    private Country   unloadingCountry  ;
    private City      unloadingCity     ;
    private Port      unloadingPort      ;
    
    private Boolean   onlyBranchInquiries = true;
    
    private MerchantBranch  branch;
    private User            currentUser;
    private Long            inquiryId;
    private Department      department;
    private User            personnel;
    private User            exceptUser;
    private String          queryName;

    private HashMap<String,Object> params = new HashMap<String,Object>();
    
    public String getInquiryCode() {
        return inquiryCode;
    }

    public void setInquiryCode(String inquiryCode) {
        this.inquiryCode = inquiryCode;
    }

    public User getResponsible() {
        return responsible;
    }

    public void setResponsible(User responsible) {
        this.responsible = responsible;
    }

    public CustomerType getCustomerType() {
        return customerType;
    }

    public void setCustomerType(CustomerType customerType) {
        this.customerType = customerType;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getRequestBeginDate() {
        return requestBeginDate;
    }

    public void setRequestBeginDate(Date requestBeginDate) {
        this.requestBeginDate = requestBeginDate;
    }

    public Date getRequestEndDate() {
        return requestEndDate;
    }

    public void setRequestEndDate(Date requestEndDate) {
        this.requestEndDate = requestEndDate;
    }

    public Date getLoadingBeginDate() {
        return loadingBeginDate;
    }

    public void setLoadingBeginDate(Date loadingBeginDate) {
        this.loadingBeginDate = loadingBeginDate;
    }

    public Date getLoadingEndDate() {
        return loadingEndDate;
    }

    public void setLoadingEndDate(Date loadingEndDate) {
        this.loadingEndDate = loadingEndDate;
    }

    public InquiryStatus getInquiryStatus() {
        return inquiryStatus;
    }

    public void setInquiryStatus(InquiryStatus inquiryStatus) {
        this.inquiryStatus = inquiryStatus;
    }

    public String getCargoTrackingNo() {
        return cargoTrackingNo;
    }

    public void setCargoTrackingNo(String cargoTrackingNo) {
        this.cargoTrackingNo = cargoTrackingNo;
    }

    
    
    public static String getResponsibleInquiriesFromLoadingDate(boolean isInquiryStatusNull,boolean isInquiryTypesNull,MemberType memberType){
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT d FROM Inquiry d ");
        sql.append("WHERE ");
        sql.append("    d.merchant.id=:mrchntid and ");
        sql.append("    d.loadingDate>=:today ");
        sql.append(" AND ");

        sql.append("(");
        //sql.append("  d.responsible.id =:responsibleId ");
        //sql.append(" OR ");
        sql.append(" EXISTS( ");
        sql.append("    select itm from InquiryTeamMember itm ");
        sql.append("    where itm.inquiry.id = d.id and itm.member.id=:responsibleId and itm.status = 'ACTIVE' ");
        sql.append("    and itm.memberType = '").append(memberType.getKey()).append("' ");
        sql.append(" ) ");
        sql.append(")");
        
        if(!isInquiryTypesNull){
            sql.append("    and d.inquiryType IN (:inquiryTypes) ");
        }
        if(!isInquiryStatusNull){
            sql.append("    and d.inquiryStatus IN (:inquiryStatuses) ");
        }else{
            sql.append("    and d.inquiryStatus IN ('WAITINGFEEDBACK') ");
        }
        sql.append(" and d.status='ACTIVE' ");
        sql.append("ORDER BY d.loadingDate ");
        return sql.toString();
    }
    public static String getDepartmentInquiriesFromLoadingDate(boolean isInquiryStatusNull,boolean isInquiryTypesNull){
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT d FROM Inquiry d ");
        sql.append("WHERE ");
        sql.append("    d.merchant.id=:mrchntid and ");
        sql.append("    d.loadingDate>=:today ");
        sql.append("    and d.responsible.id !=:currentUserId ");
        sql.append("    and d.responsible.department.id =:departmentId ");
        if(!isInquiryTypesNull){
            sql.append("    and d.inquiryType IN (:inquiryTypes) ");
        }
        if(!isInquiryStatusNull){
            sql.append("    and d.inquiryStatus IN (:inquiryStatuses) ");
        }else{
            sql.append("    and d.inquiryStatus IN ('INPROGRESS','WAITINGFEEDBACK') ");
        }
        sql.append(" and d.status='ACTIVE' ");
        sql.append("ORDER BY d.loadingDate ");
        return sql.toString();
    }
    
    public static String getDepartmentInquiriesFromUnloadingDate(boolean isInquiryStatusNull,boolean isInquiryTypesNull){
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT d FROM Inquiry d ");
        sql.append("WHERE ");
        sql.append("    d.merchant.id=:mrchntid and ");
        sql.append("    d.unloadingDate>=:today ");
        sql.append("    and d.responsible.id !=:currentUserId ");
        sql.append("    and d.responsible.department.id =:departmentId ");
        if(!isInquiryTypesNull){
            sql.append("    and d.inquiryType IN (:inquiryTypes) ");
        }
        if(!isInquiryStatusNull){
            sql.append("    and d.inquiryStatus IN (:inquiryStatuses) ");
        }else{
            sql.append("    and d.inquiryStatus IN ('INPROGRESS','WAITINGFEEDBACK') ");
        }
        sql.append(" and d.status='ACTIVE' ");
        sql.append("ORDER BY d.loadingDate ");
        return sql.toString();
    }
    
    public static String getResponsibleInquiriesFromOfferDeadline(boolean isInquiryStatusNull,boolean isInquiryTypesNull,MemberType memberType){
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT d FROM Inquiry d ");
        sql.append("WHERE ");
        sql.append("    d.merchant.id=:mrchntid and ");
        //sql.append("    d.offerDeadline >=:today ");
        //sql.append("    and  ");
        sql.append("( ");
        //sql.append("  d.responsible.id =:responsibleId ");
        //sql.append(" OR ");
        sql.append(" EXISTS( ");
        sql.append("    select itm from InquiryTeamMember itm ");
        sql.append("    where itm.inquiry.id = d.id and itm.member.id=:responsibleId and itm.status = 'ACTIVE' ");
        sql.append("    and itm.memberType = '").append(memberType.getKey()).append("' ");
        sql.append(" ) ");
        sql.append(") ");
        if(!isInquiryTypesNull){
            sql.append("    and d.inquiryType IN (:inquiryTypes) ");
        }
        if(!isInquiryStatusNull){
            sql.append("    and d.inquiryStatus IN (:inquiryStatuses) ");
        }else{
            sql.append("    and d.inquiryStatus IN ('INPROGRESS') ");
        }
        sql.append("    and d.offerDeadline is not null ");
        sql.append("    and d.inquiryStatus = 'INPROGRESS' ");
        sql.append(" and d.status='ACTIVE' ");
        sql.append("ORDER BY d.offerDeadline ");
        return sql.toString();
    }
    public static String getResponsibleInquiriesFromToAct(boolean isInquiryStatusNull,boolean isInquiryTypesNull,MemberType memberType){
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT d FROM Inquiry d ");
        sql.append("WHERE ");
        sql.append("    d.merchant.id=:mrchntid and ");
        sql.append("    d.loadingDate >=:today ");
        sql.append("    and  ");
        sql.append("(");
        //sql.append("  d.responsible.id =:responsibleId ");
        //sql.append(" OR ");
        sql.append(" EXISTS( ");
        sql.append("    select itm from InquiryTeamMember itm ");
        sql.append("    where itm.inquiry.id = d.id and itm.member.id=:responsibleId and itm.status = 'ACTIVE' ");
        sql.append("    and itm.memberType = '").append(memberType.getKey()).append("' ");
        sql.append(" ) ");
        sql.append(")");
        if(!isInquiryTypesNull){
            sql.append("    and d.inquiryType IN (:inquiryTypes) ");
        }
        if(!isInquiryStatusNull){
            sql.append("    and d.inquiryStatus IN (:inquiryStatuses) ");
        }else{
            sql.append("    and d.inquiryStatus IN ('ACCEPTED') ");
        }
        sql.append("    and d.loadingDate is not null ");
        sql.append(" and d.status='ACTIVE' ");
        sql.append("ORDER BY d.loadingDate ");
        return sql.toString();
    }
    public static String getDepartmentInquiriesFromOfferDeadline(boolean isInquiryStatusNull,boolean isInquiryTypesNull,MemberType memberType){
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT d FROM Inquiry d ");
        sql.append("WHERE ");
        sql.append("    d.merchant.id=:mrchntid and ");
        sql.append("    d.responsible.department.id =:departmentId ");
        sql.append("    and d.responsible.id !=:currentUserId ");
        if(!isInquiryTypesNull){
            sql.append("    and d.inquiryType IN (:inquiryTypes) ");
        }
        if(!isInquiryStatusNull){
            sql.append("    and d.inquiryStatus IN (:inquiryStatuses) ");
        }
        sql.append("    and d.inquiryStatus = 'INPROGRESS' ");
        sql.append("    and d.offerDeadline is not null ");
        //sql.append("    and d.offerDeadline >=:today ");
        sql.append(" and d.status='ACTIVE' ");
        sql.append("ORDER BY d.offerDeadline ");
        return sql.toString();
    }
    
    public String getInqueryQuery(){
        StringBuffer sql = new StringBuffer();
        try{
            boolean where = false;
            sql.append("SELECT d FROM Inquiry d ");
            if(inquiryId!=null && inquiryId.longValue()>0){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.id=:inquiryid ");
            }
            if(merchant!=null && merchant.getId()!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.merchant.id=:mrchntid ");
            }
            if(inquiryCode!=null && inquiryCode.length()>3){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.inquiryCode =:inqCode ");
            }
            if(responsible!=null && responsible.getId()>0){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.responsible.id =:responsibleId ");
            }
            if(customerType!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.customer.customerType =:customerTypeKey ");
            }
            if(customer!=null && customer.getId()>0){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.customer.id =:customerId ");
            }
            if(requestBeginDate!=null && requestEndDate!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" ( d.requestDate BETWEEN :requestBeginDate AND :requestEndDate ) ");
            }
            if(loadingBeginDate!=null && loadingEndDate!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" (d.loadingDate BETWEEN :loadingBeginDate AND :loadingEndDate ) ");
            }
            if(inquiryStatus!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.inquiryStatus =:inquiryStatusKey ");
            }
            if(pendingBid!=null && pendingBid){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" ( ");
            	sql.append("    select count(b) from InquiryBid b where b.inquiry.id = d.id and b.status = 'ACTIVE' ");
                sql.append(" )>0  ");
            }
            
            if(loadingCountry!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.loadingCountry.id=:loadingCountryId ");
            }
            
            if(loadingCity!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.loadingCity.id=:loadingCityId ");
            }
            if(loadingPort!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.loadingPort.id=:loadingPortId ");
            }
            if(unloadingCountry!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.unloadingCountry.id=:unloadingCountryId ");
            }
            if(unloadingCity!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.unloadingCity.id=:unloadingCityId ");
            }
            if(unloadingPort!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.unloadingPort.id=:unloadingPortId ");
            }
            
            if(loadingCountry==null && loadContinent!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.loadingCountry.continet=:loadCntnt ");
            }
            if(unloadingCountry==null && unloadContinent!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.unloadingCountry.continet=:unloadCntnt ");
            }
            /** Sadece aynı branch'teki kişiler  veya aynı takımdaki kişiler bir birlerinin kayıtları görebilir
             *  Admin tipindeki kullanıcılar tüm kayıtları görebilir.
             **/
            if(branch!=null && currentUser!=null && !currentUser.getUserType().equals(UserType.ADMIN) && onlyBranchInquiries!=null && onlyBranchInquiries.booleanValue()){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" (d.branch.id=:branchId ");
                sql.append(" OR EXISTS( ");
            	sql.append("    select itm from InquiryTeamMember itm where itm.inquiry.id = d.id and itm.member.id=:currentUserId and itm.status = 'ACTIVE' ");
                sql.append(" )) ");
            }
            
            if(where){
                sql.append(" AND ");
            }else{
                sql.append(" WHERE ");
                where = true;
            }
            sql.append(" d.status = 'ACTIVE' ");
            
        }catch(Exception e){
            e.printStackTrace();
        }    
        
        return sql.toString();          
        
    }

    public HashMap<String, Object> getParams() {
        params = new HashMap<String,Object>();
        if(merchant!=null && merchant.getId()!=null){
            params.put("mrchntid",merchant.getId());
        }
        if(inquiryCode!=null && inquiryCode.length()>3){
            params.put("inqCode",inquiryCode);
        }
        if(responsible!=null){
            params.put("responsibleId",responsible.getId());
        }
        if(customerType!=null){
            params.put("customerTypeKey",customerType.getKey());
        }
        if(customer!=null){
            params.put("customerId",customer.getId());
        }
        if(requestBeginDate!=null){
            params.put("requestBeginDate",requestBeginDate);
        }
        if(requestEndDate!=null){
            params.put("requestEndDate",requestEndDate);
        }
        if(loadingBeginDate!=null){
            params.put("loadingBeginDate",loadingBeginDate);
        }
        if(loadingEndDate!=null){
            params.put("loadingEndDate",loadingEndDate);
        }
        if(inquiryStatus!=null){
            params.put("inquiryStatusKey",inquiryStatus);
        }   
        if(loadingCountry!=null){
           params.put("loadingCountryId",loadingCountry.getId());
        }

        if(loadingCity!=null){
           params.put("loadingCityId",loadingCity.getId());
        }
        if(loadingPort!=null){
            params.put("loadingPortId",loadingPort.getId());
        }
        if(unloadingCountry!=null){
           params.put("unloadingCountryId", unloadingCountry.getId());
        }
        if(unloadingCity!=null){
            params.put("unloadingCityId", unloadingCity.getId());
        }
        if(unloadingPort!=null){
            params.put("unloadingPortId", unloadingPort.getId());
        }

        if(loadingCountry==null && loadContinent!=null){
            params.put("loadCntnt",loadContinent);
        }
        if(unloadingCountry==null && unloadContinent!=null){
            params.put("unloadCntnt",unloadContinent);
        }
        
        if(inquiryId!=null && inquiryId.longValue()>0){
            params.put("inquiryid", inquiryId);
        }
        if(branch!=null && currentUser!=null && !currentUser.getUserType().equals(UserType.ADMIN) && onlyBranchInquiries!=null && onlyBranchInquiries){
            params.put("branchId",branch.getId());
            
            params.put("currentUserId", currentUser.getId());
            
        }
        if(department!=null){
            params.put("departmentid",department.getId());
        }

        if(personnel!=null){
            params.put("personnelId",personnel.getId());
        }
        if(exceptUser!=null){
            params.put("exceptUserId",exceptUser.getId());
        }
        if((queryName==null || !queryName.equals("InqSearchListQuery")) && branch!=null && branch.getId()>0){
            params.put("branchId",branch.getId());
        }
        return params;
    }

    public void setParams(HashMap<String, Object> params) {
        this.params = params;
    }

    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    public Boolean getPendingBid() {
        return pendingBid;
    }

    public void setPendingBid(Boolean pendingBid) {
        this.pendingBid = pendingBid;
    }

    public Country getLoadingCountry() {
        return loadingCountry;
    }

    public void setLoadingCountry(Country loadingCountry) {
        this.loadingCountry = loadingCountry;
    }

    public City getLoadingCity() {
        return loadingCity;
    }

    public void setLoadingCity(City loadingCity) {
        this.loadingCity = loadingCity;
    }

    public Port getLoadingPort() {
        return loadingPort;
    }

    public void setLoadingPort(Port loadingPort) {
        this.loadingPort = loadingPort;
    }

    public Country getUnloadingCountry() {
        return unloadingCountry;
    }

    public void setUnloadingCountry(Country unloadingCountry) {
        this.unloadingCountry = unloadingCountry;
    }

    public City getUnloadingCity() {
        return unloadingCity;
    }

    public void setUnloadingCity(City unloadingCity) {
        this.unloadingCity = unloadingCity;
    }

    public Port getUnloadingPort() {
        return unloadingPort;
    }

    public void setUnloadingPort(Port unloadingPort) {
        this.unloadingPort = unloadingPort;
    }

    public Continent getLoadContinent() {
        return loadContinent;
    }

    public void setLoadContinent(Continent loadContinent) {
        this.loadContinent = loadContinent;
    }

    public Continent getUnloadContinent() {
        return unloadContinent;
    }

    public void setUnloadContinent(Continent unloadContinent) {
        this.unloadContinent = unloadContinent;
    }

    public Boolean getOnlyBranchInquiries() {
        return onlyBranchInquiries;
    }

    public void setOnlyBranchInquiries(Boolean onlyBranchInquiries) {
        this.onlyBranchInquiries = onlyBranchInquiries;
    }

    public MerchantBranch getBranch() {
        return branch;
    }

    public void setBranch(MerchantBranch branch) {
        this.branch = branch;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }

    public Long getInquiryId() {
        return inquiryId;
    }

    public void setInquiryId(Long inquiryId) {
        this.inquiryId = inquiryId;
    }



    public String getInqueryPersonnelPerformanceQuery(){
        StringBuffer sql = new StringBuffer();
        try{
            boolean where = false;
            sql.append("SELECT SUM(d.offerValue),COUNT(d.id) FROM Inquiry d ");

            if(merchant!=null && merchant.getId()!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.merchant.id=:mrchntid ");
            }
            if(branch!=null && branch.getId()!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.branch.id=:branchId ");
            }
            if(department!=null && department.getId()!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.department.id=:departmentid ");
            }
            if(requestBeginDate!=null && requestEndDate!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" ( d.requestDate BETWEEN :requestBeginDate AND :requestEndDate ) ");
            }

            if(personnel!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append("  EXISTS( ");
                sql.append("    select itm from InquiryTeamMember itm where itm.inquiry.id = d.id and itm.member.id=:personnelId and itm.status = 'ACTIVE' ");
                sql.append(" ) ");
            }
            if(exceptUser!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append("  NOT EXISTS( ");
                sql.append("    select itm from InquiryTeamMember itm where itm.inquiry.id = d.id and itm.member.id=:exceptUserId and itm.status = 'ACTIVE' ");
                sql.append(" ) ");
            }

            if(where){
                sql.append(" AND ");
            }else{
                sql.append(" WHERE ");
                where = true;
            }
            sql.append(" d.status = 'ACTIVE' ");

        }catch(Exception e){
            e.printStackTrace();
        }

        return sql.toString();

    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public User getPersonnel() {
        return personnel;
    }

    public void setPersonnel(User personnel) {
        this.personnel = personnel;
    }

    public User getExceptUser() {
        return exceptUser;
    }

    public void setExceptUser(User exceptUser) {
        this.exceptUser = exceptUser;
    }

    public String getQueryName() {
        return queryName;
    }

    public void setQueryName(String queryName) {
        this.queryName = queryName;
    }

    public String getUpdatebleInquiryQuery(){
        StringBuffer sql = new StringBuffer();
        sql.append("select inq.id from inquiry inq ");
        sql.append("where ");
        sql.append("    inq.id = " + inquiryId);
        sql.append("    and ");
        sql.append("    ( ");
        sql.append("        inq.responsible_id= " + currentUser.getId());
        sql.append("        OR ");
        sql.append("        exists(select u.id from ");
        sql.append("    user u ");
        sql.append("    JOIN user_userauth uua ON u.id = uua.user_id ");
        sql.append("    JOIN userauth ua ON uua.userAuths_id = ua.id ");
        sql.append("    where ");
        sql.append("        u.id =  " + currentUser.getId());
        sql.append("        and ");
        sql.append("                        ( ");
        sql.append("                 u.userType='ADMIN' ");
        sql.append("                            or u.memberAdmin = true ");
        sql.append("                            or ua.authcode IN ('ROLE_ADMIN') ");
        sql.append("                    ) ");
        sql.append("    ) ");
        sql.append("    OR ");
        sql.append("    exists( ");
        sql.append("            select itm.id from inquiryteammember itm where itm.inquiry_id=inq.id and itm.member_id="+currentUser.getId()+" and itm.memberType='OWNER' ");
        sql.append("        ) ");
        sql.append("    ) ");

        return sql.toString();
    }
}
