package com.camel.action.inquiry;

import com.camel.action.base.BaseAction;
import com.camel.entity.inquiry.InquiryBid;
import com.camel.entity.inquiry.InquiryBidOffer;
import com.camel.entity.inquiry.InquiryBidTerms;
import com.camel.enums.InquiryBidOfferStatus;
import com.camel.enums.Status;
import com.camel.util.Helper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author alisenturk
 */
@Named(value = "inquiryBidAction")
@ViewScoped
public class InquiryBidAction extends BaseAction<InquiryBid>{
    
    private List<InquiryBidTerms> termsList = new ArrayList<>();
    private boolean onlyBid = false;
    private InquiryBidOffer currentOffer;
    
    private List<InquiryBidOffer> bidOffers = new ArrayList<>();
    
    public List<InquiryBidTerms> getTermsList() {
        if(termsList.isEmpty()){
            termsList.addAll(getCrud().getNamedList("InquiryBidTerms.findAllTerms",Helper.getParamsHashByMerchant()));
        }
        return termsList;
    }

    public void setTermsList(List<InquiryBidTerms> termsList) {
        this.termsList = termsList;
    }

    @Override
    public void save() {
        try{
            if(getInstance().isManaged()){
                getCrud().updateObject(getInstance());
                Helper.addMessage(Helper.getMessage("Global.Record.Updated"));
            }else{
                getCrud().createObject(getInstance());
                Helper.addMessage(Helper.getMessage("Global.Record.Added"));
            }
        }catch(Exception e){
            Helper.addMessage("HATA..:" + e.getMessage());
        }
    }
    
    public void createNewOffer(){
        currentOffer = new InquiryBidOffer();
        currentOffer.setInquiryBid(getInstance());
        currentOffer.setStatus(Status.ACTIVE);
        currentOffer.setOfferStatus(InquiryBidOfferStatus.NEW);
        currentOffer.setTargetBulkType(getInstance().getTargetBulkType());
        currentOffer.setTargetCurrency(getInstance().getTargetCurrency());
    }
    
    public void saveOffer(){
        
        if(currentOffer.isManaged()){
            getCrud().updateObject(currentOffer);
            Helper.addMessage(Helper.getMessage("Global.Record.Updated"));
        }else{
            getCrud().createObject(currentOffer);
            Helper.addMessage(Helper.getMessage("Global.Record.Added"));
        }
        createNewOffer();
        bidOffers.clear();
    }
    
    public void loadBidOfferList(){
        
        if(getInstance().isManaged()){
            Map<String,Object> params = new HashMap<>();
            params.put("bidid",getInstance().getId());
            List<InquiryBidOffer> tempList = getCrud().getNamedList("InquiryBidOffer.findAll", params);
            if(null!=tempList && !tempList.isEmpty())
                bidOffers.addAll(tempList);
        }
        if(null==bidOffers)bidOffers=new ArrayList<>();
    }
    
    public boolean isOnlyBid() {
        return onlyBid;
    }

    public void setOnlyBid(boolean onlyBid) {
        this.onlyBid = onlyBid;
    }

    public InquiryBidOffer getCurrentOffer() {
        if(null==currentOffer){
            createNewOffer();
        }
        return currentOffer;
    }

    public void setCurrentOffer(InquiryBidOffer currentOffer) {
        this.currentOffer = currentOffer;
    }

    public List<InquiryBidOffer> getBidOffers() {
        if(bidOffers.isEmpty()){
            loadBidOfferList();
        }
        return bidOffers;
    }

    public void setBidOffers(List<InquiryBidOffer> bidOffers) {
        this.bidOffers = bidOffers;
    }
    
    
    
    
}
