package com.camel.action.inquiry;

import com.camel.action.base.BaseAction;
import com.camel.entity.base.MerchantFile;
import com.camel.entity.base.OfferTemplate;
import com.camel.entity.inquiry.Inquiry;
import com.camel.entity.inquiry.InquiryOffer;
import com.camel.enums.Status;
import com.camel.util.Helper;
import com.camel.util.JSFHelper;
import com.camel.util.WordDocReader;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.faces.event.ValueChangeEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.model.StreamedContent;

/**
 *
 * @author asenturk
 */
@Named(value = "inquiryOffer")
@ViewScoped
public class InquiryOfferAction extends BaseAction<InquiryOffer>{
    
    
    @Inject
    JSFHelper jsfHelper;
    
    
    private List<OfferTemplate> offerTemplates  = new ArrayList<OfferTemplate>();
    private List<InquiryOffer>  inquiryOffers   = new ArrayList<InquiryOffer>();
    
    private Inquiry     inquery;

    private InquiryOffer    currentOffer;
    
    public List<OfferTemplate> getOfferTemplates() {
        if(offerTemplates.isEmpty()){
            offerTemplates.addAll(getCrud().getNamedList("OfferTemplate.findAllMerchantOfferTemplates",Helper.getParamsHashByMerchant()));
        }
        return offerTemplates;
    }

    public void setOfferTemplates(List<OfferTemplate> offerTemplates) {
        this.offerTemplates = offerTemplates;
    }

    public List<InquiryOffer> getInquiryOffers() {
        if(getInquery()!=null && getInquery().isManaged() && inquiryOffers.isEmpty()){
            HashMap<String,Object> offerMap = new HashMap<String,Object>();
            offerMap.put("inqryid",getInquery().getId());
            inquiryOffers.addAll(getCrud().getNamedList("InquiryOffer.findAll",offerMap));
        }
        return inquiryOffers;
    }

    public void setInquiryOffers(List<InquiryOffer> inquiryOffers) {
        this.inquiryOffers = inquiryOffers;
    }
    
    public Inquiry getInquery() {
        return inquery;
    }

    public void setInquery(Inquiry inquery) {
        this.inquery = inquery;
    }

    public InquiryOffer getCurrentOffer() {
        if(currentOffer==null)
            currentOffer = getInstance();
        return currentOffer;
    }

    public void setCurrentOffer(InquiryOffer currentOffer) {
        
        this.currentOffer = currentOffer;
        setInstance(currentOffer);
    }
    
    @Override
    public void save() {
       
        try{
            if(currentOffer.isManaged()){
                getCrud().updateObject(currentOffer);
                Helper.addMessage(Helper.getMessage("Global.Record.Updated"));
            }else{
                getCrud().createObject(getInstance());
                Helper.addMessage(Helper.getMessage("Global.Record.Added"));
            }
            if(currentOffer.getStatus().equals(Status.ACTIVE)){
                getInquery().setOfferDate(currentOffer.getOfferDate());
                getInquery().setOfferDeadline(currentOffer.getOfferValidityDate());
                getCrud().updateObject(getInquery());
            }
            if(currentOffer.getStatus().equals(Status.ACTIVE)){
                String sql = "UPDATE InquiryOffer SET status='PASSIVE' WHERE id <> "+ currentOffer.getId() +" AND inquiry.id=" + getInquery().getId() + " AND status = 'ACTIVE' ";
                getCrud().updateQuery(sql);
            }
            setCurrentOffer(new InquiryOffer());
            currentOffer.setInquiry(getInquery());
            currentOffer.setStatus(Status.ACTIVE);
            inquiryOffers.clear();
        }catch(Exception e){
            e.printStackTrace();
            Helper.addMessage("HATA..:" + e.getMessage());
        }
        
    }
    
    public void offerTemplateValueChange(ValueChangeEvent event){
        if(event!=null && event.getNewValue()!=null && currentOffer!=null){
            OfferTemplate ot = (OfferTemplate)event.getNewValue();
            currentOffer.setOfferContent(ot.getContent());
        }
    }
    
    public StreamedContent offerDownload(InquiryOffer offer){
        List<MerchantFile> files =  getCrud().getNamedList("MerchantFile.findMerchantCustomerOfferFile",Helper.getParamsHashByMerchant());
        if(files!=null && files.size()>0){
            MerchantFile mf = files.get(0);
            try{
                File source = new File(mf.getFilePath());
                String content = offer.getOfferContent();
                

                String fileName = "offer_"+getInquery().getInquiryCode()+"_"+offer.getId()+"."+mf.getFileType().toLowerCase();
                File newFile = new File(fileName);

                WordDocReader wdr = new WordDocReader();
                newFile = wdr.readWordDoc(mf.getFilePath(),newFile,content);
                
                return jsfHelper.fileDownload(newFile,mf.getFileMimeType(), fileName);
            }catch(Exception e){
               // e.printStackTrace();
            }
        }
        return null;
    }
    
}
