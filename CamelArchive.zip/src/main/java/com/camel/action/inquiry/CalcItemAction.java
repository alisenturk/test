/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.inquiry;

import com.camel.action.base.BaseAction;
import com.camel.entity.base.Merchant;
import com.camel.entity.inquiry.CalcItem;
import com.camel.util.Helper;
import java.util.List;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named(value = "calcItemAction")
@ViewScoped
public class CalcItemAction extends BaseAction<CalcItem>{
    
    private Merchant merchant = Helper.getCurrentUserMerchant();
    
    @Override
    public List<CalcItem> getList() {
        if(super.getList().isEmpty()){
           super.getList().addAll(getCrud().getNamedList("CalcItem.findAll", Helper.getParamsHashByMerchant()));
        }    
        return super.getList(); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    
    @Override
    public void save() {
        if(!getInstance().isManaged()){
            getInstance().setMerchant(merchant);
        }
        super.save(); 
    }

    @Override
    public void newRecord() throws InstantiationException, IllegalAccessException {
        super.newRecord(); 
        getInstance().setMerchant(merchant);
    }
    
    
}
