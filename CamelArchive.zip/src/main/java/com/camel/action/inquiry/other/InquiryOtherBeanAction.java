package com.camel.action.inquiry.other;

import com.camel.action.base.BaseAction;
import com.camel.action.base.Enums;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.User;
import com.camel.entity.customer.Contact;
import com.camel.entity.customer.Customer;
import com.camel.entity.inquiry.Inquiry;
import com.camel.entity.inquiry.InquiryBid;
import com.camel.entity.inquiry.InquiryCalc;
import com.camel.entity.inquiry.InquiryFile;
import com.camel.entity.inquiry.InquiryOffer;
import com.camel.entity.inquiry.other.InquiryOther;
import com.camel.entity.inquiry.other.InquiryOtherFile;
import com.camel.entity.location.City;
import com.camel.entity.location.Country;
import com.camel.entity.location.Port;
import com.camel.enums.BidMode;
import com.camel.enums.CustomerType;
import com.camel.enums.DeckOption;
import com.camel.enums.InquiryFileType;
import com.camel.enums.InquirySource;
import com.camel.enums.InquiryType;
import com.camel.enums.Stackability;
import com.camel.enums.Status;
import com.camel.enums.TransportMode;
import com.camel.servlet.FileDownload;
import com.camel.util.Helper;
import com.google.gson.Gson;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.apache.commons.io.FilenameUtils;
import org.omnifaces.cdi.Param;
import org.omnifaces.cdi.param.ParamValue;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

/**
 *
 * @author asenturk
 */
@Named(value = "inquiryOther")
@ViewScoped
public class InquiryOtherBeanAction extends BaseAction<InquiryOther>{
            
    @Inject
    Enums enums;
    
    
    @Inject
    @Param(required = false)
    private ParamValue<String> processParam ;
    
    private List<User>              responsibles    = new ArrayList<User>();
    private List<Customer>          customers       = new ArrayList<Customer>();
    private List<Contact>           inquiryOwners   = new ArrayList<Contact>();
    private List<Country>           countries       = new ArrayList<Country>();
    private List<City>              loadingCities   = new ArrayList<City>();
    private List<City>              unloadingCities = new ArrayList<City>();
    private List<Port>              loadingPorts    = new ArrayList<Port>();
    private List<Port>              unloadingPorts  = new ArrayList<Port>();
    private List<InquiryOtherFile>  inquiryFiles    = new ArrayList<InquiryOtherFile>();
    
    
    private CustomerType    customerType;
    private SelectItem[]    inquirySourceSelect;
    private boolean         renderLoadingPort   = false;
    private SelectItem[]    inquiryStatus       = null;
    private boolean         loadingDateRequired = true;
    private Merchant        merchant            = Helper.getCurrentUserMerchant();
    private User            currentUser         = Helper.getCurrentUserFromSession();
    private boolean         transportRequired   = true;
    private boolean         updatable           = true;
    private InquiryFile     currentInqFile;
    private InquiryFileType inqFileType = InquiryFileType.OTHER;
    private String          previewFilePath="";
    
    
    public List<User> getResponsibles() {
        if(responsibles.isEmpty()){
            responsibles.addAll(getCrud().getNamedList("User.findMerchantAllUsers",Helper.getParamsHashByMerchant()));
        }
        return responsibles;
    }

    public void setResponsibles(List<User> responsibles) {
        this.responsibles = responsibles;
    }

    public List<Customer> getCustomers() {
        if(customers.isEmpty()){
            customers.addAll(getCrud().getNamedList("Customer.findAll",Helper.getParamsHashByMerchant()));
        }
        return customers;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }

    public CustomerType getCustomerType() {
        return customerType;
    }

    public void setCustomerType(CustomerType customerType) {
        this.customerType = customerType;
    }
    
    public void customerValueChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=getInstance().getCustomer()){            
            loadInquirySource(((Customer)event.getNewValue()).getCustomerType());
        }
    }
    private void loadInquirySource(CustomerType customerType){
        inquiryOwners = new ArrayList<Contact>(); 
        if(customerType.equals(CustomerType.AGENT)){
            inquirySourceSelect = new SelectItem[1];                
            inquirySourceSelect[0] = new SelectItem(InquirySource.AGENT.getKey(),InquirySource.AGENT.getValue());
        }else{
            inquirySourceSelect = new SelectItem[2];                
            inquirySourceSelect[0] = new SelectItem(InquirySource.OWN.getKey(),InquirySource.OWN.getValue());
            inquirySourceSelect[1] = new SelectItem(InquirySource.SALES.getKey(),InquirySource.SALES.getValue());
        }
    }
    
    public SelectItem[] getInquirySourceSelect() {
        if(inquirySourceSelect==null){
            inquirySourceSelect = new SelectItem[InquirySource.values().length];
            int i = 0;
            for (InquirySource s :InquirySource.values()) {
                inquirySourceSelect[i++] = new SelectItem(s.getKey(),s.getValue());
            }
        }
        return inquirySourceSelect;
    }

    public void setInquirySourceSelect(SelectItem[] inquirySourceSelect) {
        this.inquirySourceSelect = inquirySourceSelect;
    }

    public void inquirySourceValueChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=getInstance().getInquirySource()){            
            loadInquiryOwners(((InquirySource)event.getNewValue()));
        }
    }
    private void loadInquiryOwners(InquirySource source){
        inquiryOwners = new ArrayList<Contact>();
        if(source.equals(InquirySource.SALES)){
            inquiryOwners.addAll(getCrud().getNamedList("Contact.findMerchantSalesTeam",Helper.getParamsHashByMerchant()));
        }else if(getInstance().getCustomer()!=null){
           HashMap<String, Object> params = new HashMap<String,Object>();
           params.put("custid", getInstance().getCustomer().getId());
           params.put("mrchntid",merchant.getId());
           inquiryOwners.addAll(getCrud().getNamedList("Contact.findCustomerContacts", params));
        }
    }
    public List<Contact> getInquiryOwners() {
        return inquiryOwners;
    }

    public void setInquiryOwners(List<Contact> inquiryOwners) {
        this.inquiryOwners = inquiryOwners;
    }

    public List<Country> getCountries() {
        if(countries.isEmpty()){
            countries.addAll(getCrud().getNamedList("Country.findAll"));
        }
        return countries;
    }

    public void setCountries(List<Country> countries) {
        this.countries = countries;
    }

    public List<City> getLoadingCities() {
        return loadingCities;
    }

    public void setLoadingCities(List<City> loadingCities) {
        this.loadingCities = loadingCities;
    }

    public List<City> getUnloadingCities() {
        return unloadingCities;
    }

    public void setUnloadingCities(List<City> unloadingCities) {
        this.unloadingCities = unloadingCities;
    }

    public List<Port> getLoadingPorts() {
        return loadingPorts;
    }

    public void setLoadingPorts(List<Port> loadingPorts) {
        this.loadingPorts = loadingPorts;
    }

    public List<Port> getUnloadingPorts() {
        return unloadingPorts;
    }

    public void setUnloadingPorts(List<Port> unloadingPorts) {
        this.unloadingPorts = unloadingPorts;
    }
    
    public void loadingCountryValueChange(ValueChangeEvent event){
        try{
            if(event!=null &&  event.getNewValue()!=null && !event.getNewValue().equals(getInstance().getLoadingCountry())){            
                loadingCitiesAndPorts((Country)event.getNewValue());
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    private void loadingCitiesAndPorts(Country country){
        loadingCities   = new ArrayList<City>();
        loadingPorts    = new ArrayList<Port>();
        HashMap<String, Object> params = new HashMap<String,Object>();
        params.put("country", country.getId());
        loadingCities.addAll(getCrud().getNamedList("City.findCountryCities", params));
        loadingPorts.addAll(getCrud().getNamedList("Port.findCountryPorts",params));
    }
    
    public void unloadingCountryValueChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=getInstance().getUnloadingCountry()){            
            unloadingCitiesAndPorts((Country)event.getNewValue());
        }
    }
    
    private void unloadingCitiesAndPorts(Country country){
        unloadingCities   = new ArrayList<City>();
        unloadingPorts    = new ArrayList<Port>();
        HashMap<String, Object> params = new HashMap<String,Object>();
        params.put("country",country.getId());
        unloadingCities.addAll(getCrud().getNamedList("City.findCountryCities", params));
        unloadingPorts.addAll(getCrud().getNamedList("Port.findCountryPorts",params));
    }
    
    @PostConstruct
    private void postLoad(){
        if(getInstance()!=null && getInstance().getId()!=null && getInstance().getId()>0){
            if(getInstance().getLoadingCountry()!=null){
                loadingCitiesAndPorts(getInstance().getLoadingCountry());                
            }
            if(getInstance().getUnloadingCountry()!=null){
                unloadingCitiesAndPorts(getInstance().getUnloadingCountry());
            }
            if(getInstance().getInquirySource()!=null){
                loadInquiryOwners(getInstance().getInquirySource());
            }
            if(getInstance().getTransportMode()!=null){
                renderLoadingPort(getInstance().getTransportMode());
            }
            
            checkTransporRequird(getInstance().getTransportMode());
        }else{
            
            getInstance().setRequestDate(new Date());
            getInstance().setOfferDate(new Date());
            getInstance().setResponsible(currentUser);
            getInstance().setInquirySource(InquirySource.SALES);
        }
    }

    private void checkTransporRequird(TransportMode tm){
        transportRequired = true;
        if(!tm.equals(TransportMode.LAND)){
            transportRequired = false;
        }
    }
    public void transportModeValueChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=getInstance().getTransportMode()){            
            renderLoadingPort((TransportMode)event.getNewValue());

            TransportMode tm = (TransportMode)event.getNewValue();
            checkTransporRequird(tm);
        }
    }
    
    public boolean isRenderLoadingPort() {
        return renderLoadingPort;
    }

    public void setRenderLoadingPort(boolean renderLoadingPort) {
        this.renderLoadingPort = renderLoadingPort;
    }
    
    private void renderLoadingPort(TransportMode tm){
        if(tm!=null && 
           (tm.equals(TransportMode.OCEAN) || tm.equals(TransportMode.CONTAINER))){
            renderLoadingPort = true;
        }else{
            renderLoadingPort = false;
        }
    }

    @Override
    public void save(){
        try{
            String errorMessage = "";
            if(getInstance().getLoadingDate()!=null && getInstance().getUnloadingDate()!=null){
                double diff = Helper.dateDifferent(getInstance().getLoadingDate(),getInstance().getUnloadingDate(),Calendar.DATE);
                if(diff<0){
                    errorMessage = Helper.getMessage("Inquiry.Unloading.LoadingDiff");
                }
            }
            if(errorMessage.length()>3){
                Helper.addMessage(errorMessage,FacesMessage.SEVERITY_ERROR);
            }else{
                if(getInstance().getMerchant()==null){
                    getInstance().setMerchant(merchant);
                }
                if(getInstance().isManaged()){
                    if(getInstance().getInquiryCode()==null){
                        getInstance().setInquiryCode("INQ" + getInstance().getId());
                    }
                    getCrud().updateObject(getInstance());

                    Helper.addMessage(Helper.getMessage("Global.Record.Updated"));
                }else{
                    getCrud().createObject(getInstance());
                    getInstance().setInquiryCode("INQ" + getInstance().getId());
                    getCrud().updateObject(getInstance());
                    Helper.addMessage(Helper.getMessage("Global.Record.Added"));

                }
                super.setList(new ArrayList<InquiryOther>());
            }
        }catch(Exception e){
            Helper.addMessage("HATA..:" + e.getMessage());
        }
    }

    public SelectItem[] getInquiryStatus() {
        if(inquiryStatus==null){
            inquiryStatus = enums.getInquiryStatusSelect();
        }
        return inquiryStatus;
    }

    public void setInquiryStatus(SelectItem[] inquiryStatus) {
        this.inquiryStatus = inquiryStatus;
    }
    public void renderInquiryStatus(InquiryType inqType){
        if(inqType.equals(InquiryType.FIRM)){
            inquiryStatus = new SelectItem[enums.getInquiryFirmStatusSelect().length];
            inquiryStatus = enums.getInquiryFirmStatusSelect();
            loadingDateRequired = true;
        }else{
            loadingDateRequired = false;
            inquiryStatus = new SelectItem[enums.getInquiryIndicationStatusSelect().length];
            inquiryStatus = enums.getInquiryIndicationStatusSelect();
        }
    }
    public void inquiryTypeValueChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=getInstance().getInquiryType()){            
            renderInquiryStatus((InquiryType)event.getNewValue());
        }
    }

    public boolean isLoadingDateRequired() {
        return loadingDateRequired;
    }

    public void setLoadingDateRequired(boolean loadingDateRequired) {
        this.loadingDateRequired = loadingDateRequired;
    }

    @Override
    public void newRecord() throws InstantiationException, IllegalAccessException {
        
        inquiryOwners   = new ArrayList<Contact>();
        
        loadingCities   = new ArrayList<City>();
        unloadingCities = new ArrayList<City>();
        loadingPorts    = new ArrayList<Port>();
        unloadingPorts  = new ArrayList<Port>();
        inquiryFiles    = new ArrayList<InquiryOtherFile>();
        customerType        = null;
        inquirySourceSelect = null;
        renderLoadingPort   = false;
        inquiryStatus       = null;
        loadingDateRequired = true;

        super.newRecord(); //To change body of generated methods, choose Tools | Templates.
    }

    public List<InquiryOtherFile> getInquiryFiles() {
        if(inquiryFiles.isEmpty() && getInstance().isManaged()){
            HashMap<String,Object> inqParam = new HashMap<String,Object>();
            inqParam.put("inqryid",getInstance().getId());
            inquiryFiles.addAll(getCrud().getNamedList("InquiryOtherFile.findAll", inqParam));
        }
        return inquiryFiles;
    }

    public void setInquiryFiles(List<InquiryOtherFile> inquiryFiles) {
        this.inquiryFiles = inquiryFiles;
    }
    
    
    public void handleFileUpload(FileUploadEvent event) {
        try{
            String fileName = event.getFile().getFileName().toLowerCase(Locale.ENGLISH);
            UploadedFile source = event.getFile();
            String rootFolder = "";
            
            rootFolder = "/Users/alisenturk/Temp";
            
            String folderPath = rootFolder + "/opt/inquiry/other/"+Helper.getCurrentUserMerchant().getId()+"/"+getInstance().getId();
            
            
            File folder = new File(folderPath);
            if(!folder.exists()){
                folder.mkdirs();
            }
            String filePath = folderPath +"/"+fileName;
            byte[] bytes=null;
            if (null!=source) {
                bytes = source.getContents();
                
                
                File newFile = new File(filePath);
                BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(newFile));
                stream.write(bytes);
                stream.close();
                
                InquiryOtherFile inqFile = new InquiryOtherFile();
                inqFile.setInqFileType(inqFileType);
                inqFile.setInquiry(getInstance());
                inqFile.setFileName(fileName);
                inqFile.setFilePath(filePath);
                inqFile.setFileType(FilenameUtils.getExtension(filePath).toUpperCase());
                inqFile.setFileMimeType(source.getContentType());
                inqFile.setStatus(Status.ACTIVE);
                getCrud().createObject(inqFile);
                inquiryFiles    = new ArrayList<InquiryOtherFile>();
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        FacesMessage message = new FacesMessage("Succesful", event.getFile().getFileName() + " is uploaded.");
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    
    public void deleteInquiryFile(InquiryFile file) {
        file.setStatus(Status.DELETED);
        getCrud().deleteObject(file);
        Helper.addMessage(Helper.getMessage("Global.Record.Deleted"));
        inquiryFiles = new ArrayList<InquiryOtherFile>();
    }


    public boolean isTransportRequired() {
        return transportRequired;
    }

    public void setTransportRequired(boolean transportRequired) {
        this.transportRequired = transportRequired;
    }

    public InquiryFileType getInqFileType() {
        return inqFileType;
    }

    public void setInqFileType(InquiryFileType inqFileType) {
        this.inqFileType = inqFileType;
    }

    public boolean isUpdatable() {
        return updatable;
    }

    public void setUpdatable(boolean updatable) {
        this.updatable = updatable;
    }

    public void loadInquiryFile(InquiryFile ifile){
        currentInqFile = ifile;
        try{
            FileDownload file = new FileDownload();
            file.setFileName(currentInqFile.getFileName());
            file.setFilePath(currentInqFile.getFilePath());
            file.setContentType(currentInqFile.getFileMimeType());
            
            Gson gson = new Gson();
            String fileData = gson.toJson(file);
            fileData = Helper.getEncryptData(fileData,Helper.SECRET_KEY);
            previewFilePath = "/FileDownloader?fileData="+fileData;
            
        }catch(Exception e){
            
        }
            
    
    }
    public InquiryFile getCurrentInqFile() {
        return currentInqFile;
    }

    public void setCurrentInqFile(InquiryFile currentInqFile) {
        this.currentInqFile = currentInqFile;
    }

    public String getPreviewFilePath() {
        return previewFilePath;
    }

    public void setPreviewFilePath(String previewFilePath) {
        this.previewFilePath = previewFilePath;
    }

    
    
    
}
