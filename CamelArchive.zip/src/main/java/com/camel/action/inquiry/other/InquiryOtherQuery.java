package com.camel.action.inquiry.other;

import com.camel.entity.base.Merchant;
import com.camel.entity.base.User;
import com.camel.entity.customer.Customer;
import com.camel.entity.location.City;
import com.camel.entity.location.Country;
import com.camel.entity.location.Port;
import com.camel.enums.Continent;
import com.camel.enums.CustomerType;
import com.camel.enums.InquiryStatus;
import java.util.Date;
import java.util.HashMap;

/**
 *
 * @author asenturk
 */
public class InquiryOtherQuery {
    private String          inquiryCode;
    private User            responsible;    
    private CustomerType    customerType;
    private Customer        customer;
    private Date            requestBeginDate;
    private Date            requestEndDate;
    private Date            loadingBeginDate;
    private Date            loadingEndDate;
    private Merchant        merchant;
    private InquiryStatus   inquiryStatus;
    private Boolean         pendingBid;
    private String          cargoTrackingNo;    

    private Continent loadContinent;  
    private Country   loadingCountry    ;
    private City      loadingCity      ;
    private Port      loadingPort        ;
    
    private Continent unloadContinent;
    private Country   unloadingCountry  ;
    private City      unloadingCity     ;
    private Port      unloadingPort      ;
    
    
    
    private HashMap<String,Object> params = new HashMap<String,Object>();
    
    public String getInquiryCode() {
        return inquiryCode;
    }

    public void setInquiryCode(String inquiryCode) {
        this.inquiryCode = inquiryCode;
    }

    public User getResponsible() {
        return responsible;
    }

    public void setResponsible(User responsible) {
        this.responsible = responsible;
    }

    public CustomerType getCustomerType() {
        return customerType;
    }

    public void setCustomerType(CustomerType customerType) {
        this.customerType = customerType;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getRequestBeginDate() {
        return requestBeginDate;
    }

    public void setRequestBeginDate(Date requestBeginDate) {
        this.requestBeginDate = requestBeginDate;
    }

    public Date getRequestEndDate() {
        return requestEndDate;
    }

    public void setRequestEndDate(Date requestEndDate) {
        this.requestEndDate = requestEndDate;
    }

    public Date getLoadingBeginDate() {
        return loadingBeginDate;
    }

    public void setLoadingBeginDate(Date loadingBeginDate) {
        this.loadingBeginDate = loadingBeginDate;
    }

    public Date getLoadingEndDate() {
        return loadingEndDate;
    }

    public void setLoadingEndDate(Date loadingEndDate) {
        this.loadingEndDate = loadingEndDate;
    }

    public InquiryStatus getInquiryStatus() {
        return inquiryStatus;
    }

    public void setInquiryStatus(InquiryStatus inquiryStatus) {
        this.inquiryStatus = inquiryStatus;
    }

    public String getCargoTrackingNo() {
        return cargoTrackingNo;
    }

    public void setCargoTrackingNo(String cargoTrackingNo) {
        this.cargoTrackingNo = cargoTrackingNo;
    }

    
    
    public static String getResponsibleInquiriesFromLoadingDate(boolean isInquiryStatusNull,boolean isInquiryTypesNull){
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT d FROM InquiryOther d ");
        sql.append("WHERE ");
        sql.append("    d.merchant.id=:mrchntid and ");
        sql.append("    d.loadingDate>=:today ");
        sql.append("    and d.responsible.id =:responsibleId ");
        if(!isInquiryTypesNull){
            sql.append("    and d.inquiryType IN (:inquiryTypes) ");
        }
        if(!isInquiryStatusNull){
            sql.append("    and d.inquiryStatus IN (:inquiryStatuses) ");
        }else{
            sql.append("    and d.inquiryStatus IN ('WAITINGFEEDBACK') ");
        }
        
        sql.append("ORDER BY d.loadingDate ");
        return sql.toString();
    }
    public static String getDepartmentInquiriesFromLoadingDate(boolean isInquiryStatusNull,boolean isInquiryTypesNull){
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT d FROM InquiryOther d ");
        sql.append("WHERE ");
        sql.append("    d.merchant.id=:mrchntid and ");
        sql.append("    d.loadingDate>=:today ");
        sql.append("    and d.responsible.id !=:currentUserId ");
        sql.append("    and d.responsible.department.id =:departmentId ");
        if(!isInquiryTypesNull){
            sql.append("    and d.inquiryType IN (:inquiryTypes) ");
        }
        if(!isInquiryStatusNull){
            sql.append("    and d.inquiryStatus IN (:inquiryStatuses) ");
        }else{
            sql.append("    and d.inquiryStatus IN ('INPROGRESS','WAITINGFEEDBACK') ");
        }
        sql.append("ORDER BY d.loadingDate ");
        return sql.toString();
    }
    
    public static String getDepartmentInquiriesFromUnloadingDate(boolean isInquiryStatusNull,boolean isInquiryTypesNull){
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT d FROM InquiryOther d ");
        sql.append("WHERE ");
        sql.append("    d.merchant.id=:mrchntid and ");
        sql.append("    d.unloadingDate>=:today ");
        sql.append("    and d.responsible.id !=:currentUserId ");
        sql.append("    and d.responsible.department.id =:departmentId ");
        if(!isInquiryTypesNull){
            sql.append("    and d.inquiryType IN (:inquiryTypes) ");
        }
        if(!isInquiryStatusNull){
            sql.append("    and d.inquiryStatus IN (:inquiryStatuses) ");
        }else{
            sql.append("    and d.inquiryStatus IN ('INPROGRESS','WAITINGFEEDBACK') ");
        }
        sql.append("ORDER BY d.loadingDate ");
        return sql.toString();
    }
    
    public static String getResponsibleInquiriesFromOfferDeadline(boolean isInquiryStatusNull,boolean isInquiryTypesNull){
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT d FROM InquiryOther d ");
        sql.append("WHERE ");
        sql.append("    d.merchant.id=:mrchntid and ");
        sql.append("    d.offerDeadline >=:today ");
        sql.append("    and d.responsible.id =:responsibleId ");
        if(!isInquiryTypesNull){
            sql.append("    and d.inquiryType IN (:inquiryTypes) ");
        }
        if(!isInquiryStatusNull){
            sql.append("    and d.inquiryStatus IN (:inquiryStatuses) ");
        }else{
            sql.append("    and d.inquiryStatus IN ('INPROGRESS') ");
        }
        sql.append("    and d.offerDeadline is not null ");
        sql.append("ORDER BY d.offerDeadline ");
        return sql.toString();
    }
    public static String getResponsibleInquiriesFromToAct(boolean isInquiryStatusNull,boolean isInquiryTypesNull){
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT d FROM InquiryOther d ");
        sql.append("WHERE ");
        sql.append("    d.merchant.id=:mrchntid and ");
        sql.append("    d.loadingDate >=:today ");
        sql.append("    and d.responsible.id =:responsibleId ");
        if(!isInquiryTypesNull){
            sql.append("    and d.inquiryType IN (:inquiryTypes) ");
        }
        if(!isInquiryStatusNull){
            sql.append("    and d.inquiryStatus IN (:inquiryStatuses) ");
        }else{
            sql.append("    and d.inquiryStatus IN ('ACCEPTED') ");
        }
        sql.append("    and d.loadingDate is not null ");
        sql.append("ORDER BY d.loadingDate ");
        return sql.toString();
    }
    public static String getDepartmentInquiriesFromOfferDeadline(boolean isInquiryStatusNull,boolean isInquiryTypesNull){
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT d FROM InquiryOther d ");
        sql.append("WHERE ");
        sql.append("    d.merchant.id=:mrchntid and ");
        sql.append("    d.responsible.department.id =:departmentId ");
        sql.append("    and d.responsible.id !=:currentUserId ");
        if(!isInquiryTypesNull){
            sql.append("    and d.inquiryType IN (:inquiryTypes) ");
        }
        if(!isInquiryStatusNull){
            sql.append("    and d.inquiryStatus IN (:inquiryStatuses) ");
        }
        sql.append("    and d.offerDeadline is not null ");
        sql.append("    and d.offerDeadline >=:today ");
        sql.append("ORDER BY d.offerDeadline ");
        return sql.toString();
    }
    
    public String getInqueryQuery(){
        StringBuffer sql = new StringBuffer();
        try{
            boolean where = false;
            sql.append("SELECT d FROM InquiryOther d ");
            if(merchant!=null && merchant.getId()!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.merchant.id=:mrchntid ");
            }
            if(inquiryCode!=null && inquiryCode.length()>3){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.inquiryCode =:inqCode ");
            }
            if(responsible!=null && responsible.getId()>0){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.responsible.id =:responsibleId ");
            }
            if(customerType!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.customer.customerType =:customerTypeKey ");
            }
            if(customer!=null && customer.getId()>0){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.customer.id =:customerId ");
            }
            if(requestBeginDate!=null && requestEndDate!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" ( d.requestDate BETWEEN :requestBeginDate AND :requestEndDate ) ");
            }
            if(loadingBeginDate!=null && loadingEndDate!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" (d.loadingDate BETWEEN :loadingBeginDate AND :loadingEndDate ) ");
            }
            if(inquiryStatus!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.inquiryStatus =:inquiryStatusKey ");
            }
            if(pendingBid!=null && pendingBid){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" ( ");
            	sql.append("    select count(b) from InquiryBid b where b.inquiry.id = d.id and b.status = 'ACTIVE' ");
                sql.append(" )>0  ");
            }
            
            if(loadingCountry!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.loadingCountry.id=:loadingCountryId ");
            }
            
            if(loadingCity!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.loadingCity.id=:loadingCityId ");
            }
            if(loadingPort!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.loadingPort.id=:loadingPortId ");
            }
            if(unloadingCountry!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.unloadingCountry.id=:unloadingCountryId ");
            }
            if(unloadingCity!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.unloadingCity.id=:unloadingCityId ");
            }
            if(unloadingPort!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.unloadingPort.id=:unloadingPortId ");
            }
            
            if(loadingCountry==null && loadContinent!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.loadingCountry.continet=:loadCntnt ");
            }
            if(unloadingCountry==null && unloadContinent!=null){
                if(where){
                    sql.append(" AND ");
                }else{
                    sql.append(" WHERE ");
                    where = true;
                }
                sql.append(" d.unloadingCountry.continet=:unloadCntnt ");
            }
            
            if(where){
                sql.append(" AND ");
            }else{
                sql.append(" WHERE ");
                where = true;
            }
            sql.append(" d.status = 'ACTIVE' ");
            
        }catch(Exception e){
            e.printStackTrace();
        }    
        
        return sql.toString();          
        
    }

    public HashMap<String, Object> getParams() {
        params = new HashMap<String,Object>();
        if(merchant!=null && merchant.getId()!=null){
            params.put("mrchntid",merchant.getId());
        }
        if(inquiryCode!=null && inquiryCode.length()>3){
            params.put("inqCode",inquiryCode);
        }
        if(responsible!=null){
            params.put("responsibleId",responsible.getId());
        }
        if(customerType!=null){
            params.put("customerTypeKey",customerType.getKey());
        }
        if(customer!=null){
            params.put("customerId",customer.getId());
        }
        if(requestBeginDate!=null){
            params.put("requestBeginDate",requestBeginDate);
        }
        if(requestEndDate!=null){
            params.put("requestEndDate",requestEndDate);
        }
        if(loadingBeginDate!=null){
            params.put("loadingBeginDate",loadingBeginDate);
        }
        if(loadingEndDate!=null){
            params.put("loadingEndDate",loadingEndDate);
        }
        if(inquiryStatus!=null){
            params.put("inquiryStatusKey",inquiryStatus);
        }   
        if(loadingCountry!=null){
           params.put("loadingCountryId",loadingCountry.getId());
        }

        if(loadingCity!=null){
           params.put("loadingCityId",loadingCity.getId());
        }
        if(loadingPort!=null){
            params.put("loadingPortId",loadingPort.getId());
        }
        if(unloadingCountry!=null){
           params.put("unloadingCountryId", unloadingCountry.getId());
        }
        if(unloadingCity!=null){
            params.put("unloadingCityId", unloadingCity.getId());
        }
        if(unloadingPort!=null){
            params.put("unloadingPortId", unloadingPort.getId());
        }

        if(loadingCountry==null && loadContinent!=null){
            params.put("loadCntnt",loadContinent);
        }
        if(unloadingCountry==null && unloadContinent!=null){
            params.put("unloadCntnt",unloadContinent);
        }
    
        return params;
    }

    public void setParams(HashMap<String, Object> params) {
        this.params = params;
    }

    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    public Boolean getPendingBid() {
        return pendingBid;
    }

    public void setPendingBid(Boolean pendingBid) {
        this.pendingBid = pendingBid;
    }

    public Country getLoadingCountry() {
        return loadingCountry;
    }

    public void setLoadingCountry(Country loadingCountry) {
        this.loadingCountry = loadingCountry;
    }

    public City getLoadingCity() {
        return loadingCity;
    }

    public void setLoadingCity(City loadingCity) {
        this.loadingCity = loadingCity;
    }

    public Port getLoadingPort() {
        return loadingPort;
    }

    public void setLoadingPort(Port loadingPort) {
        this.loadingPort = loadingPort;
    }

    public Country getUnloadingCountry() {
        return unloadingCountry;
    }

    public void setUnloadingCountry(Country unloadingCountry) {
        this.unloadingCountry = unloadingCountry;
    }

    public City getUnloadingCity() {
        return unloadingCity;
    }

    public void setUnloadingCity(City unloadingCity) {
        this.unloadingCity = unloadingCity;
    }

    public Port getUnloadingPort() {
        return unloadingPort;
    }

    public void setUnloadingPort(Port unloadingPort) {
        this.unloadingPort = unloadingPort;
    }

    public Continent getLoadContinent() {
        return loadContinent;
    }

    public void setLoadContinent(Continent loadContinent) {
        this.loadContinent = loadContinent;
    }

    public Continent getUnloadContinent() {
        return unloadContinent;
    }

    public void setUnloadContinent(Continent unloadContinent) {
        this.unloadContinent = unloadContinent;
    }
    
    
    
}
