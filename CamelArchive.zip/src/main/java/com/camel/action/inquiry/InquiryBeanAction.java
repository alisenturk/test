package com.camel.action.inquiry;

import com.camel.action.base.BaseAction;
import com.camel.action.base.Enums;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.User;
import com.camel.entity.customer.Contact;
import com.camel.entity.customer.Customer;
import com.camel.entity.inquiry.Inquiry;
import com.camel.entity.inquiry.InquiryBid;
import com.camel.entity.inquiry.InquiryCalc;
import com.camel.entity.inquiry.InquiryFile;
import com.camel.entity.inquiry.InquiryOffer;
import com.camel.entity.inquiry.InquiryTeamMember;
import com.camel.entity.location.City;
import com.camel.entity.location.Country;
import com.camel.entity.location.Port;
import com.camel.entity.project.Project;
import com.camel.enums.*;
import com.camel.servlet.FileDownload;
import com.camel.util.Helper;
import com.google.gson.Gson;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.application.NavigationHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.FilenameUtils;
import org.omnifaces.cdi.Param;
import org.omnifaces.cdi.param.ParamValue;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

/**
 *
 * @author asenturk
 */
@Named(value = "inquiryBean")
@ViewScoped
public class InquiryBeanAction extends BaseAction<Inquiry>{
            
    @Inject
    Enums enums;
    
    @Inject
    InquiryCalcAction   inquiryCalcAct;
    
    @Inject
    InquiryOfferAction  inquiryOfferAct;
    
    @Inject
    InquiryBidAction    inquiryBidAction;
    
    @Inject
    @Param(required = false)
    private ParamValue<String> processParam ;
    
    private List<User>              responsibles    = new ArrayList<User>();
    private List<Customer>          customers       = new ArrayList<Customer>();
    private List<Contact>           inquiryOwners   = new ArrayList<Contact>();
    private List<Country>           countries       = new ArrayList<Country>();
    private List<City>              loadingCities   = new ArrayList<City>();
    private List<City>              unloadingCities = new ArrayList<City>();
    private List<Port>              loadingPorts    = new ArrayList<Port>();
    private List<Port>              unloadingPorts  = new ArrayList<Port>();
    private List<InquiryFile>       inquiryFiles    = new ArrayList<InquiryFile>();
    private List<User>              merchantUsers   = new ArrayList<>();
    private List<InquiryTeamMember> inquiryTeamMembers = new ArrayList<>();
    private List<Project>           projectList     = new ArrayList<>();

    private CustomerType    customerType;
    private SelectItem[]    inquirySourceSelect;
    private boolean         renderLoadingPort   = false;
    private SelectItem[]    inquiryStatus       = null;
    private boolean         loadingDateRequired = true;
    private Merchant        merchant            = Helper.getCurrentUserMerchant();
    private boolean         transportRequired   = true;
    private boolean         updatable           = true;
    private InquiryFile     currentInqFile;
    private InquiryFileType inqFileType = InquiryFileType.OTHER;
    private String          previewFilePath="";
    private boolean         renderPrice         = false;
    private boolean         renderImportance    = false;
    private User            teamMember          = null;
    private MemberType      teamMemberType      = MemberType.INFO;
    private boolean         renderProject       = false;
    private boolean         cityRequired        = true;

    public List<User> getResponsibles() {
        if(responsibles.isEmpty()){            
            responsibles.add(Helper.getCurrentUserFromSession());
            if(getInstance().getResponsible()!=null && !getInstance().getResponsible().getId().equals(Helper.getCurrentUserFromSession().getId())){
                responsibles.add(getInstance().getResponsible());
            }
        }
        return responsibles;
    }

    public void setResponsibles(List<User> responsibles) {
        this.responsibles = responsibles;
    }

    public List<Customer> getCustomers() {
        if(customers.isEmpty()){
            customers.addAll(getCrud().getNamedList("Customer.findAllActive",Helper.getParamsHashByMerchant()));
        }
        return customers;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }

    public CustomerType getCustomerType() {
        return customerType;
    }

    public void setCustomerType(CustomerType customerType) {
        this.customerType = customerType;
    }
    
    public void customerValueChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=getInstance().getCustomer()){            
            loadInquirySource(((Customer)event.getNewValue()).getCustomerType());
        }
    }
    private void loadInquirySource(CustomerType customerType){
        inquiryOwners = new ArrayList<Contact>(); 
        if(customerType.equals(CustomerType.AGENT)){
            inquirySourceSelect = new SelectItem[1];                
            inquirySourceSelect[0] = new SelectItem(InquirySource.AGENT.getKey(),InquirySource.AGENT.getValue());
        }else{
            inquirySourceSelect = new SelectItem[2];                
            inquirySourceSelect[0] = new SelectItem(InquirySource.OWN.getKey(),InquirySource.OWN.getValue());
            inquirySourceSelect[1] = new SelectItem(InquirySource.SALES.getKey(),InquirySource.SALES.getValue());
        }
    }
    
    public SelectItem[] getInquirySourceSelect() {
        if(inquirySourceSelect==null){
            inquirySourceSelect = new SelectItem[InquirySource.values().length];
            int i = 0;
            for (InquirySource s :InquirySource.values()) {
                inquirySourceSelect[i++] = new SelectItem(s.getKey(),s.getValue());
            }
        }
        return inquirySourceSelect;
    }

    public void setInquirySourceSelect(SelectItem[] inquirySourceSelect) {
        this.inquirySourceSelect = inquirySourceSelect;
    }

    public void inquirySourceValueChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=getInstance().getInquirySource()){            
            loadInquiryOwners(((InquirySource)event.getNewValue()));
        }
    }
    private void loadInquiryOwners(InquirySource source){
        inquiryOwners = new ArrayList<Contact>();
        if(source.equals(InquirySource.SALES)){
            inquiryOwners.addAll(getCrud().getNamedList("Contact.findMerchantSalesTeamActive",Helper.getParamsHashByMerchant()));
        }else if(getInstance().getCustomer()!=null){
           HashMap<String, Object> params = new HashMap<String,Object>();
           params.put("custid", getInstance().getCustomer().getId());
           params.put("mrchntid",merchant.getId());
           inquiryOwners.addAll(getCrud().getNamedList("Contact.findCustomerContactsActive", params));
        }
    }
    public List<Contact> getInquiryOwners() {
        return inquiryOwners;
    }

    public void setInquiryOwners(List<Contact> inquiryOwners) {
        this.inquiryOwners = inquiryOwners;
    }

    public List<Country> getCountries() {
        if(countries.isEmpty()){
            countries.addAll(getCrud().getNamedList("Country.findAll"));
        }
        return countries;
    }

    public void setCountries(List<Country> countries) {
        this.countries = countries;
    }

    public List<City> getLoadingCities() {
        return loadingCities;
    }

    public void setLoadingCities(List<City> loadingCities) {
        this.loadingCities = loadingCities;
    }

    public List<City> getUnloadingCities() {
        return unloadingCities;
    }

    public void setUnloadingCities(List<City> unloadingCities) {
        this.unloadingCities = unloadingCities;
    }

    public List<Port> getLoadingPorts() {
        return loadingPorts;
    }

    public void setLoadingPorts(List<Port> loadingPorts) {
        this.loadingPorts = loadingPorts;
    }

    public List<Port> getUnloadingPorts() {
        return unloadingPorts;
    }

    public void setUnloadingPorts(List<Port> unloadingPorts) {
        this.unloadingPorts = unloadingPorts;
    }
    
    public void loadingCountryValueChange(ValueChangeEvent event){
        try{
            if(event!=null &&  event.getNewValue()!=null && !event.getNewValue().equals(getInstance().getLoadingCountry())){            
                loadingCitiesAndPorts((Country)event.getNewValue());
            }
            checkCityRequired();

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private void checkCityRequired() {
        if(getInstance().getScopeOfWork()!=null && getInstance().getScopeOfWork().equals(InquiryWorkScope.PORT_TO_PORT)){
            this.cityRequired = false;
        }else{
            this.cityRequired = true;
        }
    }

    private void loadingCitiesAndPorts(Country country){
        loadingCities.clear();
        loadingPorts.clear();
        HashMap<String, Object> params = new HashMap<String,Object>();
        params.put("country", country.getId());
        loadingCities.addAll(getCrud().getNamedList("City.findCountryCities", params));
        if(getInstance().getCustomsType()!=null && getInstance().getCustomsType().equals(CustomsType.TRANSIT)){
            loadingPorts.addAll(getCrud().getNamedList("Port.findAll"));
        }else {
            loadingPorts.addAll(getCrud().getNamedList("Port.findCountryPorts", params));
        }
    }
    
    public void unloadingCountryValueChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=getInstance().getUnloadingCountry()){            
            unloadingCitiesAndPorts((Country)event.getNewValue());
        }
        if(getInstance().getScopeOfWork()!=null && getInstance().getScopeOfWork().equals(InquiryWorkScope.PORT_TO_PORT)){
            this.cityRequired = false;
        }else{
            this.cityRequired = true;
        }
    }
    
    private void unloadingCitiesAndPorts(Country country){
        unloadingCities.clear();
        unloadingPorts.clear();
        HashMap<String, Object> params = new HashMap<String,Object>();
        params.put("country",country.getId());
        unloadingCities.addAll(getCrud().getNamedList("City.findCountryCities", params));
        if(getInstance().getCustomsType()!=null && getInstance().getCustomsType().equals(CustomsType.TRANSIT)){
            unloadingPorts.addAll(getCrud().getNamedList("Port.findAll"));
        }else{
            unloadingPorts.addAll(getCrud().getNamedList("Port.findCountryPorts",params));
        }


    }
    
    private void createInquiryBid(){
        inquiryBidAction.setInstance(new InquiryBid());
        inquiryBidAction.getInstance().setInquiry(getInstance());
        inquiryBidAction.getInstance().setDeckOption(DeckOption.ONDECK);
        inquiryBidAction.getInstance().setMode(BidMode.BULK);
        inquiryBidAction.getInstance().setStackability(Stackability.NON_STACKABILITY);
        inquiryBidAction.getInstance().setStatus(Status.ACTIVE);
    }
    private void createInquiryCalc(){
        inquiryCalcAct.setInstance(new InquiryCalc());
        inquiryCalcAct.setInquery(getInstance());
        inquiryCalcAct.getInstance().setInquiry(getInstance());        
    }
    
    private boolean checkUserAccessRight(){
        try{
            InquiryQuery query = new InquiryQuery();            
            query.setInquiryId(getInstance().getId());
            query.setBranch(Helper.getCurrentUserMerchantBranch());
            query.setCurrentUser(Helper.getCurrentUserFromSession());
            query.setMerchant(Helper.getCurrentUserMerchant());
            query.setQueryName("InqSearchListQuery");
            List<Inquiry> list = getCrud().getList(query.getInqueryQuery(),query.getParams());
            if(list.size()>0){
                /** Inquiry update edilip edilemeyeceğini belirler **/
                checkInquiryUpdatable(query.getUpdatebleInquiryQuery());
                
                return true;
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
    private void accessDeniedRedirect(){
        ExternalContext    externalContext = FacesContext.getCurrentInstance().getExternalContext();
        
        HttpServletResponse response        = (HttpServletResponse) externalContext.getResponse();
        HttpServletRequest request         = (HttpServletRequest) externalContext.getRequest();
        
        try {
            response.sendRedirect(request.getContextPath() + "/access-denied.xhtml");
        } catch (IOException ex) {
            Logger.getLogger(InquiryBeanAction.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    @PostConstruct
    private void postLoad(){
        
        if(getInstance()!=null && getInstance().getId()!=null && getInstance().getId()>0){
            if(!checkUserAccessRight()){
                accessDeniedRedirect();
            }
            if(getInstance().getLoadingCountry()!=null){
                loadingCitiesAndPorts(getInstance().getLoadingCountry());                
            }
            if(getInstance().getUnloadingCountry()!=null){
                unloadingCitiesAndPorts(getInstance().getUnloadingCountry());
            }
            if(getInstance().getInquirySource()!=null){
                loadInquiryOwners(getInstance().getInquirySource());
            }
            if(getInstance().getTransportMode()!=null){
                renderLoadingPort(getInstance().getTransportMode());
            }
            inquiryCalcAct.setInquery(getInstance());
            
            inquiryOfferAct.setInquery(getInstance());
            inquiryOfferAct.setInstance(new InquiryOffer());
            inquiryOfferAct.getInstance().setInquiry(getInstance());
            inquiryOfferAct.getInstance().setStatus(Status.ACTIVE);
            
            HashMap<String, Object> params = new HashMap<String,Object>();
            params.put("inqryid",getInstance().getId());
            
            List<InquiryBid> list = getCrud().getNamedList("InquiryBid.findAll", params);
            if(!list.isEmpty()){
                inquiryBidAction.setInstance(list.get(0));
            }else{
                createInquiryBid();
            }
            
            checkTransporRequird(getInstance().getTransportMode());
            
            responsibles.add(getInstance().getResponsible());
            if(!Helper.getCurrentUserIsMemberAdmin() && !Helper.getCurrentUserIsAdmin()){
                responsibles.clear();
                responsibles.add(getInstance().getResponsible());
            }
            
            if(!inquiryOwners.contains(getInstance().getInquiryOwner())){
                inquiryOwners.add(getInstance().getInquiryOwner());
            }
            
            inquiryTeamMembers.clear();

            renderProject = getInstance().getInquiryScale().equals(InquiryScale.PROJECT);

            checkCityRequired();

        }else if(getInstance()!=null && !getInstance().isManaged()){
            createInquiryBid();
            if(!Helper.getCurrentUserIsMemberAdmin() && !Helper.getCurrentUserIsAdmin()){
                responsibles.clear();
                responsibles.add(Helper.getCurrentUserFromSession());
            }
            getInstance().setResponsible(Helper.getCurrentUserFromSession());
            getInstance().setRequestDate(new Date());
        }
        if(processParam!=null && processParam.getValue()!=null && processParam.getValue().equals("bid")){
            updatable = false;
            inquiryBidAction.setOnlyBid(true);
        }
        
        setInquiryImportance(getInstance().getOfferValue());
       
    }

    private void checkTransporRequird(TransportMode tm){
        transportRequired = true;
        if(tm.equals(TransportMode.LAND) || tm.equals(TransportMode.EXTRASERVICES)){
            transportRequired = false;
        }
    }
    public void transportModeValueChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=getInstance().getTransportMode()){            
            renderLoadingPort((TransportMode)event.getNewValue());

            TransportMode tm = (TransportMode)event.getNewValue();
            checkTransporRequird(tm);
        }
    }
    
    public boolean isRenderLoadingPort() {
        return renderLoadingPort;
    }

    public void setRenderLoadingPort(boolean renderLoadingPort) {
        this.renderLoadingPort = renderLoadingPort;
    }
    
    private void renderLoadingPort(TransportMode tm){
        
        if(tm!=null && 
           (!tm.equals(TransportMode.LAND) && !tm.equals(TransportMode.EXTRASERVICES) )){
            renderLoadingPort = true;
        }else{
            renderLoadingPort = false;
        }
        
    }

    @Override
    public void save(){
        try{
            Country userBranchCountry = Helper.getCurrentUserMerchantBranch().getCountry();
            
            String errorMessage = "";
            if(getInstance().getLoadingDate()!=null && getInstance().getUnloadingDate()!=null){
                double diff = Helper.dateDifferent(getInstance().getLoadingDate(),getInstance().getUnloadingDate(),Calendar.DATE);
                if(diff<0){
                    errorMessage = Helper.getMessage("Inquiry.Unloading.LoadingDiff");
                }
            }
            if(getInstance().getInquiryType().equals(InquiryType.FIRM) &&
               getInstance().getInquiryStatus().equals(InquiryStatus.SHIPMENTCOMPLETED) &&
               (getInstance().getCost().intValue()==0 || getInstance().getPrice().intValue()==0)){
                errorMessage = Helper.getMessage("Inquiry.Enter.CostAndPrice");
            }
            if(!getInstance().getInquiryStatus().equals(InquiryStatus.INPROGRESS) && getInstance().getImportance()==0){
                errorMessage = Helper.getMessage("Inquiry.Enter.Importance");
            }
            /** durum inprogress harici ise offer date zorunlu **/
            if(!getInstance().getInquiryStatus().equals(InquiryStatus.INPROGRESS) && getInstance().getOfferDate()==null){
                errorMessage = Helper.getMessage("Inquiry.Enter.OfferDateError01");
            }
            if(getInstance().getInquiryStatus().equals(InquiryStatus.INPROGRESS) && getInstance().getOfferDate()!=null){
                errorMessage = Helper.getMessage("Inquiry.Enter.OfferDateError04");
            }
            
            /** Offer Date ve Offer Deadline Request Date'ten sonra olmalı **/
            if(getInstance().getOfferDate()!=null && Helper.dateDifferent(getInstance().getRequestDate(), getInstance().getOfferDate(), Calendar.DATE)<0){
                errorMessage = Helper.getMessage("Inquiry.Enter.OfferDateError02");
            }
            if(getInstance().getOfferDate()!=null && getInstance().getLoadingDate()!=null &&
               Helper.dateDifferent(getInstance().getOfferDate(), getInstance().getLoadingDate(), Calendar.DATE)<0){
                errorMessage = Helper.getMessage("Inquiry.Enter.OfferDateError03");
            }
            if(getInstance().getOfferDeadline()!=null && Helper.dateDifferent(getInstance().getRequestDate(), getInstance().getOfferDeadline(), Calendar.DATE)<0){
                errorMessage = Helper.getMessage("Inquiry.Enter.OfferDeadlineError01");
            }
            if(!getInstance().getInquiryStatus().equals(InquiryStatus.INPROGRESS) && (getInstance().getOfferCost()<1 || getInstance().getOfferValue()<1)  ){
                errorMessage = Helper.getMessage("Inquiry.Enter.OfferCostAndValueError01");
            }

            if((getInstance().getCustomsType().equals(CustomsType.EXTRA_SERVICE) && !getInstance().getTransportMode().equals(TransportMode.EXTRASERVICES))
               || (!getInstance().getCustomsType().equals(CustomsType.EXTRA_SERVICE) && getInstance().getTransportMode().equals(TransportMode.EXTRASERVICES))     
              ){
                errorMessage = Helper.getMessage("Inquiry.Enter.CustomTypeError01");
            }
            /**Customs Type kuralları **/
            if(getInstance().getCustomsType().equals(CustomsType.IMPORT) &&
               getInstance().getUnloadingCountry()!=null && !getInstance().getUnloadingCountry().getId().equals(userBranchCountry.getId())){
                errorMessage = Helper.getMessage("Inquiry.Enter.CustomsTypeError02").replace("#country#", userBranchCountry.getCountryName());
            }
            if(getInstance().getCustomsType().equals(CustomsType.EXPORT) && 
               getInstance().getLoadingCountry()!=null && !getInstance().getLoadingCountry().getId().equals(userBranchCountry.getId())){
                errorMessage = Helper.getMessage("Inquiry.Enter.CustomsTypeError03").replace("#country#", userBranchCountry.getCountryName());
            }
             if(getInstance().getCustomsType().equals(CustomsType.EXPORT) && 
               getInstance().getUnloadingCountry()!=null && getInstance().getUnloadingCountry().getId().equals(userBranchCountry.getId())){
                errorMessage = Helper.getMessage("Inquiry.Enter.CustomsTypeError06").replace("#country#", userBranchCountry.getCountryName());
            }
            if(getInstance().getCustomsType().equals(CustomsType.INLAND) &&
               (
                (getInstance().getLoadingCountry()!=null && !getInstance().getLoadingCountry().getId().equals(userBranchCountry.getId())) ||
                (getInstance().getUnloadingCountry()!=null && !getInstance().getUnloadingCountry().getId().equals(userBranchCountry.getId()))    
               )
              ){
                errorMessage = Helper.getMessage("Inquiry.Enter.CustomsTypeError04").replace("#country#", userBranchCountry.getCountryName());
            }
            
            if(getInstance().getCustomsType().equals(CustomsType.CROSS) && 
               (
                (getInstance().getLoadingCountry()!=null && getInstance().getLoadingCountry().getId().equals(userBranchCountry.getId())) ||
                (getInstance().getUnloadingCountry()!=null && getInstance().getUnloadingCountry().getId().equals(userBranchCountry.getId()))    
               )
              ){
                errorMessage = Helper.getMessage("Inquiry.Enter.CustomsTypeError05").replace("#country#", userBranchCountry.getCountryName());
            }
            
            if(getInstance().getInquiryStatus().equals(InquiryStatus.SHIPMENTCOMPLETED) && 
                (getInstance().getFileCode()==null || getInstance().getFileCode().isEmpty())){
                errorMessage = Helper.getMessage("Inquiry.Enter.FileCodeError");
            }
            
            
            if(errorMessage.length()>3){
                Helper.addMessage(errorMessage,FacesMessage.SEVERITY_ERROR);
            }else{
                if(getInstance().getMerchant()==null){
                    getInstance().setMerchant(merchant);
                }
                if(getInstance().getBranch()==null){
                    getInstance().setBranch(Helper.getCurrentUserMerchantBranch());
                }
                if(getInstance().getDepartment()==null){
                    getInstance().setDepartment(Helper.getCurrentUserDepartment());
                }
                /** Team Member Kayıt için **/
                if(getInstance().getInquiryTeamMembers().isEmpty() && !getInquiryTeamMembers().isEmpty()){
                    getInstance().setInquiryTeamMembers(getInquiryTeamMembers());
                }
                checkInquiryTeamMembers();

                /** Calc offerBenefit **/
                getInstance().setOfferBenefit(calcBenefit(getInstance().getOfferCost(),getInstance().getOfferValue()));

                if(getInstance().isManaged()){ /** UPDATE **/
                    if(getInstance().getInquiryCode()==null){
                        getInstance().setInquiryCode("INQ" + getInstance().getId());
                    }
                    
                    getCrud().updateObject(getInstance());

                    Helper.addMessage(Helper.getMessage("Global.Record.Updated"));
                }else{ /** INSERT **/
                    
                    /** Kaydı giren kişi responsible olarak atanıyor **/
                    getInstance().setResponsible(Helper.getCurrentUserFromSession());
                    
                    getCrud().createObject(getInstance());
                    getInstance().setInquiryCode("INQ" + getInstance().getId());
                    getCrud().updateObject(getInstance());
                    
                    /** TeamMember'lar kayit Ediliyor **/
                    for(InquiryTeamMember itm:getInstance().getInquiryTeamMembers()){
                        getCrud().createObject(itm);
                    }
                    
                    Helper.addMessage(Helper.getMessage("Global.Record.Added"));

                }
                inquiryCalcAct.setInquery(getInstance());
                super.setList(new ArrayList<Inquiry>());
            }
        }catch(Exception e){
            Helper.addMessage("HATA..:" + e.getMessage());
        }
    }

    private Double calcBenefit(Double cost, Double value) {
        if(cost!=null && value!=null) {
            if(cost==0)return 0d;
            double dblBenefit = (value - cost) / cost * 100d;

            return BigDecimal.valueOf(dblBenefit).setScale(2, RoundingMode.HALF_UP).doubleValue();
        }
        return 0d;
    }

    public SelectItem[] getInquiryStatus() {
        if(inquiryStatus==null){
            inquiryStatus = enums.getInquiryStatusSelect();
        }
        return inquiryStatus;
    }

    public void setInquiryStatus(SelectItem[] inquiryStatus) {
        this.inquiryStatus = inquiryStatus;
    }
    public void renderInquiryStatus(InquiryType inqType){
        if(inqType.equals(InquiryType.FIRM)){
            inquiryStatus = new SelectItem[enums.getInquiryFirmStatusSelect().length];
            inquiryStatus = enums.getInquiryFirmStatusSelect();
            loadingDateRequired = true;
        }else{
            loadingDateRequired = false;
            inquiryStatus = new SelectItem[enums.getInquiryIndicationStatusSelect().length];
            inquiryStatus = enums.getInquiryIndicationStatusSelect();
        }
    }
    public void inquiryTypeValueChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=getInstance().getInquiryType()){            
            renderInquiryStatus((InquiryType)event.getNewValue());
        }
    }

    public boolean isLoadingDateRequired() {
        return loadingDateRequired;
    }

    public void setLoadingDateRequired(boolean loadingDateRequired) {
        this.loadingDateRequired = loadingDateRequired;
    }

    @Override
    public void newRecord() throws InstantiationException, IllegalAccessException {
        
        inquiryOwners   = new ArrayList<Contact>();
        
        loadingCities   = new ArrayList<City>();
        unloadingCities = new ArrayList<City>();
        loadingPorts    = new ArrayList<Port>();
        unloadingPorts  = new ArrayList<Port>();
        inquiryFiles    = new ArrayList<InquiryFile>();
        customerType        = null;
        inquirySourceSelect = null;
        renderLoadingPort   = false;
        inquiryStatus       = null;
        loadingDateRequired = true;

        super.newRecord(); 
        if(getInstance().getInquiryStatus()==null){
            getInstance().setInquiryStatus(InquiryStatus.INPROGRESS);
        }
    }

    public List<InquiryFile> getInquiryFiles() {
        if(inquiryFiles.isEmpty() && getInstance().isManaged()){
            HashMap<String,Object> inqParam = new HashMap<String,Object>();
            inqParam.put("inqryid",getInstance().getId());
            inquiryFiles.addAll(getCrud().getNamedList("InquiryFile.findAll", inqParam));
        }
        return inquiryFiles;
    }

    public void setInquiryFiles(List<InquiryFile> inquiryFiles) {
        this.inquiryFiles = inquiryFiles;
    }
    
    
    public void handleFileUpload(FileUploadEvent event) {
        try{
            String fileName = event.getFile().getFileName().toLowerCase(Locale.ENGLISH);
            UploadedFile source = event.getFile();

            String folderPath = Constants.PROJECT_FILE_FOLDER.getValue() + "/inquiry/"+Helper.getCurrentUserMerchant().getId()+"/"+getInstance().getId();
            if(Constants.PROJECT_STAGE.getValue().equals("dev")){
                folderPath = "/Users/alisenturk/Temp/opt/camel" + "/inquiry/"+Helper.getCurrentUserMerchant().getId()+"/"+getInstance().getId();
            }
            File folder = new File(folderPath);
            if(!folder.exists()){
                folder.mkdirs();
            }
            String filePath = folderPath +"/"+fileName;
            byte[] bytes=null;
            if (null!=source) {
                bytes = source.getContents();
                
                
                File newFile = new File(filePath);
                BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(newFile));
                stream.write(bytes);
                stream.close();
                
                InquiryFile inqFile = new InquiryFile();
                inqFile.setInqFileType(inqFileType);
                inqFile.setInquiry(getInstance());
                inqFile.setFileName(fileName);
                inqFile.setFilePath(filePath);
                inqFile.setFileType(FilenameUtils.getExtension(filePath).toUpperCase());
                inqFile.setFileMimeType(source.getContentType());
                inqFile.setStatus(Status.ACTIVE);
                getCrud().createObject(inqFile);
                inquiryFiles    = new ArrayList<InquiryFile>();
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        FacesMessage message = new FacesMessage("Succesful", event.getFile().getFileName() + " is uploaded.");
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    
    public void deleteInquiryFile(InquiryFile file) {
        file.setStatus(Status.DELETED);
        getCrud().deleteObject(file);
        Helper.addMessage(Helper.getMessage("Global.Record.Deleted"));
        inquiryFiles = new ArrayList<InquiryFile>();
    }

    public InquiryCalcAction getInquiryCalcAct() {
        return inquiryCalcAct;
    }

    public void setInquiryCalcAct(InquiryCalcAction inquiryCalcAct) {
        this.inquiryCalcAct = inquiryCalcAct;
    }

    public InquiryOfferAction getInquiryOfferAct() {
        return inquiryOfferAct;
    }

    public void setInquiryOfferAct(InquiryOfferAction inquiryOfferAct) {
        this.inquiryOfferAct = inquiryOfferAct;
    }

    public boolean isTransportRequired() {
        return transportRequired;
    }

    public void setTransportRequired(boolean transportRequired) {
        this.transportRequired = transportRequired;
    }

    public InquiryFileType getInqFileType() {
        return inqFileType;
    }

    public void setInqFileType(InquiryFileType inqFileType) {
        this.inqFileType = inqFileType;
    }

    public boolean isUpdatable() {
        return updatable;
    }

    public void setUpdatable(boolean updatable) {
        this.updatable = updatable;
    }

    public void loadInquiryFile(InquiryFile ifile){
        currentInqFile = ifile;
        try{
            FileDownload file = new FileDownload();
            file.setFileName(currentInqFile.getFileName());
            file.setFilePath(currentInqFile.getFilePath());
            file.setContentType(currentInqFile.getFileMimeType());
            
            Gson gson = new Gson();
            String fileData = gson.toJson(file);
            fileData = Helper.getEncryptData(fileData,Helper.SECRET_KEY);
            previewFilePath = "/FileDownloader?fileData="+fileData;
            
        }catch(Exception e){
            
        }
            
    
    }
    public InquiryFile getCurrentInqFile() {
        return currentInqFile;
    }

    public void setCurrentInqFile(InquiryFile currentInqFile) {
        this.currentInqFile = currentInqFile;
    }

    public String getPreviewFilePath() {
        return previewFilePath;
    }

    public void setPreviewFilePath(String previewFilePath) {
        this.previewFilePath = previewFilePath;
    }

    public boolean isRenderPrice() {
        return renderPrice;
    }

    public void setRenderPrice(boolean renderPrice) {
        this.renderPrice = renderPrice;
    }

    public boolean isRenderImportance() {
        return renderImportance;
    }

    public void setRenderImportance(boolean renderImportance) {
        this.renderImportance = renderImportance;
    }

    


    public List<User> getMerchantUsers() {
        if(merchantUsers.isEmpty()){
             merchantUsers.addAll(getCrud().getNamedList("User.findMerchantAllUsers",Helper.getParamsHashByMerchant()));
        }
        return merchantUsers;
    }

    public void setMerchantUsers(List<User> merchantUsers) {
        this.merchantUsers = merchantUsers;
    }

    public User getTeamMember() {
        return teamMember;
    }

    public void setTeamMember(User teamMember) {
        this.teamMember = teamMember;
    }

    public List<InquiryTeamMember> getInquiryTeamMembers() {
        if(inquiryTeamMembers.isEmpty() && getInstance().isManaged()){
            HashMap<String,Object> inqParam = new HashMap<String,Object>();
            inqParam.put("inqryid",getInstance().getId());
            inquiryTeamMembers.addAll(getCrud().getNamedList("InquiryTeamMember.findAll", inqParam));
        }
        return inquiryTeamMembers;
    }

    public void setInquiryTeamMembers(List<InquiryTeamMember> inquiryTeamMembers) {
        this.inquiryTeamMembers = inquiryTeamMembers;
    }
    public void addTeamMember(){
        try{
            if(teamMember!=null){
                boolean hasMember = false;
                for(InquiryTeamMember member:getInquiryTeamMembers()){
                    if(member.getMember().getId()==teamMember.getId()){
                        hasMember = true;
                        break;
                    }
                }
                if(!hasMember){
                    InquiryTeamMember itm = new InquiryTeamMember();
                    itm.setInquiry(getInstance());
                    itm.setMember(teamMember);
                    itm.setMemberType(teamMemberType);
                    if(teamMember.getId().equals(getInstance().getResponsible().getId())){
                        itm.setMemberType(MemberType.OWNER);
                    }
                    itm.setEdit(itm.getMemberType().equals(MemberType.OWNER));
                    if(getInstance().isManaged()){
                        getCrud().createObject(itm);

                        /* liste boşaltılıp db'den yeniden çekilir **/
                        inquiryTeamMembers.clear();
                        getInquiryTeamMembers();
                    }else{
                        inquiryTeamMembers.add(itm);
                    }
                }
                teamMember = null;
                

            }
        }catch(Exception e){
            System.out.println("***************** AddTeamMember ****************");
            e.printStackTrace();
        }
    }
    public void removeTeamMember(InquiryTeamMember member){
        try{
            member.setStatus(Status.DELETED);
            getCrud().deleteObject(member);
            inquiryTeamMembers.clear();
        }catch(Exception e){
            System.out.println("******* removeTeamMember *****");
            e.printStackTrace();
        }
    }

    private void checkInquiryUpdatable(String inqQuery) {
        updatable = false;
        String inqId = getCrud().getNativeSql(inqQuery);
        if(inqId!=null && inqId.length()>0){
            updatable = true;
        }
    }

    private void checkInquiryTeamMembers() {
        boolean hasOwner = false;
        for(InquiryTeamMember itm:getInstance().getInquiryTeamMembers()){
            if(itm.getMemberType().equals(MemberType.OWNER)){
                hasOwner=true;
                break;
            }
        }
        if(!hasOwner){
            InquiryTeamMember itm = new InquiryTeamMember();
            itm.setInquiry(getInstance());
            itm.setMember(getInstance().getResponsible());
            itm.setMemberType(MemberType.OWNER);
            itm.setEdit(true);
            getInstance().getInquiryTeamMembers().add(itm);
        }
    }

    public MemberType getTeamMemberType() {
        return teamMemberType;
    }

    public void setTeamMemberType(MemberType teamMemberType) {
        this.teamMemberType = teamMemberType;
    }
    
    public void offerValueChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null){            
            setInquiryImportance(Double.parseDouble(String.valueOf(event.getNewValue())));
            getInstance().setOfferBenefit(calcBenefit(getInstance().getOfferCost(),(double)event.getNewValue()));
        }
    }
    public void offerCostChange(ValueChangeEvent event){
        if(event!=null &&  event.getNewValue()!=null){
            getInstance().setOfferBenefit(calcBenefit((double)event.getNewValue(),getInstance().getOfferValue()));
        }
    }


    private void setInquiryImportance(double parseDouble) {
        if(parseDouble>=100000){
            getInstance().setImportance(5);
        }else if(parseDouble>=50000){
            getInstance().setImportance(4);
        }else if(parseDouble>=25000){
            getInstance().setImportance(3);
        }else if(parseDouble>=15000){
            getInstance().setImportance(2);
        }else if(parseDouble>=1){
            getInstance().setImportance(1);
        }else{
            getInstance().setImportance(0);
        }
    }

    public List<Project> getProjectList() {
        if(projectList.isEmpty()){
            projectList.addAll(getCrud().getNamedList("Project.findAll",Helper.getParamsHashByMerchant()));
        }
        return projectList;
    }

    public void setProjectList(List<Project> projectList) {
        this.projectList = projectList;
    }

    public void inquiryScaleValueChange(ValueChangeEvent event){
        renderProject = false;
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=getInstance().getInquiryType()){
            if(((InquiryScale)event.getNewValue()).equals(InquiryScale.PROJECT)){
                renderProject = true;
            };
        }
    }

    public boolean isRenderProject() {
        return renderProject;
    }

    public void setRenderProject(boolean renderProject) {
        this.renderProject = renderProject;
    }

    public boolean isCityRequired() {
        return cityRequired;
    }

    public void setCityRequired(boolean cityRequired) {
        this.cityRequired = cityRequired;
    }
}
