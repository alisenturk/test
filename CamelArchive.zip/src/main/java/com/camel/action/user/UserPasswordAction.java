/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.user;

import com.camel.action.base.BaseAction;
import com.camel.entity.base.User;
import com.camel.util.Helper;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author alisenturk
 */
@Named(value = "userPass")
@ViewScoped
public class UserPasswordAction extends BaseAction<User>{

    private String  currentPassword;
    private String  newPassword;
    private String  confirmPassword;
    
    @PostConstruct
    private void init(){
        setInstance(Helper.getCurrentUserFromSession());        
    }

    public void changePassword(){
        if(getInstance()!=null){
            if(getInstance().getPassword().equals(currentPassword)){
                getInstance().setPassword(newPassword);
                getCrud().updateObject(getInstance());
                FacesMessage fMsg = new FacesMessage("Password changed.");
                FacesContext.getCurrentInstance().addMessage(null, fMsg);
            }else{
                FacesMessage fMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR,"Hata","Currenct password is incorrect!");
                FacesContext.getCurrentInstance().addMessage(null, fMsg);
            }
        }else{
            FacesMessage fMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR,"Hata","User instance is null!");
            FacesContext.getCurrentInstance().addMessage(null, fMsg);
        }
    }

    public String getCurrentPassword() {
        return currentPassword;
    }

    public void setCurrentPassword(String currentPassword) {
        this.currentPassword = currentPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }    
}
