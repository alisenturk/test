/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.location;

import com.camel.action.base.BaseAction;
import com.camel.entity.location.City;
import com.camel.entity.location.Country;
import com.camel.entity.location.Port;
import com.camel.enums.PortType;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.primefaces.event.FileUploadEvent;

/**
 *
 * @author asenturk
 */
@Named
@ViewScoped
public class PortAction extends BaseAction<Port>{
    private Country country = new Country();
    private List<Country>   countries   = new ArrayList<Country>();
    private List<City>      cities      = new ArrayList<City>();
    
    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    
    public List<Country> getCountries() {
        if(countries==null || countries.isEmpty()){
            countries.addAll(getCrud().getNamedList("Country.findAll"));
        }
        return countries;
    }

    public void setCountries(List<Country> countries) {
        this.countries = countries;
    }

    public List<City> getCities() {
        return cities;
    }

    public void setCities(List<City> cities) {
        this.cities = cities;
    }
    
    
    
    public void loadCities(ValueChangeEvent event){
        super.setList(new ArrayList<Port>());
        cities = new ArrayList<City>();
        if(event!=null &&  event.getNewValue()!=null && event.getNewValue()!=country ){
            super.setList(new ArrayList<Port>());
            country = (Country)event.getNewValue();
            HashMap<String, Object> params = new HashMap<String,Object>();
            params.put("country", country.getId());
            super.getList().addAll(getCrud().getNamedList("Port.findCountryPorts",params));
            cities.addAll(getCrud().getNamedList("City.findCountryCities", params));
        }
    }
    
    @Override
    public List<Port> getList() {
        if(super.getList()==null || super.getList().isEmpty()){
           super.setList(new ArrayList<Port>());
           super.getList().addAll(getCrud().getNamedList("Port.findAll"));
        }
        return super.getList(); 
    }
    
    public void handleFileUpload(FileUploadEvent event) {
        try {
            List<Port> portsList = new ArrayList<Port>();

            //Create the input stream from the xlsx/xls file
            String fileName = event.getFile().getFileName();
            String portCode     = "";
            String portName     = "";
            String cityCode     = "";
            String cityName     = "";
            String countryCode  = "";
            String countryName  = "";
            InputStream fis = event.getFile().getInputstream();

            //Create Workbook instance for xlsx/xls file input stream
            Workbook workbook = null;
            if (fileName.toLowerCase().endsWith("xlsx")) {
                workbook = new XSSFWorkbook(fis);
            } else if (fileName.toLowerCase().endsWith("xls")) {
                workbook = new HSSFWorkbook(fis);
            }

            Sheet           sheet           = workbook.getSheetAt(0);
            Iterator<Row>   rowIterator     = sheet.iterator();
            Row             row             = null;
            Iterator<Cell>  cellIterator    = null;
            Cell            cell            = null;
            City            city            = null;
            Port            port            = null;
            PortType        portType        = null;
            while (rowIterator.hasNext()) {
                portCode     = "";
                portName     = "";
                cityCode     = "";            
                cityName     = "";
                countryCode  = "";
                countryName  = "";
                portType     = null;

                row             = rowIterator.next();
                cellIterator    = row.cellIterator();
                
                if(row.getRowNum()==0)continue;
                
                while (cellIterator.hasNext()) {
                    cell = cellIterator.next();
                    if (cell.getCellType().equals(CellType.STRING)) {
                        if (portCode.equalsIgnoreCase("")) {
                            portCode = cell.getStringCellValue().trim();
                        }else if (portName.equalsIgnoreCase("")) {
                            portName = cell.getStringCellValue().trim();
                       /* }else if (cityCode.equalsIgnoreCase("")) {
                            cityCode = cell.getStringCellValue().trim();
                        }else if (cityName.equalsIgnoreCase("")) {
                            cityName = cell.getStringCellValue().trim();*/
                        }else if (countryCode.equalsIgnoreCase("")) {
                            countryCode = cell.getStringCellValue().trim();
                        }else if (countryName.equalsIgnoreCase("")) {
                            countryName = cell.getStringCellValue().trim();
                        }else if(portType==null){
                            portType = PortType.getPortTypeFromString(cell.getStringCellValue().trim());
                        }
                    }
                } //end of cell iterator
                if(countryCode.equals("#N/A"))continue;
                
                country = findCountry(countryCode);
                if(cityCode!=null && cityCode.length()>1) {
                    city = findCity(cityCode);
                }
                if(country!=null ){
                    port = new Port();
                    port.setPortType(portType);
                    port.setPortCode(portCode);
                    port.setPortName(portName);
                    port.setCity(city);
                    port.setCountry(country);
                    portsList.add(port);
                }
                
            } //end of rows iterator

            //close file input stream
            fis.close();
            for (Port c : portsList) {
                super.setInstance(c);
                super.save();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        FacesMessage message = new FacesMessage("Succesful", event.getFile().getFileName() + " is uploaded.");
        FacesContext.getCurrentInstance().addMessage(null, message);
        
        country = null;
        

    }
    
    private Country findCountry(String countryCode){
        Country country = null;
        HashMap<String,Object> params = new HashMap<String,Object>();
        params.put("countryCode",countryCode);
        List<Country> countries = getCrud().getNamedList("Country.findCountry",params);
        if(countries!=null && countries.size()>0){
            country = countries.get(0);
        }
        
        return country;
    }
    private City findCity(String cityCode){
        City city = null;
        HashMap<String,Object> params = new HashMap<String,Object>();
        params.put("cityCode",cityCode);
        List<City> cities = getCrud().getNamedList("City.findCity",params);
        if(cities!=null && cities.size()>0){
            city = cities.get(0);
        }
        
        return city;
    }

}
