/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.base;

import com.camel.action.schedule.TCMBDailyExchangeReader;
import com.camel.entity.base.DailyExchange;
import com.camel.entity.base.Sector;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named
@ViewScoped
public class DailyExchangeAction extends BaseAction<DailyExchange>{
    
    @Inject
    TCMBDailyExchangeReader tcmbReader;
    
    private Date    exchangeDate = new Date();
    private HashMap<String,Object> params = new HashMap<>();
    
    @Override
    public List<DailyExchange> getList() {
        if(super.getList()==null || super.getList().isEmpty()){
            
           params = new HashMap<>();
           params.put("currdate", getExchangeDate());
           super.setList(new ArrayList<DailyExchange>());
           super.getList().addAll(getCrud().getNamedList("DailyExchange.findDateAllExchange",params));
        }
        return super.getList(); 
    }
    
    public void loadDailyExchange(){
        super.setList(new ArrayList<DailyExchange>());
    }
    
    public void loadCurrencyExchangeFromTCMB(){
        tcmbReader.setExchangeDate(exchangeDate);
        try {
            tcmbReader.read();
        } catch (Exception ex) {
            Logger.getLogger(DailyExchangeAction.class.getName()).log(Level.SEVERE, null, ex);
        }
        loadDailyExchange();
    }
    
    public Date getExchangeDate() {
        if(exchangeDate==null){
            exchangeDate = new Date();
        }
        return exchangeDate;
    }

    public void setExchangeDate(Date exchangeDate) {
        this.exchangeDate = exchangeDate;
    }
    
    
    
}
