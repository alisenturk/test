/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.base;

import com.camel.entity.base.User;
import com.camel.enums.UserType;
import com.camel.util.Helper;
import java.io.IOException;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.NavigationHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 *
 * @author asenturk
 */
@Named
@RequestScoped
public class LoginAction implements Serializable {

    @Inject
    private EntityManager em;

    @Inject
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String doLogin() {
        try {
            /***** login için spring security alternatif picketlink*/
            ExternalContext context = FacesContext.getCurrentInstance().getExternalContext();
            RequestDispatcher dispatcher = ((ServletRequest) context.getRequest()).getRequestDispatcher("/j_spring_security_check");
            dispatcher.forward((ServletRequest) context.getRequest(),(ServletResponse) context.getResponse());
            FacesContext.getCurrentInstance().responseComplete();
        } catch (ServletException ex) {
            Logger.getLogger(LoginAction.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(LoginAction.class.getName()).log(Level.SEVERE, null, ex);
        }

        return null;
    }

    public String doLogOut() throws IOException, ServletException {
        ExternalContext context
                = FacesContext.getCurrentInstance().getExternalContext();

        RequestDispatcher dispatcher
                = ((ServletRequest) context.getRequest()).getRequestDispatcher("/j_spring_security_logout");

        dispatcher.forward((ServletRequest) context.getRequest(),
                (ServletResponse) context.getResponse());

        FacesContext.getCurrentInstance().responseComplete();
        return null;
    }

    public void userSet(){
        try{
            User userTmp = em.createNamedQuery("User.findUser",User.class).setParameter("email",user.getEmail()).getSingleResult();
            if (userTmp.getPassword().equals(user.getPassword())) {
                user = userTmp;
                HttpSession session = (HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
                session.setAttribute("user",user);
            }
        }catch(Exception e){
            e.printStackTrace();
            Helper.addMessage("Kullanici bulunamadı!");
        }
    }

    public void injectUser() {
        
        if (user==null || user.getEmail()==null) {
            user =  em.createNamedQuery("User.findUser",User.class).setParameter("email",SecurityContextHolder.getContext().getAuthentication().getName()).getSingleResult();
        }
    }

    public void checkUser() {

        if (!SecurityContextHolder.getContext().getAuthentication().getName().equals("anonymousUser")) {
            NavigationHandler nh = FacesContext.getCurrentInstance().getApplication().getNavigationHandler();
            nh.handleNavigation(FacesContext.getCurrentInstance(), null, "/app/index.xhtml?faces-redirect=true");
        }
    }
    
    public String getLoginUsername(){
        String currentUser = "";
        
        User userLog =  Helper.getCurrentUserFromSession();
        if(userLog!=null){
            currentUser = userLog.getFirstname()+ " " + userLog.getLastname();
        }
        
        userLog = null;
       
        return currentUser;
    }
    
    public void redirectUser() {

        if (!SecurityContextHolder.getContext().getAuthentication().getName().equals("anonymousUser")) {
            NavigationHandler nh = FacesContext.getCurrentInstance().getApplication().getNavigationHandler();
            if(user==null || user.getEmail()==null)injectUser();
            if(user!=null && user.getUserType()!=null && user.getUserType().equals(UserType.ADMIN)){
                nh.handleNavigation(FacesContext.getCurrentInstance(), null, "/admin/index.xhtml?faces-redirect=true");
            }else{
                nh.handleNavigation(FacesContext.getCurrentInstance(), null, "/admin/index.xhtml?faces-redirect=true");
            }
        }
    }
    
    public boolean hasRole(String role){
        for (GrantedAuthority auth : SecurityContextHolder.getContext().getAuthentication().getAuthorities()) {
            if(role.contains(auth.getAuthority()))return true;
            
            
        }
        
        return false;
    }
}
