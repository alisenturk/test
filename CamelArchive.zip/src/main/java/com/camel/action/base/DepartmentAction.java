/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.base;

import com.camel.entity.base.Department;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.MerchantBranch;
import com.camel.util.Helper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.event.ValueChangeEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named
@ViewScoped
public class DepartmentAction extends BaseAction<Department>{
    
    Merchant        merchant = Helper.getCurrentUserMerchant();
    MerchantBranch  branch   = Helper.getCurrentUserMerchantBranch();
    
    private List<Merchant>          merchantList = new ArrayList<>();
    private List<MerchantBranch>    branches      = new ArrayList<>();
    
    
    @PostConstruct
    private void startup(){
        findMerchantBranches();
    }
    
    @Override
    public List<Department> getList() {
        if(super.getList()==null || super.getList().isEmpty()){
           /* HashMap<String,Object> params = new HashMap<String,Object>();
            params.put("mrchntid",merchant.getId());
           super.setList(new ArrayList<Department>());
           if(Helper.getCurrentUserIsAdmin()){
               super.getList().addAll(getCrud().getNamedList("Department.findAll"));
           }else{
                super.getList().addAll(getCrud().getNamedList("Department.findAllMerchantDepartments",params));
           }*/
           if(Helper.getCurrentUserIsAdmin() && branch==null){
                Map<String,Object> params = new HashMap<>();
                params.put("mrchntid",merchant.getId());
                super.setList(new ArrayList<Department>());
                super.getList().addAll(getCrud().getNamedList("Department.findAllMerchantDepartments",params));
           }else{
                Map<String,Object> params = new HashMap<>();
                params.put("mrchntid",merchant.getId());
                params.put("brnchid", branch.getId());
                super.setList(new ArrayList<Department>());
                super.getList().addAll(getCrud().getNamedList("Department.findAllMerchantBranchDepartments",params));
           }
        }
        return super.getList(); 
    }

    @Override
    public void newRecord() throws InstantiationException, IllegalAccessException {
        super.newRecord();
        getInstance().setMerchant(merchant);
    }

    @Override
    public void save() {
        
        if(merchant!=null && merchant.getId()!=null && merchant.getId()>0){
            if(getInstance()!=null && getInstance().getMerchant()==null){
                getInstance().setMerchant(merchant);
            }            
        }    
        super.save(); 
    }

    public List<Merchant> getMerchantList() {
        if(merchantList.isEmpty() && Helper.getCurrentUserIsAdmin()){
            merchantList.addAll(getCrud().getNamedList("Merchant.findAll"));
        }else if(merchantList.isEmpty() && !Helper.getCurrentUserIsAdmin()){
            merchantList.add(merchant);
        }
        return merchantList;
    }
    private void findMerchantBranches(){
        if(merchant!=null){
            HashMap<String,Object> params = new HashMap<>();
            params.put("mrchntid",merchant.getId());
            
            branches.clear();
            branches.addAll(getCrud().getNamedList("MerchantBranch.findAllMerchantBranchs", params));
        }
    }
    
    public void loadBranches(ValueChangeEvent event){
        if(event.getNewValue()!=null){
            merchant = (Merchant)event.getNewValue();
           findMerchantBranches();
        }
    }
    
    public void loadDepartments(ValueChangeEvent event){
        if(event.getNewValue()!=null && merchant!=null){
            
            HashMap<String,Object> params = new HashMap<>();
            params.put("mrchntid",merchant.getId());
            params.put("brnchid", branch.getId());
            super.setList(new ArrayList<Department>());
            super.getList().addAll(getCrud().getNamedList("Department.findAllMerchantBranchDepartments",params));
        }
    }

    public void setMerchantList(List<Merchant> merchantList) {
        this.merchantList = merchantList;
    }

    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    public List<MerchantBranch> getBranches() {
        return branches;
    }

    public void setBranches(List<MerchantBranch> branches) {
        this.branches = branches;
    }

    public MerchantBranch getBranch() {
        return branch;
    }

    public void setBranch(MerchantBranch branch) {
        this.branch = branch;
    }

    
    
    
    
    
    
}
