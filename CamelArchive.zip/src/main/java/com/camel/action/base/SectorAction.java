/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.base;

import com.camel.entity.base.Sector;
import java.util.ArrayList;
import java.util.List;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named
@ViewScoped
public class SectorAction extends BaseAction<Sector>{
    
    @Override
    public List<Sector> getList() {
        if(super.getList()==null || super.getList().isEmpty()){
           super.setList(new ArrayList<Sector>());
           super.getList().addAll(getCrud().getNamedList("Sector.findAll"));
        }
        return super.getList(); 
    }
}
