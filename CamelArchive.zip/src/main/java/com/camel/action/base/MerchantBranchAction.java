/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.base;

import com.camel.entity.base.Department;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.MerchantBranch;
import com.camel.entity.location.City;
import com.camel.entity.location.Country;
import com.camel.util.Helper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.faces.event.ValueChangeEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named
@ViewScoped
public class MerchantBranchAction extends BaseAction<MerchantBranch>{
    
    Merchant merchant = Helper.getCurrentUserMerchant();
    private List<Merchant>  merchantList = new ArrayList<Merchant>();
    private List<Country>   countries    = new ArrayList<Country>();
    private List<City>      cities       = new ArrayList<City>();
    
    @Override
    public List<MerchantBranch> getList() {
        if(super.getList()==null || super.getList().isEmpty()){
            HashMap<String,Object> params = new HashMap<String,Object>();
            params.put("mrchntid",merchant.getId());
           super.setList(new ArrayList<MerchantBranch>());
           if(Helper.getCurrentUserIsAdmin()){
               super.getList().addAll(getCrud().getNamedList("MerchantBranch.findAll"));
           }else{
                super.getList().addAll(getCrud().getNamedList("MerchantBranch.findAllMerchantBranchs",params));
           }
        }
        return super.getList(); 
    }

    @Override
    public MerchantBranch getInstance() {
         super.getInstance(); 
         if(super.getInstance().isManaged() && super.getInstance().getCountry()!=null){
             loadCities(super.getInstance().getCountry());
         }
         return super.getInstance();
    }
    
    

    @Override
    public void newRecord() throws InstantiationException, IllegalAccessException {
        super.newRecord();
        getInstance().setMerchant(merchant);
    }

    @Override
    public void save() {
        
        if(merchant!=null && merchant.getId()!=null && merchant.getId()>0){
            if(getInstance()!=null && getInstance().getMerchant()==null){
                getInstance().setMerchant(merchant);
            }            
        }    
        super.save(); 
    }

    public List<Merchant> getMerchantList() {
        if(merchantList.isEmpty() && Helper.getCurrentUserIsAdmin()){
            merchantList.addAll(getCrud().getNamedList("Merchant.findAll"));
        }else if(merchantList.isEmpty() && !Helper.getCurrentUserIsAdmin()){
            merchantList.add(merchant);
        }
        return merchantList;
    }

    public void setMerchantList(List<Merchant> merchantList) {
        this.merchantList = merchantList;
    }

    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    public List<Country> getCountries() {
        if (countries == null || countries.isEmpty()) {
            countries.addAll(getCrud().getNamedList("Country.findAll"));
        }
        return countries;
    }

    public void setCountries(List<Country> countries) {
        this.countries = countries;
    }

    public List<City> getCities() {
        return cities;
    }

    public void setCities(List<City> cities) {
        this.cities = cities;
    }
    

    public void loadCities(ValueChangeEvent event) {
        cities.clear();
        if (event != null && event.getNewValue() != null ) {
            Country country = (Country) event.getNewValue();
            loadCities(country);
        }
    }
    
    public void loadCities(Country country) {
        cities.clear();
        
        HashMap<String, Object> params = new HashMap<String, Object>();
        params.put("country", country.getId());
        cities.addAll(getCrud().getNamedList("City.findCountryCities", params));
        
    }
    
    
    
}
