
package com.camel.action.base;

import com.camel.entity.project.ProjectCategory;
import com.camel.entity.project.ProjectStage;
import com.camel.enums.*;

import java.io.Serializable;
import javax.faces.model.SelectItem;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named(value = "enums")
public class Enums implements Serializable{
        
    public SelectItem[] getStastusSelect() {
        SelectItem[] items = new SelectItem[Status.values().length];
        int i = 0;
        for (Status s : Status.values()) {
            items[i++] = new SelectItem(s, s.toString());
        }
        return items;
    }
    
    
    public SelectItem[] getUserTypeSelect() {
       SelectItem[] items = new SelectItem[UserType.values().length];
       int i = 0;
       for (UserType s : UserType.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    
    public SelectItem[] getGenderSelect() {
       SelectItem[] items = new SelectItem[Gender.values().length];
       int i = 0;
       for (Gender s : Gender.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    
    public SelectItem[] getContinentSelect() {
       SelectItem[] items = new SelectItem[Continent.values().length];
       int i = 0;
       for (Continent s : Continent.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    
     public SelectItem[] getAddressTypeSelect() {
       SelectItem[] items = new SelectItem[AddressType.values().length];
       int i = 0;
       for (AddressType s : AddressType.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    
    public SelectItem[] getContactTypeSelect() {
       SelectItem[] items = new SelectItem[ContactType.values().length];
       int i = 0;
       for (ContactType s : ContactType.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    public SelectItem[] getContactTypeCustomerSelect() {
       SelectItem[] items = new SelectItem[1];
       items[0] = new SelectItem(ContactType.CUSTOMER,ContactType.CUSTOMER.getValue());
       return items;
    }
    public SelectItem[] getContactTypeSalesTeamSelect() {
       SelectItem[] items = new SelectItem[1];
       items[0] = new SelectItem(ContactType.SALESTEAM,ContactType.SALESTEAM.getValue());
       return items;
    }
    public SelectItem[] getCurrencySelect() {

        SelectItem[] items = new SelectItem[1];
        items[0] = new SelectItem(Currency.USD,Currency.USD.getValue());
       /* 20.09.2019 talep üzerinde sadece USD olacak şekilde düzenlendi. A.S.
       SelectItem[] items = new SelectItem[Currency.values().length];
       int i = 0;
       for (Currency s : Currency.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       } */
       return items;
    }
    
    public SelectItem[] getCustomerTypeSelect() {
       SelectItem[] items = new SelectItem[CustomerType.values().length];
       int i = 0;
       for (CustomerType s : CustomerType.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    public SelectItem[] getCustomsTypeSelect() {
       SelectItem[] items = new SelectItem[CustomsType.getProjectCustomsTypes().size()];
       int i = 0;
       for (CustomsType s : CustomsType.getProjectCustomsTypes()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    
    public SelectItem[] getInquirySourceSelect() {
       SelectItem[] items = new SelectItem[InquirySource.values().length];
       int i = 0;
       for (InquirySource s :InquirySource.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    
    public SelectItem[] getInquiryStatusSelect() {
       SelectItem[] items = new SelectItem[InquiryStatus.values().length];
       int i = 0;
       for (InquiryStatus s :InquiryStatus.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    
    public SelectItem[] getTransportModeSelect() {
       SelectItem[] items = new SelectItem[TransportMode.values().length];
       int i = 0;
       for (TransportMode s : TransportMode.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    public SelectItem[] getPortTypeSelect() {
       SelectItem[] items = new SelectItem[PortType.values().length];
       int i = 0;
       for (PortType s : PortType.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    public SelectItem[] getInquiryTypesSelect() {
       SelectItem[] items = new SelectItem[InquiryType.getProjectInquiryTypes().size()];
       int i = 0;
       for (InquiryType s : InquiryType.getProjectInquiryTypes()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    
    public SelectItem[] getInquiryOtherTypesSelect() {
       SelectItem[] items = new SelectItem[InquiryType.getOtherInquiryTypes().size()];
       int i = 0;
       for (InquiryType s : InquiryType.getOtherInquiryTypes()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    
    public SelectItem[] getInquiryFirmStatusSelect() {
       SelectItem[] items = new SelectItem[InquiryStatus.values().length-1];
       int i = 0;
       for (InquiryStatus s :InquiryStatus.values()) {
           if(s.equals(InquiryStatus.INDICATIVEOFFERGIVEN))
               continue;
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    public SelectItem[] getInquiryIndicationStatusSelect() {
       SelectItem[] items = new SelectItem[2];
       int i = 0;
       for (InquiryStatus s :InquiryStatus.values()) {
           if(s.equals(InquiryStatus.INPROGRESS) || s.equals(InquiryStatus.INDICATIVEOFFERGIVEN)){
               items[i++] = new SelectItem(s,s.getValue());
           }
       }
       return items;
    }
    
    public SelectItem[] getEventTypes(){
       SelectItem[] items = new SelectItem[EventType.values().length];
       int i = 0;
       for (EventType s : EventType.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    
    public SelectItem[] getOfferTypeSelect() {
        SelectItem[] items = new SelectItem[OfferType.values().length];
        int i = 0;
        for (OfferType s : OfferType.values()) {
            items[i++] = new SelectItem(s, s.getValue());
        }
        return items;
    }
    
    public SelectItem[] getCalcItemTypeSelect() {
        SelectItem[] items = new SelectItem[CalcItemType.values().length];
        int i = 0;
        for (CalcItemType s : CalcItemType.values()) {
            items[i++] = new SelectItem(s, s.getValue());
        }
        return items;
    }
    
    public SelectItem[] getVisitTypeSelect() {
        SelectItem[] items = new SelectItem[VisitType.values().length];
        int i = 0;
        for (VisitType s : VisitType.values()) {
            items[i++] = new SelectItem(s, s.getLabel());
        }
        return items;
    }
    
    public SelectItem[] getBidModeSelect() {
        SelectItem[] items = new SelectItem[BidMode.values().length];
        int i = 0;
        for (BidMode s : BidMode.values()) {
            items[i++] = new SelectItem(s, s.getLabel());
        }
        return items;
    }
    
    public SelectItem[] getDeckOptionSelect() {
        SelectItem[] items = new SelectItem[DeckOption.values().length];
        int i = 0;
        for (DeckOption s : DeckOption.values()) {
            items[i++] = new SelectItem(s, s.getLabel());
        }
        return items;
    }

    public SelectItem[] getStackabilitySelect() {
        SelectItem[] items = new SelectItem[Stackability.values().length];
        int i = 0;
        for (Stackability s : Stackability.values()) {
            items[i++] = new SelectItem(s, s.getLabel());
        }
        return items;
    }
    public SelectItem[] getBulkTypeSelect() {
        SelectItem[] items = new SelectItem[BulkType.values().length];
        int i = 0;
        for (BulkType s : BulkType.values()) {
            items[i++] = new SelectItem(s, s.getLabel());
        }
        return items;
    }
    public SelectItem[] getInquiryFileTypeSelect() {
        SelectItem[] items = new SelectItem[InquiryFileType.values().length];
        int i = 0;
        for (InquiryFileType s : InquiryFileType.values()) {
            items[i++] = new SelectItem(s, s.getLabel());
        }
        return items;
    }
    public SelectItem[] getInquiryBidOfferStatusSelect() {
        SelectItem[] items = new SelectItem[InquiryBidOfferStatus.values().length];
        int i = 0;
        for (InquiryBidOfferStatus s : InquiryBidOfferStatus.values()) {
            items[i++] = new SelectItem(s, s.getLabel());
        }
        return items;
    }
    
    public SelectItem[] getInquiryScaleSelect() {
       SelectItem[] items = new SelectItem[InquiryScale.values().length];
       int i = 0;
       for (InquiryScale s : InquiryScale.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }
    public SelectItem[] getInquiryTeamMemberTypeSelect() {
       SelectItem[] items = new SelectItem[MemberType.values().length];
       int i = 0;
       for (MemberType s : MemberType.values()) {
           items[i++] = new SelectItem(s,s.getValue());
       }
       return items;
    }

    public SelectItem[] getProjectCategorySelect() {
        SelectItem[] items = new SelectItem[ProjectCategory.values().length];
        int i = 0;
        for (ProjectCategory s : ProjectCategory.values()) {
            items[i++] = new SelectItem(s,s.getValue());
        }
        return items;
    }

    public SelectItem[] getProjectStageSelect() {
        SelectItem[] items = new SelectItem[ProjectStage.values().length];
        int i = 0;
        for (ProjectStage s : ProjectStage.values()) {
            items[i++] = new SelectItem(s,s.getValue());
        }
        return items;
    }

    public SelectItem[] getInquiryScopeOfWorkSelect() {
        SelectItem[] items = new SelectItem[InquiryWorkScope.values().length];
        int i = 0;
        for (InquiryWorkScope s : InquiryWorkScope.values()) {
            items[i++] = new SelectItem(s,s.getValue());
        }
        return items;
    }


}
