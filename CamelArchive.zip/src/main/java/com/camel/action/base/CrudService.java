package com.camel.action.base;

import com.camel.util.Helper;

import java.io.Serializable;
import java.util.*;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

/**
 *
 * @author asenturk
 */
@Stateless
public class CrudService implements Serializable {

    @Inject
    private EntityManager em;

    public Object updateObject(Object object) {
        return em.merge(object);
    }

    public void createObject(Object object) {
        em.persist(object);
    }

    public void refresh(Object object) {
        em.refresh(object);
    }

    public <T> T find(Class<T> clazz, Long id) {
        return em.find(clazz, id);
    }

    public void deleteObject(Object object) {
        em.merge(object);
        //em.remove(em.merge(object));
    }

    public List getList(String query, int maxResult) {
        return em.createQuery(query).setHint("javax.persistence.cache.storeMode", "REFRESH").setMaxResults(maxResult).getResultList();
    }

    public List getList(String query) {
        return em.createQuery(query).setHint("javax.persistence.cache.storeMode", "REFRESH").getResultList();
    }

    public List getList(String query, Map<String, Object> params) {
        List rl = null;
        Query cquery = null;
        try {
            
            cquery = em.createQuery(query);
            cquery.setHint("javax.persistence.cache.storeMode", "REFRESH");
            if (params != null) {
                for (Map.Entry<String, Object> entry : params.entrySet()) {
                    if (entry.getValue() == null) {
                        continue;
                    }
            
                    cquery.setParameter(entry.getKey(), entry.getValue());
                }
            }
            rl = cquery.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rl;
    }

    public List getNamedList(String query) {
        return getNamedList(query,-1);
    }

    public List getNamedList(String query,int maxResult) {
        if(maxResult>0){
            return em.createNamedQuery(query).setHint("javax.persistence.cache.storeMode", "REFRESH").setMaxResults(maxResult).getResultList();
        }
        return em.createNamedQuery(query).setHint("javax.persistence.cache.storeMode", "REFRESH").getResultList();
    }

    public List getNativeList(String query) {
        return em.createNativeQuery(query).setHint("javax.persistence.cache.storeMode", "REFRESH").getResultList();
    }

    public String getNativeSql(String query) {
        try {
            Object result = em.createNativeQuery(query).setHint("javax.persistence.cache.storeMode", "REFRESH").getSingleResult();
            if (result != null) {
                return String.valueOf(result);
            }
        }catch (NoResultException e){
            return null;
        }
        return null;
    }
    public List getNativeList(String query, Map<String, Object> params) {
       List rl = new ArrayList();
       Query nq = em.createNativeQuery(query);
       nq.setHint("javax.persistence.cache.storeMode", "REFRESH");
       if (params != null) {
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                nq.setParameter(entry.getKey(), entry.getValue());
            }
       }
       rl = nq.getResultList();
       return rl; 
    }
    public List getNamedList(String query, Map<String, Object> params) {
        return getNamedList(query,params,-1);
    }
    public List getNamedList(String query, Map<String, Object> params,int maxResult) {
        List rl = null;
        try {
            Query nq = em.createNamedQuery(query);
            nq.setHint("javax.persistence.cache.storeMode", "REFRESH");
            if (maxResult > 0) {
                nq.setMaxResults(maxResult);
            }
            if (params != null) {
                for (Map.Entry<String, Object> entry : params.entrySet()) {
                    nq.setParameter(entry.getKey(), entry.getValue());
                }
            }
            rl = nq.getResultList();
        }catch(Exception e){
            System.out.println("CrudService.error..:" + e.getMessage() + " [QUERY]..:" + query);
            rl = Collections.emptyList();
        }
        return rl;
    }

    public void updateQuery(String query) {
        try {
            em.createQuery(query).executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public EntityManager getEm() {
        return em;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public void excutedUpdateNamedQuery(String query, Map<String, Object> params) {
        Query nq = em.createNamedQuery(query);
        if (params != null) {
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                nq.setParameter(entry.getKey(), entry.getValue());
            }
        }
        nq.executeUpdate();
    }

    public Object[] getCountQueryResult(String query, Map<String, Object> params) {
        Object[] result = null;

        try {

            Query cquery = em.createQuery(query);
            cquery.setHint("javax.persistence.cache.storeMode", "REFRESH");
            if (params != null) {
                for (Map.Entry<String, Object> entry : params.entrySet()) {
                    if (entry.getValue() == null) {
                        continue;
                    }

                    cquery.setParameter(entry.getKey(), entry.getValue());
                }
            }
            result = (Object[])cquery.getSingleResult();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}
