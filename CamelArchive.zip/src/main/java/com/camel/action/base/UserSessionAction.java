package com.camel.action.base;

import com.camel.action.events.ScheduleEventQuery;
import com.camel.action.index.Dashboard;
import com.camel.action.inquiry.InquiryQuery;
import com.camel.entity.base.User;
import com.camel.entity.events.ScheduleEvent;
import com.camel.entity.inquiry.Inquiry;
import com.camel.enums.MemberType;
import com.camel.enums.Status;
import com.camel.util.Helper;
import com.camel.util.JSFHelper;
import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.hbar.HorizontalBarChartDataSet;
import org.primefaces.model.charts.hbar.HorizontalBarChartModel;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Named
@SessionScoped
public class UserSessionAction implements Serializable {

    @Inject
    CrudService crud;

    @Inject
    JSFHelper jsfHelper;

    private List<ScheduleEvent> listEvents = new ArrayList<ScheduleEvent>();
    private HorizontalBarChartModel personnelPerformanceChart;

    @PostConstruct
    public void init() {

    }

    private void loadEvents(){
        Date today = new Date();
        User user = jsfHelper.getCurrentUserFromSession();
        if(user!=null && crud!=null){
            try{

                HashMap<String, Object> eventParam = new HashMap<String, Object>();
                eventParam.put("today", today);
                eventParam.put("currentUserId", user.getId());
                eventParam.put("departmentId", user.getDepartment().getId());
                eventParam.put("evntStatus", Status.ACTIVE);
                eventParam.put("mrchntid",Helper.getCurrentUserMerchant().getId());
                listEvents = crud.getList(ScheduleEventQuery.getScheduleEventQuery(true), eventParam);

            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    public List<ScheduleEvent> getListEvents() {
        if(listEvents.isEmpty()){
            loadEvents();
        }
        return listEvents;
    }

    public void setListEvents(List<ScheduleEvent> listEvents) {
        this.listEvents = listEvents;
    }

    private void loadPersonnelPerformance(){
        User user = jsfHelper.getCurrentUserFromSession();

        personnelPerformanceChart = new HorizontalBarChartModel();
        ChartData data = new ChartData();

        HorizontalBarChartDataSet hbarCountDataSet = new HorizontalBarChartDataSet();
        hbarCountDataSet.setLabel("Inquiry Count");
        hbarCountDataSet.setBackgroundColor("rgba(255, 99, 132, 0.2)");
        hbarCountDataSet.setBorderColor("rgb(255, 99, 132)");
        hbarCountDataSet.setBorderWidth(1);

        HorizontalBarChartDataSet hbarOfferValueDataSet = new HorizontalBarChartDataSet();
        hbarOfferValueDataSet.setLabel("Inquiry Offer Value");
        hbarOfferValueDataSet.setBackgroundColor("rgba(255, 159, 64, 0.2)");
        hbarOfferValueDataSet.setBorderColor("rgb(255, 159, 64)");
        hbarOfferValueDataSet.setBorderWidth(1);

        List<Number> offerValues = new ArrayList<>();
        List<Number> inquiryCountValues = new ArrayList<>();

        hbarCountDataSet.setData(inquiryCountValues);
        hbarOfferValueDataSet.setData(offerValues);


        List<String> labels = new ArrayList<>();
        labels.add("Prev Year of " + user.getNameSurname());
        labels.add("Current Year of " + user.getNameSurname());
        labels.add("Current Year of Department");
        labels.add("Current Year of Branch");
        labels.add("Current Year of Merchant");


        data.setLabels(labels);

        data.addChartDataSet(hbarCountDataSet);
        data.addChartDataSet(hbarOfferValueDataSet);
        personnelPerformanceChart.setData(data);

        LocalDate now = LocalDate.now(ZoneId.of("Europe/Istanbul"));

        LocalDate currentYearFirstDate = LocalDate.of(now.getYear(),1,1);
        LocalDate currentYearLastDate = LocalDate.of(now.getYear(),12,31);

        LocalDate prevYearLastDate = currentYearFirstDate.minusDays(1);
        LocalDate prevYearFirsDate = LocalDate.of(prevYearLastDate.getYear(),1,1);



        /** Önceki yıl'ın değerleri için **/
        InquiryQuery query = new InquiryQuery();
        query.setPersonnel(user);
        query.setMerchant(user.getMerchant());
        query.setRequestBeginDate(Helper.localDate2Date(prevYearFirsDate));
        query.setRequestEndDate(Helper.localDate2Date(prevYearLastDate));

        Object[] result = crud.getCountQueryResult(query.getInqueryPersonnelPerformanceQuery(),query.getParams());
        if(result!=null) {
            offerValues.add((Number) result[0]);
            inquiryCountValues.add((Number) result[1]);
        }else{
            offerValues.add(0);
            inquiryCountValues.add(0);
        }
        query   = null;
        result  = null;

        /** Mevcut yıl'ın değerleri için **/
        query = new InquiryQuery();
        query.setPersonnel(user);
        query.setMerchant(user.getMerchant());
        query.setRequestBeginDate(Helper.localDate2Date(currentYearFirstDate));
        query.setRequestEndDate(Helper.localDate2Date(currentYearLastDate));

        result = crud.getCountQueryResult(query.getInqueryPersonnelPerformanceQuery(),query.getParams());
        if(result!=null) {
            offerValues.add((Number) result[0]);
            inquiryCountValues.add((Number) result[1]);
        }else{
            offerValues.add(0);
            inquiryCountValues.add(0);
        }

        query   = null;
        result  = null;

        /** Mevcut yıl'ın departman değerleri için **/
        query = new InquiryQuery();
        query.setMerchant(user.getMerchant());
        query.setDepartment(user.getDepartment());
        //query.setExceptUser(user);
        query.setRequestBeginDate(Helper.localDate2Date(currentYearFirstDate));
        query.setRequestEndDate(Helper.localDate2Date(currentYearLastDate));

        result = crud.getCountQueryResult(query.getInqueryPersonnelPerformanceQuery(),query.getParams());
        if(result!=null) {
            offerValues.add((Number) result[0]);
            inquiryCountValues.add((Number) result[1]);
        }else{
            offerValues.add(0);
            inquiryCountValues.add(0);
        }

        query   = null;
        result  = null;

        /** Mevcut yıl'ın branch değerleri için **/
        query = new InquiryQuery();
        query.setMerchant(user.getMerchant());
        query.setBranch(Helper.getCurrentUserMerchantBranch());
        //query.setExceptUser(user);
        query.setRequestBeginDate(Helper.localDate2Date(currentYearFirstDate));
        query.setRequestEndDate(Helper.localDate2Date(currentYearLastDate));

        result = crud.getCountQueryResult(query.getInqueryPersonnelPerformanceQuery(),query.getParams());
        if(result!=null) {
            offerValues.add((Number) result[0]);
            inquiryCountValues.add((Number) result[1]);
        }else{
            offerValues.add(0);
            inquiryCountValues.add(0);
        }

        query   = null;
        result  = null;

        /** Mevcut yıl'ın Şirket değerleri için **/
        query = new InquiryQuery();
        query.setMerchant(user.getMerchant());
        //query.setExceptUser(user);
        query.setRequestBeginDate(Helper.localDate2Date(currentYearFirstDate));
        query.setRequestEndDate(Helper.localDate2Date(currentYearLastDate));

        result = crud.getCountQueryResult(query.getInqueryPersonnelPerformanceQuery(),query.getParams());
        if(result!=null) {

            offerValues.add((Number) result[0]);
            inquiryCountValues.add((Number) result[1]);
        }else{
            offerValues.add(0);
            inquiryCountValues.add(0);
        }


    }
    public void refreshPersonnelPerformanceChart(){
        loadPersonnelPerformance();
    }
    public HorizontalBarChartModel getPersonnelPerformanceChart() {
        if(null==personnelPerformanceChart){
            loadPersonnelPerformance();
        }
        return personnelPerformanceChart;
    }

    public void setPersonnelPerformanceChart(HorizontalBarChartModel personnelPerformanceChart) {
        this.personnelPerformanceChart = personnelPerformanceChart;
    }
}
