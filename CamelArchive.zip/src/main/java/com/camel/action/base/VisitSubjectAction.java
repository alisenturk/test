package com.camel.action.base;


import com.camel.entity.base.Merchant;
import com.camel.entity.visit.VisitSubject;
import com.camel.util.Helper;

import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asenturk
 */
@Named
@ViewScoped
public class VisitSubjectAction extends BaseAction<VisitSubject>{

    Merchant merchant = Helper.getCurrentUserMerchant();

    @Override
    public List<VisitSubject> getList() {
        if(super.getList()==null || super.getList().isEmpty()){
           super.setList(new ArrayList<VisitSubject>());
           super.getList().addAll(getCrud().getNamedList("VisitSubject.findAll", Helper.getParamsHashByMerchant()));
        }
        return super.getList(); 
    }

    @Override
    public void newRecord() throws InstantiationException, IllegalAccessException {
        super.newRecord();
        getInstance().setMerchant(merchant);
    }

    @Override
    public void save() {

        if(merchant!=null && merchant.getId()!=null && merchant.getId()>0){
            if(getInstance()!=null && getInstance().getMerchant()==null){
                getInstance().setMerchant(merchant);
            }
        }
        super.save();
    }
}
