/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.action.base;

import com.camel.entity.base.Department;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.OfferTemplate;
import com.camel.util.Helper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author asenturk
 */
@Named
@ViewScoped
public class OfferTemplateAction extends BaseAction<OfferTemplate>{
    
    Merchant merchant = Helper.getCurrentUserMerchant();
    
    @Override
    public List<OfferTemplate> getList() {
        if(super.getList()==null || super.getList().isEmpty()){
            HashMap<String,Object> params = new HashMap<String,Object>();
            params.put("mrchntid",merchant.getId());
           super.setList(new ArrayList<OfferTemplate>());
           super.getList().addAll(getCrud().getNamedList("OfferTemplate.findAllMerchantOfferTemplates",params));
        }
        return super.getList(); 
    }

    @Override
    public void save() {
        
        if(merchant!=null && merchant.getId()!=null && merchant.getId()>0){
            if(getInstance()!=null && getInstance().getMerchant()==null){
                getInstance().setMerchant(merchant);
            }            
        }    
        super.save(); 
    }
    
    
    
}
