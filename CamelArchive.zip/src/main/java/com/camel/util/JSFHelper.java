/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.util;


import com.camel.entity.base.DailyExchange;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.MerchantFile;
import com.camel.entity.base.User;
import com.camel.entity.inquiry.InquiryFile;
import com.camel.enums.Currency;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Date;
import javax.ejb.Stateless;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.servlet.http.HttpSession;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

/**
 *
 * @author asenturk
 */
@Named(value = "helper")
@Stateless
public class JSFHelper implements Serializable{

    @Inject
    private EntityManager entityManager;
    
        
    public String getMessage(String key){
        return Helper.getMessage(key);
    }
    public String getCurrentUserNameSurnameFromSession(){
        User user = Helper.getCurrentUserFromSession();
        return (user.getFirstname()+ " " + user.getLastname());
    }
    public Object getSessionValue(String key){
        HttpSession session = (HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        return session.getAttribute(key);
    }
    public void setSessionValue(String key,Object val){
        HttpSession session = (HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        session.setAttribute(key,val);
    }
    public void removeSessionValue(String key){
        HttpSession session = (HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        session.removeAttribute(key);
    }
    public User getCurrentUserFromSession(){
        User user = Helper.getCurrentUserFromSession();
        return user;
    }
    public String date2String(Date date){
        if(date!=null){
            return Helper.date2String(date);
        }
        
        return "";
    }
    
    public Merchant getCurrentUserMerchant(){
        Merchant merchant = Helper.getCurrentUserMerchant();
        return merchant;
    }
    
    public boolean isAdmin(){
        return  Helper.getCurrentUserIsAdmin();
    }
    public boolean isMemberAdmin(){
        return  Helper.getCurrentUserIsMemberAdmin();
    }
    public StreamedContent fileDownload(InquiryFile inqFile){
         return fileDownload(inqFile.getFilePath(),inqFile.getFileMimeType(),inqFile.getFileName());
    }
     public StreamedContent fileDownload(MerchantFile merchantFile){
         return fileDownload(merchantFile.getFilePath(),merchantFile.getFileMimeType(),merchantFile.getFileName());
    }
    
    public StreamedContent fileDownload(String filePath,String fileMimeType,String fileName){
        StreamedContent file = null;
        try{
            File source = new File(filePath);
            InputStream fis = new FileInputStream(source);
            
            
            file = new DefaultStreamedContent(fis,fileMimeType,fileName);
            
            fis = null;
            source = null;
        }catch(Exception e){
            e.printStackTrace();
        }
        return file;
    }
     public StreamedContent fileDownload(File source,String fileMimeType,String fileName){
        StreamedContent file = null;
        try{
            InputStream fis = new FileInputStream(source);
            file = new DefaultStreamedContent(fis,fileMimeType,fileName);
            
            fis = null;
            source = null;
        }catch(Exception e){
            e.printStackTrace();
        }
        return file;
    }
    
    public double getDailyExchangeValue(Currency currency,Date date){
        double val = 0d;
        try{
            DailyExchange de = (DailyExchange)entityManager.createNamedQuery("DailyExchange.findDateExchange").setParameter("currdate",date).setParameter("currtype",currency).getSingleResult();
            if(de!=null){
                val = de.getBuyingPrice();
            }
        }catch(javax.persistence.NoResultException nre){
            val = 0d;
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return val;
    }
    
    public String date2String(Date date,String format){
        if(date!=null){
            return Helper.date2String(date,format);
        }
        
        return "";
    }

    public boolean hasRole(String role){
        return Helper.hasRole(role);
    }
    
}
