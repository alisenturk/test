package com.camel.util;

import com.camel.entity.base.*;
import com.camel.enums.Currency;
import com.camel.enums.UserType;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.ejb.Stateless;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.servlet.http.HttpSession;
import org.primefaces.json.JSONArray;

/**
 *
 * @author asenturk
 */
@Stateless
public class Helper implements Serializable {

    public static final String SECRET_KEY = "Camel1980";
    
    public static void addMessage(String msg) {
        addMessage("", msg, FacesMessage.SEVERITY_INFO);
    }
    public static void addMessage(String msg,FacesMessage.Severity severity) {
        addMessage("", msg, severity);
    }
    public static void addMessage(String summary,String msg,FacesMessage.Severity severity) {
        FacesMessage fMsg = new FacesMessage(severity,msg,"");
        FacesContext.getCurrentInstance().addMessage(null, fMsg);
    }

    public static Locale getLocale(String language) {
        String firstLang = "tr";
        String secondLang = "TR";

        if (language == null || language.equals("")) {
            language = "TR";
        }
        if (language.equals("EN")) {
            firstLang = "en";
            secondLang = "US";
        } else if (language.equals("IR")) {
            language = "IR";
            firstLang = "ir";
            secondLang = "IR";
        } else if (language.equals("UA")) {
            language = "UA";
            firstLang = "uk";
            secondLang = "UA";
        } else if (language.equals("RU")) {
            language = "RU";
            firstLang = "ru";
            secondLang = "RU";
        } else {
            language = "TR";
            firstLang = "tr";
            secondLang = "TR";
        }
        return new Locale(firstLang, secondLang);
    }

    public static String getMessage(String messageKey) {
        String msgValue = "";
        try {

            FacesContext ctx = FacesContext.getCurrentInstance();
            String bundleName = ctx.getApplication().getMessageBundle();
            ResourceBundle message = ResourceBundle.getBundle(bundleName);
            msgValue = message.getString(messageKey);

            return msgValue;
        } catch (Exception e) {
            msgValue = messageKey;
            e.printStackTrace();
        }
        return messageKey;
    }

    public static String getMessage(String messageKey, String lang) {
        try {
            String msgValue = "";
            FacesContext ctx = FacesContext.getCurrentInstance();
            String bundleName = ctx.getApplication().getMessageBundle();

            ResourceBundle message = ResourceBundle.getBundle(bundleName, getLocale(lang));
            msgValue = message.getString(messageKey);

            return msgValue;
        } catch (Exception e) {
            //Utils.errorLogger(Utils.class, e);
            e.printStackTrace();
        }
        return messageKey;
    }

    public static User getCurrentUserFromSession() {
        User user = null;
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        if (session != null && session.getAttribute("user") != null) {
            user = (User) session.getAttribute("user");
        }

        return user;
    }

    public static Merchant getCurrentUserMerchant() {
        Merchant merchant = null;
        User user = Helper.getCurrentUserFromSession();
        if (user != null && user.getMerchant() != null) {
            merchant = user.getMerchant();
        }
        return merchant;
    }
    public static MerchantBranch getCurrentUserMerchantBranch() {
        MerchantBranch branch = null;
        User user = Helper.getCurrentUserFromSession();
        if (user != null && user.getMerchant() != null && user.getDepartment()!=null) {
            branch = user.getDepartment().getBranch();
        }
        return branch;
    }

    public static EntityManager getEntityManager() {

        EntityManager entityManager = Persistence.createEntityManagerFactory("CamelPU").createEntityManager();
        return entityManager;
    }

    public static String getUserNameAndSurname(Long userId) {
        String nameAndSurname = "";
        /*try{
         EntityManager em = getEntityManager();
         if(em!=null && em.isOpen()){
         User user = em.find(User.class, userId);
         nameAndSurname = user.getName() + " " + user.getLastname();
         }
         }catch(Exception e){
         e.printStackTrace();
         }*/

        return nameAndSurname;
    }

    public static JSONArray readRestService(String urlPath) {
        String result = "";
        Client client = null;
        WebResource webResource = null;
        ClientResponse response = null;
        try {
            client = Client.create();
            webResource = client.resource(urlPath);
            response = webResource.accept("application/json").get(ClientResponse.class);
            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
            }

            result = response.getEntity(String.class);
            return new JSONArray(result);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (response != null) {
                response.close();
            }
            webResource = null;
            response = null;
            client = null;
        }

        return null;
    }

    public static String utfConvStrEng(String str) {
        int unicodeIntValue = 0;
        String unicodeString = "";
        String ucValue = "";
        if (str == null) {
            return null;
        }
        try {
            int length = str.length();

            for (int i = 0; i < length; i++) {
                unicodeIntValue = str.charAt(i);

                if (unicodeIntValue == 38) {//& ile basliyorsa
                    ucValue = "" + str.charAt(i) + str.charAt(i + 1) + str.charAt(i + 2) + str.charAt(i + 3) + str.charAt(i + 4);
                    if (ucValue != null && ucValue.equals("&#304")) {
                        unicodeString += "I";
                        i = i + 5;
                        continue;
                    }
                    if (ucValue != null && ucValue.equals("&#305")) {
                        unicodeString += "i";
                        i = i + 5;
                        continue;
                    }
                    if (ucValue != null && ucValue.equals("&#214")) {
                        unicodeString += "O";
                        i = i + 5;
                        continue;
                    }
                    if (ucValue != null && ucValue.equals("&#246")) {
                        unicodeString += "o";
                        i = i + 5;
                        continue;
                    }
                    if (ucValue != null && ucValue.equals("&#220")) {
                        unicodeString += "U";
                        i = i + 5;
                        continue;
                    }
                    if (ucValue != null && ucValue.equals("&#252")) {
                        unicodeString += "u";
                        i = i + 5;
                        continue;
                    }
                    if (ucValue != null && ucValue.equals("&#199")) {
                        unicodeString += "C";
                        i = i + 5;
                        continue;
                    }
                    if (ucValue != null && ucValue.equals("&#231")) {
                        unicodeString += "c";
                        i = i + 5;
                        continue;
                    }
                    if (ucValue != null && ucValue.equals("&#286")) {
                        unicodeString += "G";
                        i = i + 5;
                        continue;
                    }
                    if (ucValue != null && ucValue.equals("&#287")) {
                        unicodeString += "g";
                        i = i + 5;
                        continue;
                    }
                    if (ucValue != null && ucValue.equals("&#350")) {
                        unicodeString += "S";
                        i = i + 5;
                        continue;
                    }
                    if (ucValue != null && ucValue.equals("&#351")) {
                        unicodeString += "s";
                        i = i + 5;
                        continue;
                    }
                }

                if (unicodeIntValue == 221 || unicodeIntValue == 304) {
                    unicodeString += "I";
                    continue;
                }
                if (unicodeIntValue == 253 || unicodeIntValue == 305) {
                    unicodeString += "i";
                    continue;
                }
                if (unicodeIntValue == 254 || unicodeIntValue == 351) {
                    unicodeString += "s";
                    continue;
                }
                if (unicodeIntValue == 222 || unicodeIntValue == 350) {
                    unicodeString += "S";
                    continue;
                }
                if (unicodeIntValue == 208 || unicodeIntValue == 286) {
                    unicodeString += "G";
                    continue;
                }
                if (unicodeIntValue == 240 || unicodeIntValue == 287) {
                    unicodeString += "g";
                    continue;
                }
                if (unicodeIntValue == 231) {
                    unicodeString += "c";
                    continue;
                }
                if (unicodeIntValue == 199) {
                    unicodeString += "C";
                    continue;
                }
                if (unicodeIntValue == 252) {
                    unicodeString += "u";
                    continue;
                }
                if (unicodeIntValue == 220) {
                    unicodeString += "U";
                    continue;
                }
                if (unicodeIntValue == 246) {
                    unicodeString += "o";
                    continue;
                }
                if (unicodeIntValue == 214) {
                    unicodeString += "O";
                    continue;
                }

                unicodeString += (char) unicodeIntValue;
            }
            return unicodeString;
        } catch (Exception e) {

            return "";
        }
    }

    public static String date2String(Date date) {
        if (date != null) {
            SimpleDateFormat sdf = new SimpleDateFormat();
            sdf.applyPattern("dd/MM/yyyy");
            return sdf.format(date);
        } else {
            return "";
        }
    }

    public static Date dateAddMinute(Date date, int minute) {
        Date newdate = date;
        try {
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            cal.add(Calendar.MINUTE, minute);
            newdate = cal.getTime();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return newdate;
    }

    public static Date dateAdd(Date date, int day) {
        Date newdate = date;
        try {
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            cal.add(Calendar.DATE, day);
            newdate = cal.getTime();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return newdate;
    }

    public static boolean getCurrentUserIsAdmin() {
        boolean isAdmin = false;
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        if (session != null && session.getAttribute("user") != null) {
            User user = (User) session.getAttribute("user");
            if (user.getUserType().equals(UserType.ADMIN)) {
                isAdmin = true;
            }
        }

        return isAdmin;
    }

    public static boolean hasRole(String role) {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        if (session != null && session.getAttribute("user") != null) {
            User user = (User) session.getAttribute("user");
            for(UserAuth auth:user.getUserAuths()){
                if(auth.getAuthCode().indexOf(role)>-1){
                    return true;
                }
            }
        }

        return false;
    }

    public static HashMap<String, Object> getParamsHashByMerchant() {
        HashMap<String, Object> params = new HashMap<String, Object>();
        Merchant merchant = getCurrentUserMerchant();
        params.put("mrchntid", merchant.getId());
        return params;

    }

    public static Date dateAddMonth(Date date, int month) {
        Date newdate = date;
        try {
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            cal.add(Calendar.MONTH, month);
            newdate = cal.getTime();

        } catch (Exception e) {
           e.printStackTrace();
        }
        return newdate;
    }

    public static Currency getCurrency(String currencyCode){
        Currency currency = null;
        try{
            currency = Currency.valueOf(currencyCode);
        }catch(IllegalArgumentException e){
            currency = null;
        }
        
        return currency;
    }
    
    public static double roundDecimal(double val){        
    
        try{    
            
            double newval = BigDecimal.valueOf(val).setScale(2,RoundingMode.HALF_UP).doubleValue();
            DecimalFormat df = new DecimalFormat("#.##",DecimalFormatSymbols.getInstance(Locale.ENGLISH));
            return new Double(df.format(newval));
        }catch(Exception e){
            System.out.println("roundecimal-error..:" + e.getMessage() + " val..:" + val);
        }
        
        return val;
    }
    
    public static boolean getCurrentUserIsMemberAdmin() {
        boolean isAdmin = false;
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        if (session != null && session.getAttribute("user") != null) {
            User user = (User) session.getAttribute("user");
            if (user.getMemberAdmin()) {
                isAdmin = true;
            }
        }

        return isAdmin;
    }
    
    public static Department getCurrentUserDepartment() {
        Department department = null;
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        if (session != null && session.getAttribute("user") != null) {
            User user = (User) session.getAttribute("user");
            department = user.getDepartment();
        }

        return department;
    }
    
    public static double dateDifferent(Date from, Date to, int differentType) {

        if (from == null) {
                from = new Date();
        }
        if (to == null) {
                to = new Date();
        }

        Calendar calendar1 = Calendar.getInstance();
        Calendar calendar2 = Calendar.getInstance();
        calendar1.setTime(from);
        calendar2.setTime(to);
        long milliseconds1 = calendar1.getTimeInMillis();
        long milliseconds2 = calendar2.getTimeInMillis();
        double diff = milliseconds2 - milliseconds1;

        double left = 0;
        if (differentType == Calendar.SECOND) {
                left = (diff / 1000l);
        } else if (differentType == Calendar.MINUTE) {
                left = (diff / (60l * 1000l));
        } else if (differentType == Calendar.HOUR) {
                left = (diff / (60l * 60l * 1000l));
        } else if (differentType == Calendar.DATE) {
                left = Helper.roundDecimal((diff / (24d * 60d * 60d * 1000d)));
        }else if (differentType == Calendar.MILLISECOND) {
                left = diff;
        }else if (differentType == Calendar.YEAR) {
                left = Helper.roundDouble((diff / (365d * 24d * 60d * 60d * 1000d)));
        }


        return left;
    }
    public static double roundDouble(double input){
        return Math.round(input * Math.pow(10, (double) 2.0)) / Math.pow(10, (double) 2.0);	
    }


        public static String getEncryptData(String data,String key){
        String strResult = "";
        AESCrypto aes = new AESCrypto(key);
        try {
            strResult = URLEncoder.encode(aes.encrypt(data.trim()),"UTF-8");
        } catch (UnsupportedEncodingException ex) {
        }
        
        return strResult; 
    }
    
    public static String getDecryptData(String data,String key){
        return getDecryptData(data, key, true);
    }
    public static String getDecryptData(String strToDecrypt,String key,boolean urlEncoded){
        String strResult = "";
        AESCrypto aes = new AESCrypto(key);
        try {
            if(urlEncoded){
                strToDecrypt = URLDecoder.decode(strToDecrypt, "UTF-8");
            }
            strResult = aes.decrypt(strToDecrypt.trim());
        } catch (UnsupportedEncodingException ex) {
        }
        
        
        return strResult; 
    }
    
    public static String date2String(Date date,String format) {
        if (date != null) {
            SimpleDateFormat sdf = new SimpleDateFormat();
            sdf.applyPattern(format);
            return sdf.format(date);
        } else {
            return "";
        }
    }

    public static Date string2Date(String strDate, String format){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        LocalDateTime time = LocalDate.parse(strDate, formatter).atStartOfDay();
        return  Date.from(time.atZone(ZoneId.of("Europe/Istanbul")).toInstant());

    }

    public static Date localDate2Date(LocalDate localDate){
        return  Date.from(localDate.atStartOfDay().atZone(ZoneId.of("Europe/Istanbul")).toInstant());
    }
}
