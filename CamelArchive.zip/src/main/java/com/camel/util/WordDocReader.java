/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JTextPane;
import javax.swing.text.StyledDocument;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

/**
 *
 * @author asenturk
 */
public class WordDocReader {

    public  File readWordDoc(String orginalFilePath, File newFile, String content) {
        FileInputStream fis = null;
        FileOutputStream out = null;
        try {
            JTextPane textPane = new JTextPane();
            textPane.setText(content);
            StyledDocument sdoc = textPane.getStyledDocument();
            
            fis = new FileInputStream(orginalFilePath);
            XWPFDocument doc = new XWPFDocument(fis);        
            XWPFParagraph paragraph = doc.createParagraph();
            XWPFRun run=paragraph.createRun();
            run.setText(sdoc.getText(0,sdoc.getEndPosition().getOffset()));
            
            
            out = new FileOutputStream(newFile); // yeni dosya oluşturuluyor. 
            doc.write(out);
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    
                    out.close();
                    
                    fis.close();
                    out = null;
                    fis = null;
                } catch (IOException ioEx) {
                    ioEx.printStackTrace();
                }
            }
        }
        return newFile;
    }

    

}
