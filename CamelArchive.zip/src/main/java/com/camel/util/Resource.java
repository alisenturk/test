/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.util;

import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author asenturk
 */
public class Resource {

    @Produces
    @PersistenceContext
    EntityManager em;
    
    public static final String    PROJECT_WEBSERVICE_PATH="http://localhost:8080/Patient/rest";
}
