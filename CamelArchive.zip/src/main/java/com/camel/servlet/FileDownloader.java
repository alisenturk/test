package com.camel.servlet;

import com.camel.util.Helper;
import com.google.gson.Gson;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author alisenturk
 */
@WebServlet(name = "FileDownloader", urlPatterns = {"/FileDownloader"})
public class FileDownloader extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException, IOException{
            
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
		
        String 	fileData	= request.getParameter("fileData");
        if(fileData!=null && fileData.length()>10){		
                try{
                        
                    String filePath 	= "";
                    String contentType 	= "";
                    String fileName		= "";

                    String key = Helper.SECRET_KEY;
                    String data = Helper.getDecryptData(fileData, key,false);
                    Gson gson = new Gson();
                    FileDownload fileDownload = gson.fromJson(data,FileDownload.class);

                    if(fileDownload!=null){
                        response.setContentType(fileDownload.getContentType()); 
                        response.addHeader("Content-Disposition", "attachment; filename=" + fileDownload.getFileName()); 
                        File 		file	= new File(fileDownload.getFilePath());
                        OutputStream 	out 	= response.getOutputStream();
                        FileInputStream fileIn = new FileInputStream(file);

                        byte[] outputByte = new byte[4096];					
                        while(fileIn.read(outputByte, 0, 4096) != -1)
                        {
                                out.write(outputByte, 0, 4096);
                        }
                        fileIn.close();
                        out.flush();
                        out.close();
                    }else{
                        processRequest(request, response);
                    }

                }catch(Exception e){
                }finally{
                }
        }else{
                response.getWriter().write("<h1>Üzgünüm, gönderdiğiniz parametreler hatalı!</h1>");			
        }

    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

}
