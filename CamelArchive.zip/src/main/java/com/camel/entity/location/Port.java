/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.entity.location;

import com.camel.entity.base.BaseEntity;
import com.camel.enums.PortType;
import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.validation.constraints.NotNull;


/**
 *
 * @author asenturk
 */
@Cacheable(true)
@Entity

@NamedQueries({
    @NamedQuery(name = "Port.findAll",query = "select d from Port d where d.status<>'DELETED' order by d.portType,d.country.countryName,d.portName",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Port.findPort",query = "select d from Port d where d.id=:id",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Port.findCountryPorts",query = "select d from Port d where d.country.id=:country and d.status<>'DELETED' order by d.portName ",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Port.findCountrySeaports",query = "select d from Port d where d.portType='SEAPORT' and d.country.id=:country and d.status<>'DELETED'",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Port.findCountryAirports",query = "select d from Port d where d.portType='AIRPORT' and d.country.id=:country and d.status<>'DELETED'",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")})
})
public class Port extends BaseEntity{
    
    private Country     country;
    private City        city;
    private PortType    portType;
    private String      portCode;
    private String      portName;

    @NotNull
    @ManyToOne
    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }


    @ManyToOne
    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    @NotNull
    @Enumerated(EnumType.STRING)
    public PortType getPortType() {
        return portType;
    }

    public void setPortType(PortType portType) {
        this.portType = portType;
    }

    @NotNull
    @Column(length = 256)
    public String getPortName() {
        return portName;
    }

    public void setPortName(String portName) {
        this.portName = portName;
    }

    @Column(length = 20)
    public String getPortCode() {
        return portCode;
    }

    public void setPortCode(String portCode) {
        this.portCode = portCode;
    }

    
    
    
}
