package com.camel.entity.visit;

import com.camel.entity.base.BaseEntity;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.User;
import com.camel.entity.customer.Contact;
import com.camel.entity.customer.Customer;
import com.camel.enums.VisitType;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author asenturk
 */
@Cacheable(true)
@Entity
@NamedQueries({
    @NamedQuery(name = "CustomerVisit.findAll",query = "select d from CustomerVisit d where d.merchant.id=:mrchntid and d.status<>'DELETED'",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "CustomerVisit.findCustomerAllVisit",query = "select d from CustomerVisit d where d.merchant.id=:mrchntid and d.customer.id=:custid and  d.status<>'DELETED' ORDER BY visitDate desc ",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")})
})

public class CustomerVisit extends BaseEntity{
    private Merchant    merchant;
    private User        visitor;
    private Customer    customer;
    private List<Contact> contacts = new ArrayList<>();
    private VisitType   visitType;
    private Date        visitDate;
    private VisitSubject      subject;
    private String      visitContent;

    @ManyToOne
    public Merchant getMerchant() {
        return merchant;
    }
    
    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    @ManyToOne
    public User getVisitor() {
        return visitor;
    }

    public void setVisitor(User visitor) {
        this.visitor = visitor;
    }
    
    @ManyToOne
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }


    @Enumerated(EnumType.STRING)
    public VisitType getVisitType() {
        return visitType;
    }

    public void setVisitType(VisitType visitType) {
        this.visitType = visitType;
    }

    @Temporal(TemporalType.DATE)
    public Date getVisitDate() {
        return visitDate;
    }

    public void setVisitDate(Date visitDate) {
        this.visitDate = visitDate;
    }


    @NotNull
    @Column(length = 4000)
    public String getVisitContent() {
        return visitContent;
    }

    public void setVisitContent(String visitContent) {
        this.visitContent = visitContent;
    }


    @ManyToOne
    public VisitSubject getSubject() {
        return subject;
    }

    public void setSubject(VisitSubject subject) {
        this.subject = subject;
    }


    @ManyToMany
    @JoinColumn(name="visit_id")
    @OrderColumn(name = "orderid")
    public List<Contact> getContacts() {
        return contacts;
    }

    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
    }
}
