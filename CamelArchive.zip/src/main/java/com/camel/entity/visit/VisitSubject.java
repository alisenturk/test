package com.camel.entity.visit;

import com.camel.entity.base.BaseEntity;
import com.camel.entity.base.Merchant;

import javax.persistence.*;



@Cacheable(value = true)
@Entity
@NamedQueries({
        @NamedQuery(name = "VisitSubject.findAll",query = "select d from VisitSubject d where d.merchant.id=:mrchntid and d.status<>'DELETED'",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")})
})

public class VisitSubject extends BaseEntity {
    private Merchant    merchant;
    private String      subject;


    @ManyToOne
    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }


}
