package com.camel.entity.project;

public enum ProjectFileType {

    OTHER("OTHER","Other");

    private String value;
    private String label;

    ProjectFileType(String value,String label){
        this.value    = value;
        this.label  = label;
    }

    public String getValue() {
        return value;
    }


    public String getLabel() {
        return label;
    }


}
