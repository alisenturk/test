package com.camel.entity.project;

public enum ProjectStage {

    PLANING("PLANING","Planing"),
    POSTPONED("POSTPONED","Postponed"),
    ONGOING("ONGOING","Ongoing"),
    COMPLETED("COMPLETED","Completed");

    private String  key;
    private String  value;

    ProjectStage(String key,String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }


    public String getValue() {
        return value;
    }

}
