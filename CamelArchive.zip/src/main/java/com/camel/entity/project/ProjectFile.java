package com.camel.entity.project;

import com.camel.entity.base.BaseEntity;

import javax.persistence.*;


@Entity
@NamedQueries({
        @NamedQuery(name = "ProjectFile.findAll",query = "select d from ProjectFile d where d.project.id =:prjctid and d.status<>'DELETED'")
})

public class ProjectFile extends BaseEntity {

    private Project         project;
    private ProjectFileType projectFileType;
    private String          fileName;
    private String          filePath;
    private String          fileType;
    private String          fileMimeType;

    @ManyToOne(fetch = FetchType.LAZY)
    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    @Enumerated(EnumType.STRING)
    public ProjectFileType getProjectFileType() {
        return projectFileType;
    }

    public void setProjectFileType(ProjectFileType projectFileType) {
        this.projectFileType = projectFileType;
    }

    @Column(length=60)
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @Column(length = 512)
    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    @Column(length = 10)
    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    @Column(length = 200)
    public String getFileMimeType() {
        return fileMimeType;
    }

    public void setFileMimeType(String fileMimeType) {
        this.fileMimeType = fileMimeType;
    }
}

