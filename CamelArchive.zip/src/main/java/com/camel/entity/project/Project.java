package com.camel.entity.project;

import com.camel.entity.base.*;
import com.camel.entity.location.Country;
import com.camel.enums.Currency;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@NamedQueries({
        @NamedQuery(name = "Project.findAll",query = "select d from Project d where d.merchant.id=:mrchntid and d.status<>'DELETED' order by d.projectName ")
})

public class Project extends BaseEntity {

    private Merchant            merchant;
    private MerchantBranch      branch;
    private Department          department;
    private String              projectName;
    private String              projectExplanation;
    private ProjectCategory     category;
    private Country             country;
    private Date                expectedStartDate;
    private Date                startDate;
    private Date                expectedCompletionDate;
    private Date                completionDate;

    private Double              projectValue;
    private Currency            projectCurrency;
    private Double              expectedLogisticsTurnover;
    private Currency            turnoverCurrency;

    private User                projectOwner;

    private ProjectStage        stage;

    private List<ProjectFile> projectFiles = new ArrayList<>();


    @ManyToOne(fetch = FetchType.LAZY)
    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public MerchantBranch getBranch() {
        return branch;
    }

    public void setBranch(MerchantBranch branch) {
        this.branch = branch;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }


    @NotNull
    @Column(length = 100)
    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    @NotNull
    @Column(length = 4000)
    public String getProjectExplanation() {
        return projectExplanation;
    }

    public void setProjectExplanation(String projectExplanation) {
        this.projectExplanation = projectExplanation;
    }

    @Enumerated(EnumType.STRING)
    public ProjectCategory getCategory() {
        return category;
    }

    public void setCategory(ProjectCategory category) {
        this.category = category;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    @Temporal(TemporalType.DATE)
    public Date getExpectedStartDate() {
        return expectedStartDate;
    }

    public void setExpectedStartDate(Date expectedStartDate) {
        this.expectedStartDate = expectedStartDate;
    }

    @Temporal(TemporalType.DATE)
    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    @Temporal(TemporalType.DATE)
    public Date getExpectedCompletionDate() {
        return expectedCompletionDate;
    }

    public void setExpectedCompletionDate(Date expectedCompletionDate) {
        this.expectedCompletionDate = expectedCompletionDate;
    }

    @Temporal(TemporalType.DATE)
    public Date getCompletionDate() {
        return completionDate;
    }

    public void setCompletionDate(Date completionDate) {
        this.completionDate = completionDate;
    }

    public Double getProjectValue() {
        return projectValue;
    }

    public void setProjectValue(Double projectValue) {
        this.projectValue = projectValue;
    }

    @Enumerated(EnumType.STRING)
    public Currency getProjectCurrency() {
        return projectCurrency;
    }

    public void setProjectCurrency(Currency projectCurrency) {
        this.projectCurrency = projectCurrency;
    }

    public Double getExpectedLogisticsTurnover() {
        return expectedLogisticsTurnover;
    }

    public void setExpectedLogisticsTurnover(Double expectedLogisticsTurnover) {
        this.expectedLogisticsTurnover = expectedLogisticsTurnover;
    }

    @Enumerated(EnumType.STRING)
    public Currency getTurnoverCurrency() {
        return turnoverCurrency;
    }

    public void setTurnoverCurrency(Currency turnoverCurrency) {
        this.turnoverCurrency = turnoverCurrency;
    }

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    public User getProjectOwner() {
        return projectOwner;
    }

    public void setProjectOwner(User projectOwner) {
        this.projectOwner = projectOwner;
    }

    @Enumerated(EnumType.STRING)
    public ProjectStage getStage() {
        return stage;
    }

    public void setStage(ProjectStage stage) {
        this.stage = stage;
    }

    @OneToMany(mappedBy = "project")
    public List<ProjectFile> getProjectFiles() {
        return projectFiles;
    }

    public void setProjectFiles(List<ProjectFile> projectFiles) {
        this.projectFiles = projectFiles;
    }
}

