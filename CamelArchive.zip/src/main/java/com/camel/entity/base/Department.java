/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.entity.base;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.validation.constraints.NotNull;

/**
 *
 * @author asenturk
 */
@Cacheable(true)
@Entity
@NamedQueries({
    @NamedQuery(name = "Department.findAll",query = "select d from Department d where d.status<>'DELETED'",hints={@QueryHint(name="org.hibernate.cacheable",value="true") }),
    @NamedQuery(name = "Department.findAllMerchantDepartments",query = "select d from Department d where d.merchant.id=:mrchntid and d.status<>'DELETED'",hints={@QueryHint(name="org.hibernate.cacheable",value="true")}),
    @NamedQuery(name = "Department.findAllMerchantBranchDepartments",query = "select d from Department d where d.merchant.id=:mrchntid and d.branch.id=:brnchid and d.status<>'DELETED'",hints={@QueryHint(name="org.hibernate.cacheable",value="true")})
})

public class Department extends BaseEntity{

    private Merchant        merchant;
    private MerchantBranch  branch;
    private String          departmentName;
    private Boolean         charter = false;
    
    @NotNull
    @Column(length = 60)
    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    @NotNull
    @ManyToOne
    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    @NotNull
    @ManyToOne
    public MerchantBranch getBranch() {
        return branch;
    }

    public void setBranch(MerchantBranch branch) {
        this.branch = branch;
    }

    @Column(nullable = false, columnDefinition = "TINYINT(1)")    
    public Boolean getCharter() {
        return charter;
    }

    public void setCharter(Boolean charter) {
        this.charter = charter;
    }

    
    
    
    
}
