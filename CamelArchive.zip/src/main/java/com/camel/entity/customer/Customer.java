/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.entity.customer;

import com.camel.entity.base.BaseEntity;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.Sector;
import com.camel.entity.location.Country;
import com.camel.enums.CustomerType;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author asenturk
 */
@Cacheable(true)
@Entity
@NamedQueries({
    @NamedQuery(name = "Customer.findAll",query = "select d from Customer d where d.merchant.id=:mrchntid and d.status<>'DELETED' order by customerName",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Customer.findAllActive",query = "select d from Customer d where d.merchant.id=:mrchntid and d.status = 'ACTIVE' order by customerName",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Customer.findCustomersByType",query = "select d from Customer d where d.merchant.id=:mrchntid and d.status<>'DELETED' and d.customerType=:custType",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),    
    @NamedQuery(name = "Customer.findAllSuppliers",query = "select d from Customer d where d.merchant.id=:mrchntid and d.status<>'DELETED' and d.isSupplier=true ",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),    
    @NamedQuery(name = "Customer.findCustomer",query = "select d from Customer d where d.id=:customer and d.merchant.id=:mrchntid ",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Customer.findCustomerByName",query = "select d from Customer d where d.merchant.id=:mrchntid and d.customerName LIKE CONCAT('%',:pcustomerName ,'%') and d.id !=:custid and d.status<>'DELETED' ",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")})
})

public class Customer extends BaseEntity{

    private Merchant    merchant;
    private String      customerName;
    private String      companyName;
    private String      email;
    private String      phone;
    private String      website;
    private CustomerType customerType;
    private Sector      sector; 
    private Country     country;
    private List<Contact> contacts = new ArrayList<Contact>();
    private Boolean     isSupplier = false;
    private Customer     mainCompany;
    private String       taxOffice;
    private String       taxNumber;

    @NotNull
    @Column(length = 120)
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    @Column(length = 120)
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Column(length = 20)
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Column(length = 120)
    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    @OneToMany(mappedBy = "customer")
    public List<Contact> getContacts() {
        return contacts;
    }

    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
    }
    

    @NotNull
    @Enumerated(EnumType.STRING)
    public CustomerType getCustomerType() {
        return customerType;
    }

    public void setCustomerType(CustomerType customerType) {
        this.customerType = customerType;
    }

    @ManyToOne
    public Sector getSector() {
        return sector;
    }

    public void setSector(Sector sector) {
        this.sector = sector;
    }

    @Column(length =512)
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    @ManyToOne
    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    @Column(nullable = false, columnDefinition = "TINYINT(1)")    
    public Boolean getIsSupplier() {
        return isSupplier;
    }

    public void setIsSupplier(Boolean isSupplier) {
        this.isSupplier = isSupplier;
    }

    @ManyToOne
    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Customer getMainCompany() {
        return mainCompany;
    }

    public void setMainCompany(Customer mainCompany) {
        this.mainCompany = mainCompany;
    }

    @Column(length = 256)
    public String getTaxOffice() {
        return taxOffice;
    }

    public void setTaxOffice(String taxOffice) {
        this.taxOffice = taxOffice;
    }

    @Column(length = 20)
    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber;
    }
}
