/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.entity.customer;

import com.camel.entity.base.BaseEntity;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.MerchantBranch;
import com.camel.enums.ContactType;
import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;


/**
 *
 * @author asenturk
 */
@Cacheable(true)
@Entity
@NamedQueries({
    @NamedQuery(name = "Contact.findAll",query = "select d from Contact d where d.merchant.id=:mrchntid and d.status<>'DELETED'",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Contact.findCustomerContacts",query = "select d from Contact d where d.merchant.id=:mrchntid and d.customer.id=:custid and d.status<>'DELETED'",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Contact.findCustomerContactsActive",query = "select d from Contact d where d.merchant.id=:mrchntid and d.customer.id=:custid and d.status = 'ACTIVE'",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Contact.findSalesTeam",query = "select d from Contact d where d.merchant.id=:mrchntid and d.contactType='SALESTEAM' and d.status<>'DELETED'",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Contact.findMerchantSalesTeam",query = "select d from Contact d where d.merchant.id=:mrchntid and d.contactType='SALESTEAM' and d.status<>'DELETED'",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Contact.findMerchantSalesTeamActive",query = "select d from Contact d where d.merchant.id=:mrchntid and d.contactType='SALESTEAM' and d.status = 'ACTIVE' ",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")}),
    @NamedQuery(name = "Contact.findContact",query = "select d from Contact d where d.id=:personelId",hints={@QueryHint(name="javax.persistence.query.timeout", value="1800000")})    
})

public class Contact extends BaseEntity{
    
    private Merchant    merchant;
    private MerchantBranch  branch;
    private Customer    customer;
    private ContactType     contactType;
    private String      name;
    private String      surname;
    private String      email;
    private String      phone;

    public Contact() {
    }

    public Contact(Customer customer,ContactType cntcType) {
        this.customer = customer;
    }

    @ManyToOne
    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    @ManyToOne
    public MerchantBranch getBranch() {
        return branch;
    }

    public void setBranch(MerchantBranch branch) {
        this.branch = branch;
    }

    @ManyToOne
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @NotNull
    @Column(length = 60)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotNull
    @Column(length = 60)
    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    @NotNull
    @Column(length = 120)
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Column(length = 20)
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Enumerated(EnumType.STRING)
    public ContactType getContactType() {
        return contactType;
    }

    public void setContactType(ContactType contactType) {
        this.contactType = contactType;
    }
    
    @Transient
    public String getContactName(){
        return (name + " " + surname);
    }
}
