package com.camel.entity.inquiry;

import com.camel.entity.base.BaseEntity;
import com.camel.enums.BidMode;
import com.camel.enums.BulkType;
import com.camel.enums.Currency;
import com.camel.enums.DeckOption;
import com.camel.enums.Stackability;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;


/**
 * @author alisenturk
 */

@Entity
@NamedQueries({
    @NamedQuery(name = "InquiryBid.findAll",query = "select d from InquiryBid d where d.inquiry.id =:inqryid and d.status<>'DELETED'")
})

public class InquiryBid extends BaseEntity implements Cloneable{
    
    private Inquiry         inquiry;
    private BidMode         mode;
    private String          commodity;
    private String          volume;
    private DeckOption      deckOption;
    private Stackability    stackability;
    private InquiryBidTerms terms;
    private double          targetRate;
    private Currency        targetCurrency;
    private BulkType        targetBulkType;
    private String          remarks;

    @ManyToOne
    public Inquiry getInquiry() {
        return inquiry;
    }

    public void setInquiry(Inquiry inquiry) {
        this.inquiry = inquiry;
    }

    @Enumerated(EnumType.STRING)
    public BidMode getMode() {
        return mode;
    }

    public void setMode(BidMode mode) {
        this.mode = mode;
    }

    @NotNull
    @Column(length = 3000)
    public String getCommodity() {
        return commodity;
    }

    public void setCommodity(String commodity) {
        this.commodity = commodity;
    }

    @NotNull
    @Column(length = 3000)
    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    @Enumerated(EnumType.STRING)
    public DeckOption getDeckOption() {
        return deckOption;
    }

    public void setDeckOption(DeckOption deckOption) {
        this.deckOption = deckOption;
    }
    
    @Enumerated(EnumType.STRING)
    public Stackability getStackability() {
        return stackability;
    }

    public void setStackability(Stackability stackability) {
        this.stackability = stackability;
    }

    @ManyToOne
    public InquiryBidTerms getTerms() {
        return terms;
    }

    public void setTerms(InquiryBidTerms terms) {
        this.terms = terms;
    }

    public double getTargetRate() {
        return targetRate;
    }

    public void setTargetRate(double targetRate) {
        this.targetRate = targetRate;
    }

    @Enumerated(EnumType.STRING)
    public Currency getTargetCurrency() {
        return targetCurrency;
    }

    public void setTargetCurrency(Currency targetCurrency) {
        this.targetCurrency = targetCurrency;
    }

    @Enumerated(EnumType.STRING)
    public BulkType getTargetBulkType() {
        return targetBulkType;
    }

    public void setTargetBulkType(BulkType targetBulkType) {
        this.targetBulkType = targetBulkType;
    }

    @Column(length = 3000)
    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone(); 
    }
    
    
    
        
}
