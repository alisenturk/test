package com.camel.entity.inquiry.other;


import com.camel.entity.base.BaseEntity;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.User;
import com.camel.entity.customer.Contact;
import com.camel.entity.customer.Customer;
import com.camel.entity.location.City;
import com.camel.entity.location.Country;
import com.camel.entity.location.Port;
import com.camel.enums.CustomsType;
import com.camel.enums.InquirySource;
import com.camel.enums.InquiryStatus;
import com.camel.enums.InquiryType;
import com.camel.enums.TransportMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PostPersist;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;


/**
 *
 * @author asenturk
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "InquiryOther.findAll",query = "select d from InquiryOther d where d.status<>'DELETED'")    
})

public class InquiryOther extends BaseEntity{
    
    private String          inquiryCode;
    private String          inquiryDescription;
    private User            responsible;
    private Customer        customer;
    private InquirySource   inquirySource;
    private Contact         inquiryOwner;
    private Date            requestDate;
    private Date            offerDate;
    private Date            offerDeadline;
    private CustomsType     customsType;
    private TransportMode   transportMode;
    private Date            loadingDate;
    private Country         loadingCountry;
    private City            loadingCity;
    private Port            loadingPort;
    private Date            unloadingDate;
    private Country         unloadingCountry;
    private City            unloadingCity;
    private Port            unloadingPort;
    private String          shortDescription;    
    private InquiryStatus   inquiryStatus;
    private InquiryType     inquiryType;
    private Merchant        merchant;
    
    
    private List<InquiryOtherFile> inquiryFiles = new ArrayList<InquiryOtherFile>();
    
    @PostPersist
    private void onPostPersist(){
        setInquiryCode("INQ"+getId());
    }
    
    
    @Column(length = 20)
    public String getInquiryCode() {
        return inquiryCode;
    }

    public void setInquiryCode(String inquiryCode) {
        this.inquiryCode = inquiryCode;
    }

    @NotNull
    @Column(length = 100)
    public String getInquiryDescription() {
        return inquiryDescription;
    }

    public void setInquiryDescription(String inquiryDescription) {
        this.inquiryDescription = inquiryDescription;
    }

    
    
    @NotNull
    @ManyToOne    
    public User getResponsible() {
        return responsible;
    }

    public void setResponsible(User responsible) {
        this.responsible = responsible;
    }

    @NotNull
    @Temporal(TemporalType.DATE)
    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    @Temporal(TemporalType.DATE)
    public Date getOfferDate() {
        return offerDate;
    }

    public void setOfferDate(Date offerDate) {
        this.offerDate = offerDate;
    }

    @Temporal(TemporalType.DATE)
    public Date getLoadingDate() {
        return loadingDate;
    }

    public void setLoadingDate(Date loadingDate) {
        this.loadingDate = loadingDate;
    }

    @ManyToOne
    public Country getLoadingCountry() {
        return loadingCountry;
    }

    public void setLoadingCountry(Country loadingCountry) {
        this.loadingCountry = loadingCountry;
    }

    @ManyToOne
    public City getLoadingCity() {
        return loadingCity;
    }

    public void setLoadingCity(City loadingCity) {
        this.loadingCity = loadingCity;
    }

    @Column(length = 4000)
    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    @Enumerated(EnumType.STRING)
    public InquirySource getInquirySource() {
        return inquirySource;
    }

    public void setInquirySource(InquirySource inquirySource) {
        this.inquirySource = inquirySource;
    }

    @Enumerated(EnumType.STRING)
    public TransportMode getTransportMode() {
        return transportMode;
    }

    public void setTransportMode(TransportMode transportMode) {
        this.transportMode = transportMode;
    }

    @Enumerated(EnumType.STRING)
    public CustomsType getCustomsType() {
        return customsType;
    }

    public void setCustomsType(CustomsType customsType) {
        this.customsType = customsType;
    }

    @Enumerated(EnumType.STRING)
    public InquiryStatus getInquiryStatus() {
        return inquiryStatus;
    }

    public void setInquiryStatus(InquiryStatus inquiryStatus) {
        this.inquiryStatus = inquiryStatus;
    }

    @ManyToOne
    public Contact getInquiryOwner() {
        return inquiryOwner;
    }

    public void setInquiryOwner(Contact inquiryOwner) {
        this.inquiryOwner = inquiryOwner;
    }

    @ManyToOne
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Temporal(TemporalType.DATE)
    public Date getOfferDeadline() {
        return offerDeadline;
    }

    public void setOfferDeadline(Date offerDeadline) {
        this.offerDeadline = offerDeadline;
    }

    @ManyToOne
    public Port getLoadingPort() {
        return loadingPort;
    }

    public void setLoadingPort(Port loadingPort) {
        this.loadingPort = loadingPort;
    }

    @Temporal(TemporalType.DATE)
    public Date getUnloadingDate() {
        return unloadingDate;
    }

    public void setUnloadingDate(Date unloadingDate) {
        this.unloadingDate = unloadingDate;
    }

    @ManyToOne
    public Country getUnloadingCountry() {
        return unloadingCountry;
    }

    public void setUnloadingCountry(Country unloadingCountry) {
        this.unloadingCountry = unloadingCountry;
    }

    @ManyToOne
    public City getUnloadingCity() {
        return unloadingCity;
    }

    public void setUnloadingCity(City unloadingCity) {
        this.unloadingCity = unloadingCity;
    }

    @ManyToOne
    public Port getUnloadingPort() {
        return unloadingPort;
    }

    public void setUnloadingPort(Port unloadingPort) {
        this.unloadingPort = unloadingPort;
    }

    @Enumerated(EnumType.STRING)
    public InquiryType getInquiryType() {
        return inquiryType;
    }

    public void setInquiryType(InquiryType inquiryType) {
        this.inquiryType = inquiryType;
    }

    @ManyToOne
    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    @OneToMany(mappedBy = "inquiry")
    public List<InquiryOtherFile> getInquiryFiles() {
        return inquiryFiles;
    }

    public void setInquiryFiles(List<InquiryOtherFile> inquiryFiles) {
        this.inquiryFiles = inquiryFiles;
    }

    
}
