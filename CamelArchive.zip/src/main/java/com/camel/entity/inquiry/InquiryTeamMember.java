/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.entity.inquiry;

import com.camel.entity.base.BaseEntity;
import com.camel.entity.base.User;
import com.camel.enums.MemberType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.validation.constraints.NotNull;


/**
 *
 * @author alisenturk
 */

@Entity
@NamedQueries({
    @NamedQuery(name = "InquiryTeamMember.findAll",query = "select d from InquiryTeamMember d where d.inquiry.id =:inqryid and d.status<>'DELETED'")
})

public class InquiryTeamMember extends BaseEntity implements Cloneable{
    
    private Inquiry     inquiry;
    private User        member;
    private MemberType  memberType;
    private Boolean     edit;   

    @ManyToOne
    public Inquiry getInquiry() {
        return inquiry;
    }

    public void setInquiry(Inquiry inquiry) {
        this.inquiry = inquiry;
    }
    
    @NotNull
    @ManyToOne    
    public User getMember() {
        return member;
    }

    public void setMember(User member) {
        this.member = member;
    }

    @Enumerated(EnumType.STRING)
    public MemberType getMemberType() {
        return memberType;
    }

    public void setMemberType(MemberType memberType) {
        this.memberType = memberType;
    }

    @Column(nullable = false, columnDefinition = "TINYINT(1)")    
    public Boolean getEdit() {
        return edit;
    }

    public void setEdit(Boolean edit) {
        this.edit = edit;
    }

   

    
    
}
