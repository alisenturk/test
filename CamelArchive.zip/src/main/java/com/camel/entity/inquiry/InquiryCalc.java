/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.entity.inquiry;

import com.camel.entity.base.BaseEntity;
import com.camel.entity.customer.Customer;
import com.camel.enums.CalcItemType;
import com.camel.enums.CalculationType;
import com.camel.enums.Currency;
import com.camel.util.Helper;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


/**
 *
 * @author asenturk
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "InquiryCalc.findAll",query = "select d from InquiryCalc d where d.inquiry.id =:inqryid and d.status<>'DELETED'"),
    @NamedQuery(name = "InquiryCalc.findCostAll",query = "select d from InquiryCalc d where d.inquiry.id =:inqryid and d.calcType='COST' and d.status<>'DELETED' order by d.calcType, d.calcItemType desc,d.calcItem  "),
    @NamedQuery(name = "InquiryCalc.findSellingAll",query = "select d from InquiryCalc d where d.inquiry.id =:inqryid and d.calcType='SELLING' and d.status<>'DELETED' order by d.calcType, d.calcItemType desc,d.calcItem ")
})

public class InquiryCalc extends BaseEntity implements Cloneable{

    private Inquiry         inquiry;
    private CalculationType calcType;
    private CalcItemType    calcItemType = CalcItemType.ORGIN;
    private CalcItem        calcItem;
    private Double          rate = 0d;
    private Currency        currency = Currency.TRY;
    private Double          param1 = 1d;
    private Double          param2 = 1d;
    private Double          vat = 0d;
    private Double          total = 0d;
    private Double          dailyExchangeTRYRate = 1d;
    private Date            dailyExchangeDate;
    private Double          totalAsTRY=0d;
    private Customer        supplier;    
    private String          paymentTerm;
    private String          remark;

    public InquiryCalc(Inquiry inquiry, CalculationType calcType,CalcItemType calcItemType) {
        this.inquiry        = inquiry;
        this.calcType       = calcType;
        this.calcItemType   = calcItemType;
    }
    public InquiryCalc(Inquiry inquiry, CalculationType calcType,CalcItemType calcItemType,Currency currency,Date dailyExchDate) {
        this.inquiry        = inquiry;
        this.calcType       = calcType;
        this.calcItemType   = calcItemType;
        this.currency       = currency;
        this.dailyExchangeDate = dailyExchDate;
        this.rate           = 0d;
        this.param1         = 1d;
        this.total          = 0d;
        this.dailyExchangeTRYRate = 1d;
    }
    public InquiryCalc() {
        super();
    }    

    @Enumerated(EnumType.STRING)
    public CalculationType getCalcType() {
        return calcType;
    }

    public void setCalcType(CalculationType calcType) {
        this.calcType = calcType;
    }
     
    @ManyToOne
    public Inquiry getInquiry() {
        return inquiry;
    }

    public void setInquiry(Inquiry inquiry) {
        this.inquiry = inquiry;
    }

    @Enumerated(EnumType.STRING)
    public CalcItemType getCalcItemType() {
        return calcItemType;
    }

    public void setCalcItemType(CalcItemType calcItemType) {
        this.calcItemType = calcItemType;
    }

        

    @ManyToOne
    public CalcItem getCalcItem() {
        return calcItem;
    }

    public void setCalcItem(CalcItem calcItem) {
        this.calcItem = calcItem;
    }

    public Double getRate() {
        return rate;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }

    @Enumerated(EnumType.STRING)
    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public Double getParam1() {
        return param1;
    }

    public void setParam1(Double param1) {
        this.param1 = param1;
    }

    public Double getParam2() {
        return param2;
    }

    public void setParam2(Double param2) {
        this.param2 = param2;
    }

    public Double getVat() {
        return vat;
    }

    public void setVat(Double vat) {
        this.vat = vat;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    @ManyToOne
    public Customer getSupplier() {
        return supplier;
    }

    public void setSupplier(Customer supplier) {
        this.supplier = supplier;
    }

    @Column(length = 256)
    public String getPaymentTerm() {
        return paymentTerm;
    }

    public void setPaymentTerm(String paymentTerm) {
        this.paymentTerm = paymentTerm;
    }

    @Column(length = 256)
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Double getDailyExchangeTRYRate() {
        return dailyExchangeTRYRate;
    }

    public void setDailyExchangeTRYRate(Double dailyExchangeTRYRate) {
        this.dailyExchangeTRYRate = dailyExchangeTRYRate;
    }
  
    @Transient
    public void getCalcTotal(){
        if(param1==0)param1=1d;
        if(param2==0)param2=1d;

        total = rate * param1 * param2 * vat;
    }

    @Transient
    public Double getTotalAsTRY() {
        totalAsTRY = Helper.roundDecimal(getTotal() * getDailyExchangeTRYRate());
        return totalAsTRY;
    }

    public void setTotalAsTRY(Double totalAsTRY) {
        this.totalAsTRY = totalAsTRY;
    }
    
    
    
    @Override
    public InquiryCalc clone() throws CloneNotSupportedException {
        return (InquiryCalc)super.clone(); //To change body of generated methods, choose Tools | Templates.
    }

    @Temporal(TemporalType.DATE)
    public Date getDailyExchangeDate() {
        return dailyExchangeDate;
    }

    public void setDailyExchangeDate(Date dailyExchangeDate) {
        this.dailyExchangeDate = dailyExchangeDate;
    }
    
    
}
