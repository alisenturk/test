package com.camel.entity.inquiry;

import com.camel.entity.base.BaseEntity;
import com.camel.entity.base.Department;
import com.camel.entity.base.Merchant;
import com.camel.entity.base.MerchantBranch;
import com.camel.entity.base.User;
import com.camel.entity.customer.Contact;
import com.camel.entity.customer.Customer;
import com.camel.entity.location.City;
import com.camel.entity.location.Country;
import com.camel.entity.location.Port;
import com.camel.entity.project.Project;
import com.camel.enums.*;
import com.camel.util.Helper;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PostPersist;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;


/**
 *
 * @author asenturk
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "Inquiry.findAll",query = "select d from Inquiry d where d.status<>'DELETED'"),
    @NamedQuery(name = "Inquiry.findCustomerTop10Inquiry",query = "select d from Inquiry d where d.merchant.id=:mrchntid and d.customer.id=:custid and d.status<>'DELETED' ORDER BY inquiryCode desc"),
    @NamedQuery(name = "Inquiry.findProjectInquiries",query = "select d from Inquiry d where d.merchant.id=:mrchntid and d.project.id=:projectid and d.status<>'DELETED' ORDER BY inquiryCode desc")
})

public class Inquiry extends BaseEntity{
    
    private String          inquiryCode;
    private String          inquiryDescription;
    private User            responsible;
    private Customer        customer;
    private InquirySource   inquirySource;
    private Contact         inquiryOwner;
    private Date            requestDate;
    private Date            offerDate;
    private Date            offerDeadline;
    private CustomsType     customsType;
    private TransportMode   transportMode;
    private Date            loadingDate;
    private Country         loadingCountry;
    private City            loadingCity;
    private Port            loadingPort;
    private Date            unloadingDate;
    private Country         unloadingCountry;
    private City            unloadingCity;
    private Port            unloadingPort;
    private String          shortDescription;    
    private InquiryStatus   inquiryStatus;
    private InquiryType     inquiryType;
    private Merchant        merchant;
    private int             importance  = 0;
    private Double          cost        = 0d;
    private Double          price       = 0d;
    private Double          rate        = 0d;
    private Double          benefit     = 0d;
    private Currency        currency    = Currency.USD;
    private String          fileCode  ;
    private InquiryScale    inquiryScale = InquiryScale.PROJECT;
    
    private List<InquiryFile> inquiryFiles = new ArrayList<InquiryFile>();
    private List<InquiryCalc> inquiryCalcs = new ArrayList<InquiryCalc>();
    private List<InquiryTeamMember> inquiryTeamMembers = new ArrayList<InquiryTeamMember>();
    
    private MerchantBranch  branch;
    private Department      department;

    private Double          offerCost       = 0d;
    private Double          offerValue      = 0d;
    private Currency        offerCurrency   = Currency.USD;
    private Double          offerBenefit    = 0d;

    private InquiryWorkScope scopeOfWork;

    private Project         project;

    @PostPersist
    private void onPostPersist(){
        setInquiryCode("INQ"+getId());
    }

    @Column(length = 20)
    public String getInquiryCode() {
        return inquiryCode;
    }

    public void setInquiryCode(String inquiryCode) {
        this.inquiryCode = inquiryCode;
    }

    @NotNull
    @Column(length = 100)
    public String getInquiryDescription() {
        return inquiryDescription;
    }

    public void setInquiryDescription(String inquiryDescription) {
        this.inquiryDescription = inquiryDescription;
    }
    
    @NotNull
    @ManyToOne
    public User getResponsible() {
        return responsible;
    }

    public void setResponsible(User responsible) {
        this.responsible = responsible;
    }

    @NotNull
    @Temporal(TemporalType.DATE)
    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    @Temporal(TemporalType.DATE)
    public Date getOfferDate() {
        return offerDate;
    }

    public void setOfferDate(Date offerDate) {
        this.offerDate = offerDate;
    }

    @Temporal(TemporalType.DATE)
    public Date getLoadingDate() {
        return loadingDate;
    }

    public void setLoadingDate(Date loadingDate) {
        this.loadingDate = loadingDate;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Country getLoadingCountry() {
        return loadingCountry;
    }

    public void setLoadingCountry(Country loadingCountry) {
        this.loadingCountry = loadingCountry;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public City getLoadingCity() {
        return loadingCity;
    }

    public void setLoadingCity(City loadingCity) {
        this.loadingCity = loadingCity;
    }

    @Column(length = 4000)
    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    @Enumerated(EnumType.STRING)
    public InquirySource getInquirySource() {
        return inquirySource;
    }

    public void setInquirySource(InquirySource inquirySource) {
        this.inquirySource = inquirySource;
    }

    @Enumerated(EnumType.STRING)
    public TransportMode getTransportMode() {
        return transportMode;
    }

    public void setTransportMode(TransportMode transportMode) {
        this.transportMode = transportMode;
    }

    @Enumerated(EnumType.STRING)
    public CustomsType getCustomsType() {
        return customsType;
    }

    public void setCustomsType(CustomsType customsType) {
        this.customsType = customsType;
    }

    @Enumerated(EnumType.STRING)
    public InquiryStatus getInquiryStatus() {
        return inquiryStatus;
    }

    public void setInquiryStatus(InquiryStatus inquiryStatus) {
        this.inquiryStatus = inquiryStatus;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Contact getInquiryOwner() {
        return inquiryOwner;
    }

    public void setInquiryOwner(Contact inquiryOwner) {
        this.inquiryOwner = inquiryOwner;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Temporal(TemporalType.DATE)
    public Date getOfferDeadline() {
        return offerDeadline;
    }

    public void setOfferDeadline(Date offerDeadline) {
        this.offerDeadline = offerDeadline;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Port getLoadingPort() {
        return loadingPort;
    }

    public void setLoadingPort(Port loadingPort) {
        this.loadingPort = loadingPort;
    }

    @Temporal(TemporalType.DATE)
    public Date getUnloadingDate() {
        return unloadingDate;
    }

    public void setUnloadingDate(Date unloadingDate) {
        this.unloadingDate = unloadingDate;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Country getUnloadingCountry() {
        return unloadingCountry;
    }

    public void setUnloadingCountry(Country unloadingCountry) {
        this.unloadingCountry = unloadingCountry;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public City getUnloadingCity() {
        return unloadingCity;
    }

    public void setUnloadingCity(City unloadingCity) {
        this.unloadingCity = unloadingCity;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Port getUnloadingPort() {
        return unloadingPort;
    }

    public void setUnloadingPort(Port unloadingPort) {
        this.unloadingPort = unloadingPort;
    }

    @Enumerated(EnumType.STRING)
    public InquiryType getInquiryType() {
        return inquiryType;
    }

    public void setInquiryType(InquiryType inquiryType) {
        this.inquiryType = inquiryType;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    @OneToMany(mappedBy = "inquiry")
    public List<InquiryFile> getInquiryFiles() {
        return inquiryFiles;
    }

    public void setInquiryFiles(List<InquiryFile> inquiryFiles) {
        this.inquiryFiles = inquiryFiles;
    }

    @OneToMany(mappedBy = "inquiry")
    public List<InquiryCalc> getInquiryCalcs() {
        return inquiryCalcs;
    }

    public void setInquiryCalcs(List<InquiryCalc> inquiryCalcs) {
        this.inquiryCalcs = inquiryCalcs;
    }

    public int getImportance() {
        return importance;
    }

    public void setImportance(int importance) {
        this.importance = importance;
    }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Enumerated(EnumType.STRING)
    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public Double getRate() {
        if(getBenefit()!=null && getCost()!=null && getBenefit().doubleValue()>0 && getCost().doubleValue()>0){
            rate = Helper.roundDecimal(getBenefit()/getCost()*100d);
        }
        return rate;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }

    public Double getBenefit() {
        if(price!=null && cost!=null){
            benefit = price - cost;
        }
        return benefit;
    }

    public void setBenefit(Double benefit) {
        this.benefit = benefit;
    }

    @Column(length = 120)
    public String getFileCode() {
        return fileCode;
    }

    public void setFileCode(String fileCode) {
        this.fileCode = fileCode;
    }

    @Enumerated(EnumType.STRING)
    public InquiryScale getInquiryScale() {
        return inquiryScale;
    }

    public void setInquiryScale(InquiryScale inquiryScale) {
        this.inquiryScale = inquiryScale;
    }

     @OneToMany(mappedBy = "inquiry")
    public List<InquiryTeamMember> getInquiryTeamMembers() {
        return inquiryTeamMembers;
    }

    public void setInquiryTeamMembers(List<InquiryTeamMember> inquiryTeamMembers) {
        this.inquiryTeamMembers = inquiryTeamMembers;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public MerchantBranch getBranch() {
        return branch;
    }

    public void setBranch(MerchantBranch branch) {
        this.branch = branch;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Double getOfferValue() {
        if(offerValue==null){
            offerValue = 0d;
        }
        return offerValue;
    }

    public void setOfferValue(Double offerValue) {
        this.offerValue = offerValue;
    }

    @Enumerated(EnumType.STRING)
    public Currency getOfferCurrency() {
        return offerCurrency;
    }

    public void setOfferCurrency(Currency offerCurrency) {
        this.offerCurrency = offerCurrency;
    }


    public Double getOfferCost() {
        if(offerCost == null){
            offerCost = 0d;
        }
        return offerCost;
    }

    public void setOfferCost(Double offerCost) {
        this.offerCost = offerCost;
    }

    public Double getOfferBenefit() {
       if(offerBenefit==null){
            offerBenefit = 0d;
       }
       return offerBenefit;
    }

    public void setOfferBenefit(Double offerBenefit) {
        this.offerBenefit = offerBenefit;
    }

    @Enumerated(EnumType.STRING)
    public InquiryWorkScope getScopeOfWork() {
        return scopeOfWork;
    }

    public void setScopeOfWork(InquiryWorkScope scopeOfWork) {
        this.scopeOfWork = scopeOfWork;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }
}
