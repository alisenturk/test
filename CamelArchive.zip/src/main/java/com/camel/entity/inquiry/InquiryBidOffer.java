package com.camel.entity.inquiry;

import com.camel.entity.base.BaseEntity;
import com.camel.enums.BulkType;
import com.camel.enums.Currency;
import com.camel.enums.InquiryBidOfferStatus;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;


/**
 *
 * @author alisenturk
 */

@Entity
@NamedQueries({
    @NamedQuery(name = "InquiryBidOffer.findAll",query = "select d from InquiryBidOffer d where d.inquiryBid.id =:bidid and d.status<>'DELETED'")
})

public class InquiryBidOffer extends BaseEntity implements Cloneable{
    
    private InquiryBid              inquiryBid;
    private double                  targetRate;
    private Currency                targetCurrency;
    private BulkType                targetBulkType;
    private String                  remarks;
    private InquiryBidOfferStatus   offerStatus;

    @ManyToOne
    public InquiryBid getInquiryBid() {
        return inquiryBid;
    }

    public void setInquiryBid(InquiryBid inquiryBid) {
        this.inquiryBid = inquiryBid;
    }

    public double getTargetRate() {
        return targetRate;
    }

    public void setTargetRate(double targetRate) {
        this.targetRate = targetRate;
    }

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    public Currency getTargetCurrency() {
        return targetCurrency;
    }

    public void setTargetCurrency(Currency targetCurrency) {
        this.targetCurrency = targetCurrency;
    }

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    public BulkType getTargetBulkType() {
        return targetBulkType;
    }

    public void setTargetBulkType(BulkType targetBulkType) {
        this.targetBulkType = targetBulkType;
    }

    @Column(length = 2000)
    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    public InquiryBidOfferStatus getOfferStatus() {
        return offerStatus;
    }

    public void setOfferStatus(InquiryBidOfferStatus offerStatus) {
        this.offerStatus = offerStatus;
    }
    
    
    
}
