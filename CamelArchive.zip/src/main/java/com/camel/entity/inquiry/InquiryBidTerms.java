/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.entity.inquiry;

import com.camel.entity.base.BaseEntity;
import com.camel.entity.base.Merchant;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.validation.constraints.NotNull;


/**
 *
 * @author alisenturk
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "InquiryBidTerms.findAllTerms",query = "select d from InquiryBidTerms d where d.merchant.id =:mrchntid and d.status<>'DELETED'")
})
public class InquiryBidTerms extends BaseEntity{
    
    private Merchant    merchant;
    private String      title;
    private String      description;

    @NotNull
    @ManyToOne
    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    @Column(length = 120)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Column(length = 500)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    
    
}
