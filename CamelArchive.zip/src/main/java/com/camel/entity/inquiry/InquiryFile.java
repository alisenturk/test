/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.entity.inquiry;

import com.camel.entity.base.BaseEntity;
import com.camel.enums.InquiryFileType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;


/**
 *
 * @author asenturk
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "InquiryFile.findAll",query = "select d from InquiryFile d where d.inquiry.id =:inqryid and d.status<>'DELETED'")    
})

public class InquiryFile extends BaseEntity{
    private Inquiry         inquiry;
    private InquiryFileType inqFileType;
    private String          fileName;
    private String          filePath;
    private String          fileType;
    private String          fileMimeType;
    
    @ManyToOne
    public Inquiry getInquiry() {
        return inquiry;
    }

    public void setInquiry(Inquiry inquiry) {
        this.inquiry = inquiry;
    }

    @Column(length=60)
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @Column(length = 512)
    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    @Column(length = 10)
    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    @Column(length = 200)
    public String getFileMimeType() {
        return fileMimeType;
    }

    public void setFileMimeType(String fileMimeType) {
        this.fileMimeType = fileMimeType;
    }

    @Enumerated(EnumType.STRING)
    public InquiryFileType getInqFileType() {
        return inqFileType;
    }

    public void setInqFileType(InquiryFileType inqFileType) {
        this.inqFileType = inqFileType;
    }
    
    
    
}
