/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.entity.inquiry;

import com.camel.entity.base.BaseEntity;
import com.camel.entity.base.OfferTemplate;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 *
 * @author asenturk
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "InquiryOffer.findAll",query = "select d from InquiryOffer d where d.inquiry.id =:inqryid and d.status<>'DELETED' order by d.status ")
})

public class InquiryOffer extends BaseEntity{
    
    private Inquiry         inquiry;
    private Date            offerDate;
    private Date            offerValidityDate;
    private OfferTemplate   offerTemplate;
    private String          offerContent;

    @ManyToOne
    public Inquiry getInquiry() {
        return inquiry;
    }

    public void setInquiry(Inquiry inquiry) {
        this.inquiry = inquiry;
    }

    @Temporal(TemporalType.DATE)
    public Date getOfferDate() {
        return offerDate;
    }

    public void setOfferDate(Date offerDate) {
        this.offerDate = offerDate;
    }

    @Temporal(TemporalType.DATE)
    public Date getOfferValidityDate() {
        return offerValidityDate;
    }

    public void setOfferValidityDate(Date offerValidityDate) {
        this.offerValidityDate = offerValidityDate;
    }

    @ManyToOne
    public OfferTemplate getOfferTemplate() {
        return offerTemplate;
    }

    public void setOfferTemplate(OfferTemplate offerTemplate) {
        this.offerTemplate = offerTemplate;
    }

    @Lob
    public String getOfferContent() {
        return offerContent;
    }

    public void setOfferContent(String offerContent) {
        this.offerContent = offerContent;
    }
    
    
    
}
