/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.camel.entity.inquiry;

import com.camel.entity.base.BaseEntity;
import com.camel.entity.base.Merchant;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.validation.constraints.NotNull;


/**
 *
 * @author asenturk
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "CalcItem.findAll",query = "select d from CalcItem d where d.merchant.id=:mrchntid and d.status<>'DELETED'")    
})

public class CalcItem extends BaseEntity{
    
    private Merchant    merchant;
    private String      itemName;

    @ManyToOne
    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    @NotNull
    @Column(length = 60)
    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }
    
    
    
}
