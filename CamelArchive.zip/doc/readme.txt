Maven ile yeni jar'ı local Repoya yüklemek
	mvn install:install-file -Dfile=/Users/alisenturk/Downloads/ultima-2.0.1/ultima-theme-2.0.1.jar -DgroupId=com.camel.external -DartifactId=primefaces-ultima-theme -Dversion=2.0.1 -Dpackaging=jar

Pom.xml içinde sürümü güncelle

SASS Kurulumu

	brew install sass/sass/sass
	Kurulum sonrası sorun yaşarsan;
		sudo gem uninstall sass
		sudo gem install sass -n /usr/local/bin

SCSS Derlemek:
	cd /Users/alisenturk/Java/GithubRepo/Camel
	sass --update src/main/webapp/resources/ --sourcemap=none


