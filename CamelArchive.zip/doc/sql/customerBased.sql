
--- Customer Based----------
select
  c.customerName ,
  iq.inquiryStatus ,
   count(1) cnt  
from
  inquiry iq
  JOIN customer c ON c.id = iq.customer_id
where
  iq.merchant_id = 1
  and (iq.requestDate between ADDDATE(curdate(), -400) and curdate()) 
  and iq.requestDate is not null  
group by c.customerName,iq.inquiryStatus
order by c.customerName,iq.inquiryStatus