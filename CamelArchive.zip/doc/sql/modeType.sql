--- MODE TYPE ----------
select
  iq.transportMode,
  iq.customsType,
   count(1) cnt  
from
  inquiry iq
  
where
  iq.merchant_id = 2405
  and (iq.requestDate between ADDDATE(curdate(), -400) and curdate()) 
  and iq.requestDate is not null  
group by iq.transportMode,iq.customsType
order by iq.transportMode,iq.customsType