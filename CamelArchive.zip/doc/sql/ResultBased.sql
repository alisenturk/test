
--- ResultBased----------
select
  iq.inquiryStatus ,
  iq.inquirySource ,
   count(1) cnt  
from
  inquiry iq
  
where
  iq.merchant_id = 1
  and (iq.requestDate between ADDDATE(curdate(), -400) and curdate()) 
  and iq.requestDate is not null  
group by iq.inquiryStatus,iq.inquirySource
order by iq.inquiryStatus,iq.inquirySource