select
  iq.responsible_id,
  u.firstname,
  u.lastname,
  avg(( case when (iq.offerDate - iq.requestDate)<24 then 24 else (iq.offerDate - iq.requestDate) end  /24)) avgOfferDays ,
  count(1) inquiryCount
from
  inquiry iq
  JOIN user u on u.id = iq.responsible_id
where
  iq.merchant_id = 2405
  and (iq.requestDate between ADDDATE(curdate(), -400) and curdate()) 
  and iq.offerDate is not null
  and iq.requestDate is not null  
group by iq.responsible_id
order by avgOfferDays,inquiryCount desc
