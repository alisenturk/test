
insert into country(id,countryCode,CountryName,continet,status) values(1,'TR','Turkey','EAST_MEDITERRANEAN','ACTIVE');

insert into city(id,country_id,cityCode,cityName,status) values(1,1,'IST','Istanbul','ACTIVE');

insert into merchant(id,status,merchantName) values(1,'ACTIVE','ISS Global Forwarding');

insert into merchantbranch(id,merchant_id,branchName,status,country_id,city_id) values(1,1,'ISTANBUL BRANCH','ACTIVE',1,1);
insert into department(id,merchant_id,branch_id,departmentName,status,charter) values(1,1,1,'PROJECT','ACTIVE',0);

INSERT INTO user(ID,createdBy,creationDate,status,email,enabled,firstname,lastname,password,userType,memberAdmin,merchant_id,department_id) 
VALUES (1,1,'2015-06-24 07:29:12','ACTIVE','ADMIN@ADMIN.COM',1,'ALI','SENTURK','admin1213','ADMIN',1,1,1);

insert into userauth(id,status,authCode,authName,authNameEn) values
(1,'ACTIVE','ROLE_ADMIN','ROLE_ADMIN','ROLE_ADMIN'),
(2,'ACTIVE','ROLE_MEMBER','ROLE_MEMBER','ROLE_MEMBER'),
(3,'ACTIVE','ROLE_ALLBRANCHES','TUM SUBE KAYITLARINI GOREBILIR','ALL BRANCHES VIEW'),
(4,'ACTIVE','ROLE_ALLDEPARTMENTS','TUM DEPARTMENLARIN KAYITLARINI GOREBILIR','TUM DEPARTMENLARIN KAYITLARINI GOREBILIR');


insert into user_userauth(User_id,userAuths_id,orderid) values(1,1,1);

